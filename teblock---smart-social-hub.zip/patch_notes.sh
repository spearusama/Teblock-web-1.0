sed -i '5i import { encryptText, decryptText } from "../utils/crypto";' components/NotesSystem.tsx
sed -i 's/setNotes(snap.docs.map(d => {/setNotes(snap.docs.map(d => { const data = d.data(); return { id: d.id, ...data, text: decryptText(data.text || "") };/g' components/NotesSystem.tsx
sed -i 's/userId: user.Id_user, text: textToSave/userId: user.Id_user, text: encryptText(textToSave)/g' components/NotesSystem.tsx
