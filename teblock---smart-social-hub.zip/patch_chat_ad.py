import re

with open('components/AIChatView.tsx', 'r') as f:
    content = f.read()

# Make sure to import AdComponent if not already there
if "import { AdComponent }" not in content:
    content = content.replace("import React", "import { AdComponent } from './AdComponent';\\nimport React")

chat_old = """                 {(index + 1) % 8 === 0 && (
                   <div 
                      onClick={() => window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank')}
                      className="flex items-center p-4 bg-white/[0.02] border border-blue-500/30 rounded-[2.2rem] hover:bg-white/[0.05] transition-all cursor-pointer relative overflow-hidden"
                   >
                      <div className="absolute top-0 right-0 bg-blue-600 text-white text-[8px] font-black px-2 py-0.5 rounded-bl-lg z-10">إعلان ممول</div>
                      <div className="relative ml-4">
                        <img src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=150&h=150&fit=crop" className="w-12 h-12 rounded-2xl border border-white/10 object-cover" alt="Ad" />
                      </div>
                      <div className="flex-1 text-right overflow-hidden">
                         <div className="flex justify-between items-center mb-1">
                            <span className="text-[8px] text-blue-400 font-bold">إعلان</span>
                            <h4 className="text-[11px] font-black text-blue-400">تطبيق جديد وحصري</h4>
                         </div>
                         <p className="text-[10px] text-slate-400 truncate font-bold">قم بتجربة أحدث الخدمات الآن مجاناً، اضغط هنا للمزيد.</p>
                      </div>
                   </div>
                 )}"""

chat_new = """                 {(index + 1) % 8 === 0 && (
                   <div className="relative p-2 bg-white/[0.02] border border-blue-500/30 rounded-[2.2rem] overflow-hidden">
                      <div className="absolute top-0 right-0 bg-blue-600 text-white text-[8px] font-black px-2 py-0.5 rounded-bl-lg z-10">إعلان ممول</div>
                      <AdComponent />
                   </div>
                 )}"""

content = content.replace(chat_old, chat_new)

with open('components/AIChatView.tsx', 'w') as f:
    f.write(content)
