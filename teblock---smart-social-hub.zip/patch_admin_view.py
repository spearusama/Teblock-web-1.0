import re

with open('components/AdminReportsView.tsx', 'r') as f:
    content = f.read()

delete_old = """  const handleDeleteContent = async (report: any) => {
    if (confirm("هل أنت متأكد من حذف المحتوى المبلغ عنه؟")) {
      try {
        if (report.messageId && report.reportedChat) {
          // It's a message in a chat
          await deleteDoc(doc(db, `chats/${report.reportedChat}/messages`, report.messageId));
        }
        // Then delete the report
        await deleteDoc(doc(db, 'reports', report.id));
        alert("تم حذف المحتوى والبلاغ بنجاح");
      } catch (e) {
        alert("فشل حذف المحتوى");
      }
    }
  };"""

delete_new = """  const handleDeleteContent = async (report: any) => {
    if (confirm("هل أنت متأكد من حذف المحتوى المبلغ عنه؟")) {
      try {
        if (report.messageId && report.reportedChat) {
          // It's a message in a chat
          await deleteDoc(doc(db, `chats/${report.reportedChat}/messages`, report.messageId));
        } else if (report.reelId) {
          // It's a reel
          await deleteDoc(doc(db, 'reels', report.reelId));
        } else if (report.reportedChat && !report.messageId) {
          // It's a whole chat report (maybe just delete the report since we don't want to delete the whole chat for everyone unless intended)
        }
        // Then delete the report
        await deleteDoc(doc(db, 'reports', report.id));
        alert("تم حذف المحتوى والبلاغ بنجاح");
      } catch (e) {
        alert("فشل حذف المحتوى");
      }
    }
  };"""

content = content.replace(delete_old, delete_new)

cond_old = """                 {(report.messageId || report.reportedChat) && ("""
cond_new = """                 {(report.messageId || report.reelId) && ("""

content = content.replace(cond_old, cond_new)

with open('components/AdminReportsView.tsx', 'w') as f:
    f.write(content)
