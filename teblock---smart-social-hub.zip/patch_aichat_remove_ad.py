import re

with open('components/AIChatView.tsx', 'r') as f:
    content = f.read()

content = content.replace("import { AdComponent } from './AdComponent';\n", "")

ad_block = """                 {(index + 1) % 8 === 0 && (
                   <div className="relative p-2 bg-white/[0.02] border border-blue-500/30 rounded-[2.2rem] overflow-hidden">
                      <div className="absolute top-0 right-0 bg-blue-600 text-white text-[8px] font-black px-2 py-0.5 rounded-bl-lg z-10">إعلان ممول</div>
                      <AdComponent />
                   </div>
                 )}"""

content = content.replace(ad_block, "")

with open('components/AIChatView.tsx', 'w') as f:
    f.write(content)
