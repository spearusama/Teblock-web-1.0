import re

with open('components/AuthForm.tsx', 'r') as f:
    content = f.read()

content = content.replace('} else {\n        const userDoc', '} else {\n        if (!agreeTerms) { setError(\'يجب الموافقة على سياسة الخصوصية وشروط الاستخدام\'); setIsSubmitting(false); return; }\n        const userDoc')

with open('components/AuthForm.tsx', 'w') as f:
    f.write(content)
