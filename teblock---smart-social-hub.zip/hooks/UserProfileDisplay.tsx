import React from 'react';
import { useUserProfile } from './useUserProfile';

export const UserAvatar: React.FC<{ userId: string, fallbackName: string, fallbackPhoto: string, currentUser: any, className?: string, onClick?: () => void }> = ({ userId, fallbackName, fallbackPhoto, currentUser, className, onClick }) => {
  const profile = useUserProfile(userId, fallbackName, fallbackPhoto, currentUser);
  return (
    <img src={profile.photo || `https://api.dicebear.com/7.x/bottts/svg?seed=${userId}`} alt={profile.name} className={className} onClick={onClick} />
  );
};

export const UserName: React.FC<{ userId: string, fallbackName: string, fallbackPhoto: string, currentUser: any, className?: string }> = ({ userId, fallbackName, fallbackPhoto, currentUser, className }) => {
  const profile = useUserProfile(userId, fallbackName, fallbackPhoto, currentUser);
  return (
    <span className={className}>{profile.name}</span>
  );
};
