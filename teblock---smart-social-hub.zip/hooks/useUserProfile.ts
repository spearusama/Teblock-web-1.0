import { useState, useEffect } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

const profileCache: Record<string, { UserData: string, photoURL: string }> = {};

export function useUserProfile(userId: string | undefined, fallbackName: string, fallbackPhoto: string, currentUser: any) {
  const [profile, setProfile] = useState({ 
    name: userId === currentUser?.Id_user ? currentUser.UserData : (profileCache[userId || '']?.UserData || fallbackName), 
    photo: userId === currentUser?.Id_user ? currentUser.photoURL : (profileCache[userId || '']?.photoURL || fallbackPhoto)
  });

  useEffect(() => {
    if (!userId || userId.startsWith('ai_') || userId === 'ai') return;
    
    if (userId === currentUser?.Id_user) {
      setProfile({ name: currentUser.UserData, photo: currentUser.photoURL });
      return;
    }
    
    if (profileCache[userId]) {
      setProfile({ name: profileCache[userId].UserData, photo: profileCache[userId].photoURL });
    }
    
    const unsub = onSnapshot(doc(db, 'users', userId), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        profileCache[userId] = { UserData: data.UserData, photoURL: data.photoURL || '' };
        setProfile({ name: data.UserData, photo: data.photoURL || fallbackPhoto });
      }
    });
    
    return unsub;
  }, [userId, currentUser?.UserData, currentUser?.photoURL, fallbackPhoto]);

  return profile;
}
