import re

with open('index.html', 'r') as f:
    content = f.read()

content = content.replace('    <!-- Adsterra Video/Banner Ad Script -->\n', '')
content = content.replace('    <script src="https://pl30593998.effectivecpmnetwork.com/5d/6d/3d/5d6d3d271dcc65e5ae0e572182cb4c4b.js"></script>\n', '')

with open('index.html', 'w') as f:
    f.write(content)
