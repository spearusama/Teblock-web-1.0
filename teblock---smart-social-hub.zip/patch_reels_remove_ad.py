import re

with open('components/ReelsView.tsx', 'r') as f:
    content = f.read()

content = content.replace("import { AdComponent } from './AdComponent';\n", "")

ad_block = """        {(index + 1) % 5 === 0 && (
            <div className="h-full w-full snap-start snap-always relative flex flex-col items-center justify-center bg-black overflow-hidden">
                <div className="absolute top-6 right-6 z-50">
                  <div className="bg-blue-600 text-white text-[10px] font-black px-3 py-1.5 rounded-lg shadow-lg uppercase tracking-wider">
                     إعلان ممول
                  </div>
               </div>
               <div className="flex-1 w-full h-full flex items-center justify-center">
                   <AdComponent />
               </div>
            </div>
        )}"""

content = content.replace(ad_block, "")

with open('components/ReelsView.tsx', 'w') as f:
    f.write(content)
