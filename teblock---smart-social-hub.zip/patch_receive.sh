sed -i '814i \
        const newIds = new Set(allMsgs.map((m: any) => m.id));\
        if (prevMsgIds.current.size > 0) {\
          const hasNew = allMsgs.some((m: any) => !prevMsgIds.current.has(m.id) && m.senderId !== user.Id_user && (m.timestamp?.seconds || 0) * 1000 > Date.now() - 5000);\
          if (hasNew) soundManager.playReceiveSound();\
        }\
        prevMsgIds.current = newIds;\
' components/AIChatView.tsx
