import re

with open('components/ChatContainer.tsx', 'r') as f:
    content = f.read()

state_old = "  const [isDeveloper, setIsDeveloper] = useState(() => localStorage.getItem('teblock_developer') === 'true');\n"
content = content.replace(state_old, "")

menu_old = """        <MenuView 
          isDeveloper={isDeveloper}
          setIsDeveloper={setIsDeveloper}
          onNavigate={(view) => setCurrentView(view as any)}
          onBack={() => setCurrentView('chats')}
        />"""

menu_new = """        <MenuView 
          user={user}
          onNavigate={(view) => setCurrentView(view as any)}
          onBack={() => setCurrentView('chats')}
        />"""
content = content.replace(menu_old, menu_new)

with open('components/ChatContainer.tsx', 'w') as f:
    f.write(content)
