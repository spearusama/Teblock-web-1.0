import React, { useState, useEffect } from 'react';
import twemoji from 'twemoji';

export type EmojiStyle = 'twemoji' | 'google' | 'system';

export interface EmojiStyleOption {
  id: EmojiStyle;
  name: string;
  nameEn: string;
  brand: string;
  color: string;
  description: string;
  license: string;
}

export const EMOJI_STYLES: EmojiStyleOption[] = [
  {
    id: 'twemoji',
    name: 'تويتر (Twemoji رسمي مفتوح المصدر)',
    nameEn: 'Twemoji (Official Open Source)',
    brand: 'Twemoji',
    color: 'from-sky-400 to-blue-500',
    description: 'المكتبة الرسمية المفتوحة المصدر (SVG فائق الدقة) المرخصة قانونياً برخصة المشاع الإبداعي CC-BY 4.0',
    license: 'CC-BY 4.0'
  },
  {
    id: 'google',
    name: 'جوجل (Google Noto رسمي)',
    nameEn: 'Google Noto (Official Open Source)',
    brand: 'Google Noto',
    color: 'from-amber-400 to-orange-500',
    description: 'المكتبة الرسمية المفتوحة المصدر من جوجل (Apache 2.0 / fonts.gstatic.com)',
    license: 'Apache 2.0'
  },
  {
    id: 'system',
    name: 'إيموجي النظام الرسمي (Native)',
    nameEn: 'Native System (Official OS)',
    brand: 'System Native',
    color: 'from-slate-600 to-slate-800',
    description: 'إيموجي نظام التشغيل المدمج في جهازك بدون أي صور خارجية (Unicode رسمي 100%)',
    license: 'Unicode Standard'
  }
];

const EMOJI_STYLE_KEY = 'teblock_emoji_style';
const DEFAULT_STYLE: EmojiStyle = 'twemoji';

export function getStoredEmojiStyle(): EmojiStyle {
  if (typeof window === 'undefined') return DEFAULT_STYLE;
  const saved = localStorage.getItem(EMOJI_STYLE_KEY) as string;
  if (saved && ['twemoji', 'google', 'system'].includes(saved)) {
    return saved as EmojiStyle;
  }
  // Clear any legacy unofficial style (apple/facebook) from localStorage
  if (saved && ['apple', 'facebook'].includes(saved)) {
    localStorage.setItem(EMOJI_STYLE_KEY, DEFAULT_STYLE);
  }
  return DEFAULT_STYLE;
}

export function setStoredEmojiStyle(style: EmojiStyle): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(EMOJI_STYLE_KEY, style);
  window.dispatchEvent(new CustomEvent('teblock_emoji_style_changed', { detail: style }));
}

export function useEmojiStyle(): EmojiStyle {
  const [style, setStyle] = useState<EmojiStyle>(getStoredEmojiStyle);

  useEffect(() => {
    const handleStyleChange = (e: Event) => {
      const customEvent = e as CustomEvent<EmojiStyle>;
      if (customEvent.detail) {
        setStyle(customEvent.detail);
      } else {
        setStyle(getStoredEmojiStyle());
      }
    };

    window.addEventListener('teblock_emoji_style_changed', handleStyleChange);
    window.addEventListener('storage', handleStyleChange);

    return () => {
      window.removeEventListener('teblock_emoji_style_changed', handleStyleChange);
      window.removeEventListener('storage', handleStyleChange);
    };
  }, []);

  return style;
}

/**
 * Returns the exact CDN image URL for an officially licensed emoji and style
 */
export function getEmojiUrl(emoji: string, style: EmojiStyle = 'twemoji'): string {
  if (style === 'system') return '';
  try {
    let code = twemoji.convert.toCodePoint(emoji);
    if (!code) return '';

    if (style === 'twemoji') {
      if (code === '2764-fe0f') code = '2764';
      return `https://cdn.jsdelivr.net/gh/jdecked/twemoji@latest/assets/svg/${code}.svg`;
    }

    if (style === 'google') {
      const cleanCode = code.replace(/-fe0f/g, '').toLowerCase();
      return `https://fonts.gstatic.com/s/e/notoemoji/latest/${cleanCode}/512.png`;
    }

    return `https://cdn.jsdelivr.net/gh/jdecked/twemoji@latest/assets/svg/${code}.svg`;
  } catch {
    return '';
  }
}

interface EmojiImgProps {
  emoji: string;
  size?: number | string;
  className?: string;
  styleOverride?: EmojiStyle;
  alt?: string;
}

export const EmojiImg: React.FC<EmojiImgProps> = ({ 
  emoji, 
  size = 20, 
  className = '', 
  styleOverride,
  alt 
}) => {
  const currentStyle = useEmojiStyle();
  const activeStyle = styleOverride || currentStyle;
  const [loadFailed, setLoadFailed] = useState(false);
  const [fallbackAttempted, setFallbackAttempted] = useState(false);

  useEffect(() => {
    setLoadFailed(false);
    setFallbackAttempted(false);
  }, [emoji, activeStyle]);

  if (!emoji) return null;

  // If system native style, render standard Unicode glyph directly without external image
  if (activeStyle === 'system') {
    const numericSize = typeof size === 'number' ? `${size}px` : size;
    return (
      <span 
        className={`inline-block select-none align-middle font-emoji ${className}`}
        style={{ fontSize: numericSize, lineHeight: 1 }}
        title={alt || emoji}
      >
        {emoji}
      </span>
    );
  }

  const primaryUrl = getEmojiUrl(emoji, activeStyle);
  const fallbackUrl = getEmojiUrl(emoji, 'twemoji');

  if (loadFailed || !primaryUrl) {
    const numericSize = typeof size === 'number' ? `${size}px` : size;
    return (
      <span 
        className={`inline-block select-none align-middle font-emoji ${className}`}
        style={{ fontSize: numericSize, lineHeight: 1 }}
        title={alt || emoji}
      >
        {emoji}
      </span>
    );
  }

  const currentSrc = fallbackAttempted ? fallbackUrl : primaryUrl;
  const numericSize = typeof size === 'number' ? `${size}px` : size;

  return (
    <img
      src={currentSrc}
      alt={alt || emoji}
      draggable={false}
      loading="lazy"
      onError={() => {
        if (!fallbackAttempted && fallbackUrl && fallbackUrl !== primaryUrl) {
          setFallbackAttempted(true);
        } else {
          setLoadFailed(true);
        }
      }}
      className={`inline-block align-middle select-none pointer-events-none object-contain ${className}`}
      style={{ 
        width: numericSize, 
        height: numericSize,
        minWidth: numericSize,
        minHeight: numericSize
      }}
    />
  );
};

export interface TokenPart {
  type: 'text' | 'emoji';
  value: string;
}

export function splitTextIntoTokens(text: string): TokenPart[] {
  if (!text) return [];
  const tokens: TokenPart[] = [];
  let lastIndex = 0;

  try {
    (twemoji as any).replace(text, (match: string, ...args: any[]) => {
      const offset = typeof args[args.length - 2] === 'number' ? args[args.length - 2] : text.indexOf(match, lastIndex);
      if (offset > lastIndex) {
        tokens.push({ type: 'text', value: text.substring(lastIndex, offset) });
      }
      tokens.push({ type: 'emoji', value: match });
      lastIndex = offset + match.length;
      return match;
    });

    if (lastIndex < text.length) {
      tokens.push({ type: 'text', value: text.substring(lastIndex) });
    }
  } catch {
    return [{ type: 'text', value: text }];
  }

  return tokens;
}

/**
 * Renders a string with all emojis replaced by uniform EmojiImg components
 */
export function renderEmojiText(
  text: string, 
  options?: { size?: number | string; style?: EmojiStyle; className?: string }
): React.ReactNode[] {
  if (!text) return [];
  const tokens = splitTextIntoTokens(text);
  const size = options?.size || 20;

  return tokens.map((token, index) => {
    if (token.type === 'emoji') {
      return (
        <EmojiImg 
          key={`e-${index}`} 
          emoji={token.value} 
          size={size} 
          styleOverride={options?.style}
          className={options?.className} 
        />
      );
    }
    return <span key={`t-${index}`}>{token.value}</span>;
  });
}
