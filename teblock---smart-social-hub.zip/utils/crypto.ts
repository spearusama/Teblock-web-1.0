import CryptoJS from 'crypto-js';

// Using a static key for app-level encryption, ensuring data is encrypted at rest in the database.
// In a production app, this could be derived from user passwords or managed via a KMS.
const SECRET_KEY = (typeof import.meta !== 'undefined' && (import.meta as any)?.env?.VITE_ENCRYPTION_KEY) || 
  (typeof process !== 'undefined' && process.env?.VITE_ENCRYPTION_KEY) || 
  "TeBLOCK_Comprehensive_Secure_Key_2026_!@#";

export const encryptText = (text: string): string => {
  if (!text) return text;
  try {
    return 'ENC:' + CryptoJS.AES.encrypt(text, SECRET_KEY).toString();
  } catch (e) {
    console.error("Encryption error:", e);
    return text;
  }
};

export const decryptText = (ciphertext: string): string => {
  if (!ciphertext) return ciphertext;
  if (typeof ciphertext === 'string' && ciphertext.startsWith('ENC:')) {
    try {
      const bytes = CryptoJS.AES.decrypt(ciphertext.replace('ENC:', ''), SECRET_KEY);
      const decrypted = bytes.toString(CryptoJS.enc.Utf8);
      return decrypted || ciphertext; // Fallback to ciphertext if decryption results in empty (wrong key)
    } catch (e) {
      console.error("Decryption error:", e);
      return ciphertext; // Fallback
    }
  }
  return ciphertext; // Return unencrypted for backward compatibility
};
