import React from 'react';
import { Reel } from '../types';

export const POPULAR_HASHTAGS = ['#fortnite', '#العاب', '#ترند', '#ضحك', '#تحديات', '#gaming', '#فلوق', '#تيك_توك'];

/**
 * Extracts all hashtags from a given text.
 * Supports Arabic, Latin, numeric, and underscore characters (e.g. #fortnite, #العاب, #pubg_mobile).
 */
export function extractHashtags(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  // Match hashtag symbol followed by letters (Arabic/Latin), numbers, or underscores
  const regex = /#([\p{L}\p{N}_]+)/gu;
  const matches = text.match(regex);
  if (!matches) return [];

  // Normalize: lowercase, trim, remove duplicate hashtags
  const normalized = matches.map(tag => tag.trim().toLowerCase());
  return Array.from(new Set(normalized));
}

/**
 * Retrieves all relevant hashtags for a given Reel.
 * Prioritizes reel.hashtags or extracts from reel.caption.
 */
export function getReelHashtags(reel: Reel): string[] {
  const fromCaption = extractHashtags(reel.caption || "");
  const fromHashtags = Array.isArray((reel as any).hashtags) 
    ? (reel as any).hashtags.map((h: string) => (h.startsWith('#') ? h.toLowerCase() : `#${h.toLowerCase()}`)) 
    : [];
  
  // Backwards compatibility: check if existing keywords are hashtags
  const fromKeywords = Array.isArray(reel.keywords)
    ? reel.keywords.filter(k => k.startsWith('#')).map(k => k.toLowerCase())
    : [];

  const combined = Array.from(new Set([...fromCaption, ...fromHashtags, ...fromKeywords]));
  return combined;
}

/**
 * Calculates recommendation score and match percentage between a reel's hashtags
 * and the user's interest vector.
 */
export function calculateReelMatch(
  reelHashtags: string[],
  userInterestVector: Record<string, number> = {}
): { score: number; matchPercentage: number; matchedTags: string[] } {
  if (!reelHashtags || reelHashtags.length === 0) {
    return { score: 0, matchPercentage: 0, matchedTags: [] };
  }

  let totalScore = 0;
  const matchedTags: string[] = [];

  for (const tag of reelHashtags) {
    const rawTag = tag.toLowerCase();
    const withoutHash = rawTag.replace(/^#/, '');

    // Check with and without '#'
    const weight = userInterestVector[rawTag] || userInterestVector[withoutHash] || 0;
    if (weight > 0) {
      totalScore += weight;
      matchedTags.push(rawTag);
    }
  }

  if (matchedTags.length === 0) {
    return { score: 0, matchPercentage: 0, matchedTags: [] };
  }

  // Calculate a realistic match percentage (30% to 100%)
  // Ratio of matched hashtags + weight boost
  const matchRatio = matchedTags.length / reelHashtags.length;
  const weightBoost = Math.min(40, totalScore * 10);
  const matchPercentage = Math.min(100, Math.max(30, Math.round(matchRatio * 60 + weightBoost)));

  return {
    score: totalScore,
    matchPercentage,
    matchedTags
  };
}

/**
 * Formats and renders text with interactive, highlighted hashtags.
 */
export function renderCaptionWithHashtags(
  text: string,
  onHashtagClick?: (tag: string) => void
): React.ReactNode {
  if (!text) return null;

  // Regex to split by hashtags while keeping them
  const parts = text.split(/(#[\p{L}\p{N}_]+)/gu);

  return parts.map((part, idx) => {
    if (part.startsWith('#') && part.length > 1) {
      return (
        <span
          key={idx}
          onClick={(e) => {
            e.stopPropagation();
            if (onHashtagClick) {
              onHashtagClick(part.toLowerCase());
            }
          }}
          className="text-blue-400 font-black cursor-pointer hover:text-blue-300 hover:underline transition-colors mx-0.5 inline-block pointer-events-auto"
        >
          {part}
        </span>
      );
    }
    return <span key={idx}>{part}</span>;
  });
}
