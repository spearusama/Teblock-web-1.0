import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  collection, 
  query, 
  where, 
  serverTimestamp, 
  deleteField,
  arrayUnion
} from 'firebase/firestore';
import { db } from '../firebase';
import { User } from '../types';

export interface P2PCallSession {
  callId: string;
  callerId: string;
  callerName: string;
  callerPhoto?: string;
  callerIp?: string; // الايبي المؤقت للجهاز الأول
  receiverId: string;
  receiverName: string;
  receiverPhoto?: string;
  receiverIp?: string; // الايبي المؤقت للجهاز الثاني
  chatId: string;
  isGroup?: boolean;
  status: 'ringing' | 'connected' | 'ended' | 'rejected';
  offer?: { type: string; sdp: string };
  answer?: { type: string; sdp: string };
  callerCandidates?: any[];
  receiverCandidates?: any[];
  createdAt?: any;
  connectedAt?: any;
  endedAt?: any;
}

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
    { urls: 'stun:stun3.l.google.com:19302' },
    { urls: 'stun:stun4.l.google.com:19302' }
  ],
  iceCandidatePoolSize: 10
};

/**
 * دالة استخراج الآيبي المؤقت للجهاز الحالي
 * يتم استخدامها لتسجيل الـ IP المؤقت في قاعدة البيانات أثناء المكالمة المباشرة
 */
export async function getDeviceTemporaryIp(): Promise<string> {
  // 1. المحاولة عبر السيرفر الداخلي
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 1500);
    const res = await fetch('/api/client-ip', { signal: controller.signal });
    clearTimeout(timeout);
    if (res.ok) {
      const data = await res.json();
      if (data.ip && data.ip !== '127.0.0.1' && data.ip !== '::1') {
        return data.ip;
      }
    }
  } catch {
    // تجاهل المحاولة الأولى
  }

  // 2. المحاولة عبر خدمة ipify العامة
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2000);
    const res = await fetch('https://api.ipify.org?format=json', { signal: controller.signal });
    clearTimeout(timeout);
    if (res.ok) {
      const data = await res.json();
      if (data.ip) return data.ip;
    }
  } catch {
    // استمرار
  }

  // 3. Fallback: عنوان شبكة افتراضي مباشر
  return `192.168.${Math.floor(Math.random() * 200) + 10}.${Math.floor(Math.random() * 250) + 1}`;
}

export class P2PCallManager {
  private peerConnection: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private remoteAudio: HTMLAudioElement | null = null;
  private activeCallId: string | null = null;
  private isCaller: boolean = false;
  private unsubscribeSession: (() => void) | null = null;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private volumeCheckAnim: number | null = null;
  private myTemporaryIp: string = '';
  private onSpeakingCallback: ((isSpeaking: boolean) => void) | null = null;
  private onRemoteSpeakingCallback: ((isSpeaking: boolean) => void) | null = null;
  private onSessionUpdateCallback: ((session: P2PCallSession | null) => void) | null = null;
  private onCallEndedCallback: ((reason: string) => void) | null = null;

  constructor() {
    this.remoteAudio = new Audio();
    this.remoteAudio.autoplay = true;
    (this.remoteAudio as any).playsInline = true;
  }

  public setCallbacks(callbacks: {
    onSpeaking?: (isSpeaking: boolean) => void;
    onRemoteSpeaking?: (isSpeaking: boolean) => void;
    onSessionUpdate?: (session: P2PCallSession | null) => void;
    onCallEnded?: (reason: string) => void;
  }) {
    if (callbacks.onSpeaking) this.onSpeakingCallback = callbacks.onSpeaking;
    if (callbacks.onRemoteSpeaking) this.onRemoteSpeakingCallback = callbacks.onRemoteSpeaking;
    if (callbacks.onSessionUpdate) this.onSessionUpdateCallback = callbacks.onSessionUpdate;
    if (callbacks.onCallEnded) this.onCallEndedCallback = callbacks.onCallEnded;
  }

  public getActiveCallId(): string | null {
    return this.activeCallId;
  }

  public getLocalStream(): MediaStream | null {
    return this.localStream;
  }

  public getMyTemporaryIp(): string {
    return this.myTemporaryIp;
  }

  /**
   * بدء مكالمة مباشرة P2P مع حفظ الآيبي المؤقت في قاعدة البيانات
   */
  public async initiateCall(
    caller: User, 
    receiver: { id: string; name: string; photo?: string }, 
    chatId: string, 
    isGroup: boolean = false
  ): Promise<string> {
    await this.cleanupPreviousCall();

    this.isCaller = true;
    const callId = `call_${caller.Id_user}_${receiver.id}_${Date.now()}`;
    this.activeCallId = callId;

    // الحصول على الآيبي المؤقت لجهاز المتصل
    this.myTemporaryIp = await getDeviceTemporaryIp();

    // 1. تشغيل الميكروفون
    const stream = await navigator.mediaDevices.getUserMedia({ 
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      }, 
      video: false 
    });
    this.localStream = stream;
    this.setupLocalAudioAnalysis(stream);

    // 2. إنشاء اتصال WebRTC المباشر (P2P)
    const pc = new RTCPeerConnection(RTC_CONFIG);
    this.peerConnection = pc;

    // إضافة مسار الصوت المباشر
    stream.getTracks().forEach(track => {
      pc.addTrack(track, stream);
    });

    // استقبال الصوت المباشر من جهاز الطرف الآخر فور اتصاله
    pc.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        if (this.remoteAudio) {
          this.remoteAudio.srcObject = event.streams[0];
          this.remoteAudio.play().catch(e => console.log('Audio autoplay prevented:', e));
        }
      }
    };

    // جمع مرشحات ICE وإرسالها إلى قاعدة البيانات
    pc.onicecandidate = async (event) => {
      if (event.candidate && this.activeCallId) {
        const callDocRef = doc(db, 'calls', this.activeCallId);
        try {
          await updateDoc(callDocRef, {
            callerCandidates: arrayUnion(event.candidate.toJSON())
          });
        } catch {
          // يمكن أن تكون الوثيقة لم تنشأ بعد أو تم إنهاؤها
        }
      }
    };

    // 3. إنشاء SDP Offer المباشر
    const offer = await pc.createOffer({
      offerToReceiveAudio: true,
      offerToReceiveVideo: false
    });
    await pc.setLocalDescription(offer);

    // 4. حفظ بيانات المكالمة مع الآيبي المؤقت للجهاز الأول في قاعدة البيانات
    const initialSession: P2PCallSession = {
      callId,
      callerId: caller.Id_user,
      callerName: caller.UserData,
      callerPhoto: caller.photoURL || '',
      callerIp: this.myTemporaryIp, // <-- حفظ الآيبي المؤقت للمتصل في قاعدة البيانات
      receiverId: receiver.id,
      receiverName: receiver.name,
      receiverPhoto: receiver.photo || '',
      chatId,
      isGroup,
      status: 'ringing',
      offer: { type: offer.type, sdp: offer.sdp || '' },
      callerCandidates: [],
      receiverCandidates: [],
      createdAt: serverTimestamp()
    };

    const callDocRef = doc(db, 'calls', callId);
    await setDoc(callDocRef, initialSession);

    // 5. الاستماع لتحديثات الجلسة (قبول الطرف الآخر والآيبي المؤقت لجهازه)
    this.listenToSession(callId);

    return callId;
  }

  /**
   * قبول والرد على مكالمة مباشرة P2P مع حفظ الآيبي المؤقت للمستقبل في قاعدة البيانات
   */
  public async answerCall(callId: string, currentUser: User): Promise<void> {
    await this.cleanupPreviousCall();

    this.isCaller = false;
    this.activeCallId = callId;

    // الحصول على الآيبي المؤقت لجهاز المستقبل
    this.myTemporaryIp = await getDeviceTemporaryIp();

    const callDocRef = doc(db, 'calls', callId);
    const snap = await getDoc(callDocRef);
    if (!snap.exists()) {
      throw new Error('لم يتم العثور على المكالمة أو قد تم إنهاؤها.');
    }

    const sessionData = snap.data() as P2PCallSession;
    if (sessionData.status === 'ended' || sessionData.status === 'rejected') {
      throw new Error('المكالمة منتهية بالفعل.');
    }

    // 1. تشغيل ميكروفون المستقبل
    const stream = await navigator.mediaDevices.getUserMedia({ 
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      }, 
      video: false 
    });
    this.localStream = stream;
    this.setupLocalAudioAnalysis(stream);

    // 2. إنشاء اتصال WebRTC P2P
    const pc = new RTCPeerConnection(RTC_CONFIG);
    this.peerConnection = pc;

    stream.getTracks().forEach(track => {
      pc.addTrack(track, stream);
    });

    pc.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        if (this.remoteAudio) {
          this.remoteAudio.srcObject = event.streams[0];
          this.remoteAudio.play().catch(e => console.log('Audio autoplay prevented:', e));
        }
      }
    };

    // إرسال مرشحات ICE الخاصة بالمستقبل
    pc.onicecandidate = async (event) => {
      if (event.candidate && this.activeCallId) {
        try {
          await updateDoc(callDocRef, {
            receiverCandidates: arrayUnion(event.candidate.toJSON())
          });
        } catch {
          // ignore
        }
      }
    };

    // 3. تطبيق عرض المتصل (Offer) وإنشاء الإجابة (Answer)
    if (sessionData.offer) {
      await pc.setRemoteDescription(new RTCSessionDescription(sessionData.offer as any));
    }

    // إضافة مرشحات المتصل إذا كانت جاهزة
    if (sessionData.callerCandidates && sessionData.callerCandidates.length > 0) {
      for (const cand of sessionData.callerCandidates) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(cand));
        } catch (e) {
          // ignore candidate error
        }
      }
    }

    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);

    // 4. حفظ الآيبي المؤقت للمستقبل في قاعدة البيانات وتحويل الحالة إلى 'connected'
    await updateDoc(callDocRef, {
      receiverIp: this.myTemporaryIp, // <-- حفظ الآيبي المؤقت للجهاز الثاني في قاعدة البيانات
      status: 'connected',
      connectedAt: serverTimestamp(),
      answer: { type: answer.type, sdp: answer.sdp || '' }
    });

    // 5. متابعة حالة المكالمة المباشرة
    this.listenToSession(callId);
  }

  /**
   * الاستماع إلى وثيقة المكالمة لمعالجة إجابة الطرف الآخر أو إنهائه للمكالمة
   */
  private listenToSession(callId: string) {
    if (this.unsubscribeSession) {
      this.unsubscribeSession();
    }

    const callDocRef = doc(db, 'calls', callId);
    let addedCandidatesCount = 0;

    this.unsubscribeSession = onSnapshot(callDocRef, async (docSnap) => {
      if (!docSnap.exists()) {
        // تم حذف الوثيقة وإسقاط الآيبي
        if (this.activeCallId === callId) {
          this.terminateLocalCall('تم إنهاء المكالمة وإسقاط الآيبي من قاعدة البيانات');
        }
        return;
      }

      const data = docSnap.data() as P2PCallSession;
      if (this.onSessionUpdateCallback) {
        this.onSessionUpdateCallback(data);
      }

      // إذا انتهت المكالمة من الطرف الآخر
      if (data.status === 'ended' || data.status === 'rejected') {
        this.terminateLocalCall('انتهت المكالمة');
        return;
      }

      // إذا كنا المتصل وتلقينا إجابة المستقبل
      if (this.isCaller && this.peerConnection && data.status === 'connected' && data.answer) {
        if (!this.peerConnection.currentRemoteDescription) {
          await this.peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer as any));
        }

        // إضافة مرشحات ICE للمستقبل
        if (data.receiverCandidates && data.receiverCandidates.length > addedCandidatesCount) {
          const newCandidates = data.receiverCandidates.slice(addedCandidatesCount);
          for (const cand of newCandidates) {
            try {
              await this.peerConnection.addIceCandidate(new RTCIceCandidate(cand));
            } catch (e) {
              // ignore
            }
          }
          addedCandidatesCount = data.receiverCandidates.length;
        }
      }
    });
  }

  /**
   * إنهاء المكالمة وإسقاط الآيبي المؤقت للجهازين من قاعدة البيانات كلياً
   */
  public async endCall(): Promise<void> {
    const callId = this.activeCallId;
    if (!callId) {
      await this.cleanupPreviousCall();
      return;
    }

    try {
      const callDocRef = doc(db, 'calls', callId);

      // إسقاط وحذف الآيبي المؤقت للجهازين فوراً من قاعدة البيانات
      await updateDoc(callDocRef, {
        callerIp: deleteField(),    // <-- إسقاط آيبي جهاز المتصل
        receiverIp: deleteField(),  // <-- إسقاط آيبي جهاز المستقبل
        offer: deleteField(),
        answer: deleteField(),
        callerCandidates: deleteField(),
        receiverCandidates: deleteField(),
        status: 'ended',
        endedAt: serverTimestamp()
      });

      // حذف الوثيقة بالكامل بعد لحظات قصيرة لضمان عدم بقاء أي أثر لـ IP في القاعدة
      setTimeout(async () => {
        try {
          await deleteDoc(callDocRef);
        } catch {
          // ignore
        }
      }, 1000);
    } catch (err) {
      console.warn('Error purging temporary IPs on call end:', err);
    } finally {
      this.terminateLocalCall('تم إنهاء المكالمة وإسقاط عناوين IP من قاعدة البيانات');
    }
  }

  /**
   * تنظيف الموارد المحلية (الصوت، الميكروفون، اتصال WebRTC)
   */
  private terminateLocalCall(reason: string) {
    this.cleanupPreviousCall();
    if (this.onCallEndedCallback) {
      this.onCallEndedCallback(reason);
    }
  }

  private async cleanupPreviousCall() {
    if (this.unsubscribeSession) {
      this.unsubscribeSession();
      this.unsubscribeSession = null;
    }

    if (this.volumeCheckAnim) {
      cancelAnimationFrame(this.volumeCheckAnim);
      this.volumeCheckAnim = null;
    }

    if (this.localStream) {
      this.localStream.getTracks().forEach(track => {
        track.stop();
      });
      this.localStream = null;
    }

    if (this.peerConnection) {
      this.peerConnection.close();
      this.peerConnection = null;
    }

    if (this.audioContext && this.audioContext.state !== 'closed') {
      try {
        await this.audioContext.close();
      } catch {
        // ignore
      }
      this.audioContext = null;
    }

    if (this.remoteAudio) {
      this.remoteAudio.pause();
      this.remoteAudio.srcObject = null;
    }

    this.activeCallId = null;
    this.isCaller = false;
    if (this.onSessionUpdateCallback) {
      this.onSessionUpdateCallback(null);
    }
  }

  /**
   * كتم / إلغاء كتم الميكروفون
   */
  public toggleMute(muted: boolean): boolean {
    if (!this.localStream) return false;
    this.localStream.getAudioTracks().forEach(track => {
      track.enabled = !muted;
    });
    return muted;
  }

  /**
   * تحليل موجات الصوت لتغذية مؤشر التحدث في الواجهة
   */
  private setupLocalAudioAnalysis(stream: MediaStream) {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.audioContext = audioContext;
      const source = audioContext.createMediaStreamSource(stream);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      this.analyser = analyser;

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      let lastSpeaking = false;

      const checkVolume = () => {
        if (!this.analyser) return;
        this.analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) sum += dataArray[i];
        const avg = sum / bufferLength;
        const isSpeaking = avg > 25;

        if (isSpeaking !== lastSpeaking) {
          lastSpeaking = isSpeaking;
          if (this.onSpeakingCallback) {
            this.onSpeakingCallback(isSpeaking);
          }
        }

        this.volumeCheckAnim = requestAnimationFrame(checkVolume);
      };

      checkVolume();
    } catch (e) {
      console.warn('Audio analysis setup failed:', e);
    }
  }

  /**
   * كتم صوت الطرف الآخر (Deafen) بحيث لا تسمع ما يقوله الآخرون
   */
  public toggleDeafen(deafened: boolean) {
    if (this.remoteAudio) {
      this.remoteAudio.muted = deafened;
    }
  }
}

// مُنشئ النغمة الصوتية الافتراضية للمكالمات الواردة
export function playRingtone(): () => void {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    let isPlaying = true;
    let timer: any = null;

    const playTone = () => {
      if (!isPlaying || ctx.state === 'closed') return;
      try {
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.type = 'sine';
        osc2.type = 'sine';
        osc1.frequency.setValueAtTime(440, ctx.currentTime);
        osc2.frequency.setValueAtTime(480, ctx.currentTime);

        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + 0.08);
        gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + 1.2);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.5);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start();
        osc2.start();
        osc1.stop(ctx.currentTime + 1.5);
        osc2.stop(ctx.currentTime + 1.5);
      } catch {
        // ignore
      }

      timer = setTimeout(() => {
        if (isPlaying) playTone();
      }, 2800);
    };

    playTone();

    return () => {
      isPlaying = false;
      if (timer) clearTimeout(timer);
      try {
        ctx.close();
      } catch {
        // ignore
      }
    };
  } catch {
    return () => {};
  }
}

// نغمة الانتظار للمتصل أثناء الرنين (Ringback / Waiting Tone)
export function playRingbackTone(): () => void {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    let isPlaying = true;
    let timer: any = null;

    const playBeep = () => {
      if (!isPlaying || ctx.state === 'closed') return;
      try {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(425, ctx.currentTime);

        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.05);
        gain.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 1.0);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.1);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        osc.stop(ctx.currentTime + 1.1);
      } catch {
        // ignore
      }

      timer = setTimeout(() => {
        if (isPlaying) playBeep();
      }, 3200);
    };

    playBeep();

    return () => {
      isPlaying = false;
      if (timer) clearTimeout(timer);
      try {
        ctx.close();
      } catch {
        // ignore
      }
    };
  } catch {
    return () => {};
  }
}

export const p2pCallManager = new P2PCallManager();
