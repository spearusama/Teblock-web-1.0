import { 
  collection, query, orderBy, limit, getDocs, startAfter, doc, getDoc, 
  QueryDocumentSnapshot, DocumentData 
} from 'firebase/firestore';
import { db } from '../firebase';
import { Reel } from '../types';
import { decryptText } from './crypto';
import { optimizeVideoUrl, optimizeMediaUrl } from './mediaOptimizer';
import { getReelHashtags, calculateReelMatch } from './hashtagUtils';

export interface ChunkFetchLog {
  id: string;
  time: string;
  reason: string;
  count: number;
  totalNow: number;
}

export interface ReelsManagerStats {
  chunkSize: number;
  totalChunksLoaded: number;
  totalReelsLoaded: number;
  hasMore: boolean;
  isInitialPreloaded: boolean;
  preloadedVideosCount: number;
  dataSavedPercent: number;
  estimatedDataSavedMB: number;
  fetchLogs: ChunkFetchLog[];
}

export const REELS_CHUNK_SIZE = 5;

// Cache of preloaded video elements in memory to maintain cached media stream
const preloadedVideoElements = new Map<string, HTMLVideoElement>();

class ReelsManager {
  private reels: Reel[] = [];
  private candidatePool: Reel[] = [];
  private seenReelIds: Set<string> = new Set();
  private lastDoc: QueryDocumentSnapshot<DocumentData> | null = null;
  private hasMore: boolean = true;
  private isLoading: boolean = false;
  private isPreloaded: boolean = false;
  private subscribers: Set<(reels: Reel[], updatedReelId?: string) => void> = new Set();
  private statsSubscribers: Set<(stats: ReelsManagerStats) => void> = new Set();
  private fetchLogs: ChunkFetchLog[] = [];
  private totalChunksLoaded: number = 0;
  private preloadedVideoUrls: Set<string> = new Set();
  private currentFilterHashtag: string | null = null;
  private currentUserId: string | null = null;
  private currentUserInterests: Record<string, number> = {};

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('teblock_reels_compressed', () => {
        this.resetAndRefresh();
      });
      window.addEventListener('teblock_video_quality_changed', () => {
        this.resetAndRefresh();
      });
    }
  }

  public subscribe(cb: (reels: Reel[], updatedReelId?: string) => void) {
    this.subscribers.add(cb);
    cb(this.reels);
    return () => {
      this.subscribers.delete(cb);
    };
  }

  public subscribeStats(cb: (stats: ReelsManagerStats) => void) {
    this.statsSubscribers.add(cb);
    cb(this.getStats());
    return () => {
      this.statsSubscribers.delete(cb);
    };
  }

  private notify(updatedReelId?: string) {
    const list = [...this.reels];
    this.subscribers.forEach(cb => cb(list, updatedReelId));
    this.notifyStats();
  }

  private notifyStats() {
    const stats = this.getStats();
    this.statsSubscribers.forEach(cb => cb(stats));
  }

  public getStats(): ReelsManagerStats {
    const singleFullFetchDocs = 50;
    const currentDocs = this.reels.length;
    const savedPercentage = currentDocs > 0 
      ? Math.max(0, Math.round(((singleFullFetchDocs - Math.min(singleFullFetchDocs, currentDocs)) / singleFullFetchDocs) * 100))
      : 90;
    
    const estimatedSavedMB = Math.round((Math.max(0, singleFullFetchDocs - currentDocs) * 1.8) * 10) / 10;

    return {
      chunkSize: REELS_CHUNK_SIZE,
      totalChunksLoaded: this.totalChunksLoaded,
      totalReelsLoaded: this.reels.length,
      hasMore: this.hasMore,
      isInitialPreloaded: this.isPreloaded,
      preloadedVideosCount: this.preloadedVideoUrls.size,
      dataSavedPercent: savedPercentage,
      estimatedDataSavedMB: estimatedSavedMB,
      fetchLogs: [...this.fetchLogs]
    };
  }

  public getLoadedReels(): Reel[] {
    return this.reels;
  }

  public getHasMore(): boolean {
    return this.hasMore || this.candidatePool.length > 0;
  }

  public getIsLoading(): boolean {
    return this.isLoading;
  }

  public setUserContext(userId?: string, interestVector?: Record<string, number>) {
    if (userId) this.currentUserId = userId;
    if (interestVector) this.currentUserInterests = { ...interestVector };
  }

  /**
   * Parse a raw Firestore doc into a typed Reel object
   */
  private parseDocToReel(d: QueryDocumentSnapshot<DocumentData> | DocumentData, id?: string): Reel {
    const data = typeof (d as any).data === 'function' ? (d as any).data() : d;
    const docId = id || (d as any).id;
    const mediaUrls = (data.mediaUrls || []).map((m: any) => ({
      ...m,
      url: optimizeMediaUrl(m.url, m.type)
    }));
    const videoUrl = optimizeVideoUrl(data.videoUrl);

    const caption = decryptText(data.caption || "");
    const reel: Reel = {
      id: docId,
      ...data,
      videoUrl: videoUrl || (mediaUrls.find((m: any) => m.type === 'video')?.url) || data.videoUrl,
      mediaUrls: mediaUrls.length > 0 ? mediaUrls : (videoUrl ? [{ url: videoUrl, type: 'video' }] : []),
      caption
    };

    const tags = getReelHashtags(reel);
    reel.hashtags = tags;
    return reel;
  }

  /**
   * Scores and organizes candidate reels according to viewer's interest vector.
   * Prioritizes high-affinity reels matching the hashtags the user interacts with,
   * while smoothly interleaving fresh content so the feed stays lively and diverse.
   */
  private scoreAndOrganizeCandidates(
    candidates: Reel[], 
    interestVector: Record<string, number> = {},
    filterHashtag?: string | null
  ): Reel[] {
    let list = [...candidates];

    // Filter by specific hashtag if user selected one
    if (filterHashtag) {
      const cleanFilter = filterHashtag.toLowerCase().replace(/^#/, '');
      list = list.filter(reel => {
        const tags = getReelHashtags(reel);
        return tags.some(t => t.toLowerCase().replace(/^#/, '') === cleanFilter);
      });
    }

    // Score each candidate against viewer's interest vector
    list.forEach(reel => {
      const tags = getReelHashtags(reel);
      reel.hashtags = tags;
      const match = calculateReelMatch(tags, interestVector);
      reel._algoScore = match.score;
      reel.matchPercentage = match.matchPercentage;
    });

    // Partition: high-affinity (matched interests) vs general (fresh content)
    const highAffinity = list.filter(r => (r._algoScore || 0) > 0)
      .sort((a, b) => (b._algoScore || 0) - (a._algoScore || 0));
    const general = list.filter(r => (r._algoScore || 0) <= 0)
      .sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));

    // Interleave: 2 interest reels : 1 fresh discovery reel
    const organized: Reel[] = [];
    let highIdx = 0;
    let genIdx = 0;

    while (highIdx < highAffinity.length || genIdx < general.length) {
      if (highIdx < highAffinity.length) organized.push(highAffinity[highIdx++]);
      if (highIdx < highAffinity.length) organized.push(highAffinity[highIdx++]);
      if (genIdx < general.length) organized.push(general[genIdx++]);
    }

    return organized;
  }

  /**
   * Preload video assets into browser cache
   */
  public preloadVideoUrl(url: string) {
    const optimized = optimizeVideoUrl(url);
    if (!optimized || this.preloadedVideoUrls.has(optimized)) return;
    this.preloadedVideoUrls.add(optimized);

    try {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.as = 'video';
      link.href = optimized;
      document.head.appendChild(link);

      const vid = document.createElement('video');
      vid.preload = 'auto';
      vid.muted = true;
      vid.src = optimized;
      vid.style.display = 'none';
      vid.load();
      preloadedVideoElements.set(optimized, vid);

      if (preloadedVideoElements.size > 8) {
        const oldestKey = preloadedVideoElements.keys().next().value;
        if (oldestKey) {
          const oldVid = preloadedVideoElements.get(oldestKey);
          if (oldVid) {
            oldVid.src = '';
            oldVid.remove();
          }
          preloadedVideoElements.delete(oldestKey);
        }
      }
    } catch (err) {
      console.warn("Video preload error:", err);
    }
  }

  /**
   * Preload the initial batch of reels and the first 2 videos
   * before the user navigates into the Reels view.
   */
  public async preloadBeforeEntering(currentUserId?: string) {
    if (this.reels.length > 0 || this.isLoading) return;
    try {
      await this.fetchInitialChunk('تحميل مسبق في الخلفية (Zero Wait Time)', { Id_user: currentUserId });
      this.isPreloaded = true;
      this.notifyStats();
    } catch (e) {
      console.warn("Background preload error:", e);
    }
  }

  /**
   * Proactively buffer the next 2 upcoming reels when viewing at index
   */
  public preloadUpcoming(currentIndex: number) {
    const next1 = this.reels[currentIndex + 1];
    const next2 = this.reels[currentIndex + 2];

    if (next1) {
      const vidUrl = next1.videoUrl || next1.mediaUrls?.find(m => m.type === 'video')?.url;
      if (vidUrl) this.preloadVideoUrl(vidUrl);
    }
    if (next2) {
      const vidUrl = next2.videoUrl || next2.mediaUrls?.find(m => m.type === 'video')?.url;
      if (vidUrl) this.preloadVideoUrl(vidUrl);
    }
  }

  /**
   * Fetch initial chunk organized according to viewer interests
   */
  public async fetchInitialChunk(
    reason: string = 'بدء تشغيل الريلز', 
    user?: { Id_user?: string; interestVector?: Record<string, number> }, 
    filterHashtag?: string | null
  ): Promise<Reel[]> {
    if (this.isLoading) return this.reels;
    this.isLoading = true;
    this.currentFilterHashtag = filterHashtag || null;
    if (user?.Id_user) this.currentUserId = user.Id_user;
    if (user?.interestVector) this.currentUserInterests = { ...user.interestVector };

    this.seenReelIds.clear();
    this.candidatePool = [];
    this.reels = [];
    this.lastDoc = null;
    this.hasMore = true;

    try {
      const candidateLimit = 30;
      const q = query(
        collection(db, 'reels'),
        orderBy('timestamp', 'desc'),
        limit(candidateLimit)
      );

      const snap = await getDocs(q);
      const docs = snap.docs;

      if (docs.length < candidateLimit) {
        this.hasMore = false;
      }
      if (docs.length > 0) {
        this.lastDoc = docs[docs.length - 1];
      }

      const parsed: Reel[] = docs.map(d => this.parseDocToReel(d));
      const organized = this.scoreAndOrganizeCandidates(parsed, this.currentUserInterests, this.currentFilterHashtag);

      const initialBatch = organized.slice(0, REELS_CHUNK_SIZE);
      const remaining = organized.slice(REELS_CHUNK_SIZE);

      initialBatch.forEach(r => this.seenReelIds.add(r.id));
      this.reels = initialBatch;
      this.candidatePool = remaining;
      this.totalChunksLoaded = 1;

      this.fetchLogs.unshift({
        id: `chunk-${Date.now()}`,
        time: new Date().toLocaleTimeString(),
        reason,
        count: initialBatch.length,
        totalNow: initialBatch.length
      });
      if (this.fetchLogs.length > 20) this.fetchLogs.pop();

      this.logServerActivity('REELS_CHUNK_LOADED', `${reason} - سحب منظم حسب الاهتمامات (${initialBatch.length} ريلز)`);

      if (this.reels[0]) {
        const u = this.reels[0].videoUrl || this.reels[0].mediaUrls?.find(m => m.type === 'video')?.url;
        if (u) this.preloadVideoUrl(u);
      }
      if (this.reels[1]) {
        const u = this.reels[1].videoUrl || this.reels[1].mediaUrls?.find(m => m.type === 'video')?.url;
        if (u) this.preloadVideoUrl(u);
      }

      this.notify();
      return this.reels;
    } catch (err) {
      console.error("Failed to load initial reels chunk:", err);
      return this.reels;
    } finally {
      this.isLoading = false;
    }
  }

  /**
   * Fetch the next batch when approaching the end of current reels.
   * Appends to the bottom of the feed without modifying already viewed items.
   */
  public async fetchNextChunk(
    reason: string = 'الاقتراب من نهاية الريلزات المتوفرة', 
    user?: { Id_user?: string; interestVector?: Record<string, number> }
  ): Promise<Reel[]> {
    if (this.isLoading) return this.reels;
    if (user?.interestVector) this.currentUserInterests = { ...user.interestVector };

    // 1. Check if we have unseen organized candidates in candidatePool
    if (this.candidatePool.length > 0) {
      const nextBatch = this.candidatePool.slice(0, REELS_CHUNK_SIZE);
      this.candidatePool = this.candidatePool.slice(REELS_CHUNK_SIZE);

      const uniqueBatch = nextBatch.filter(r => !this.seenReelIds.has(r.id));
      uniqueBatch.forEach(r => this.seenReelIds.add(r.id));

      if (uniqueBatch.length > 0) {
        // APPEND ONLY - NEVER REORDER EXISTING REELS
        this.reels = [...this.reels, ...uniqueBatch];
        this.totalChunksLoaded += 1;

        this.fetchLogs.unshift({
          id: `chunk-${Date.now()}`,
          time: new Date().toLocaleTimeString(),
          reason: `${reason} (من الطابور المنظم)`,
          count: uniqueBatch.length,
          totalNow: this.reels.length
        });
        if (this.fetchLogs.length > 20) this.fetchLogs.pop();

        if (uniqueBatch[0]) {
          const u = uniqueBatch[0].videoUrl || uniqueBatch[0].mediaUrls?.find(m => m.type === 'video')?.url;
          if (u) this.preloadVideoUrl(u);
        }

        this.notify();
        return this.reels;
      }
    }

    // 2. If candidatePool is exhausted, query next batch from Firestore
    if (!this.hasMore || !this.lastDoc) {
      return this.reels;
    }

    this.isLoading = true;
    try {
      const fetchLimit = 25;
      const q = query(
        collection(db, 'reels'),
        orderBy('timestamp', 'desc'),
        startAfter(this.lastDoc),
        limit(fetchLimit)
      );

      const snap = await getDocs(q);
      const docs = snap.docs;

      if (docs.length < fetchLimit) {
        this.hasMore = false;
      }

      if (docs.length > 0) {
        this.lastDoc = docs[docs.length - 1];
        const parsed: Reel[] = docs.map(d => this.parseDocToReel(d));

        const unseen = parsed.filter(r => !this.seenReelIds.has(r.id));
        const organized = this.scoreAndOrganizeCandidates(unseen, this.currentUserInterests, this.currentFilterHashtag);

        const nextBatch = organized.slice(0, REELS_CHUNK_SIZE);
        const remaining = organized.slice(REELS_CHUNK_SIZE);

        nextBatch.forEach(r => this.seenReelIds.add(r.id));
        this.candidatePool = [...this.candidatePool, ...remaining];

        if (nextBatch.length > 0) {
          // APPEND ONLY
          this.reels = [...this.reels, ...nextBatch];
          this.totalChunksLoaded += 1;

          this.fetchLogs.unshift({
            id: `chunk-${Date.now()}`,
            time: new Date().toLocaleTimeString(),
            reason,
            count: nextBatch.length,
            totalNow: this.reels.length
          });
          if (this.fetchLogs.length > 20) this.fetchLogs.pop();

          if (nextBatch[0]) {
            const u = nextBatch[0].videoUrl || nextBatch[0].mediaUrls?.find(m => m.type === 'video')?.url;
            if (u) this.preloadVideoUrl(u);
          }

          this.notify();
        }
      } else {
        this.hasMore = false;
        this.notifyStats();
      }

      return this.reels;
    } catch (err) {
      console.error("Failed to load next reels chunk:", err);
      return this.reels;
    } finally {
      this.isLoading = false;
    }
  }

  /**
   * Load a specific jump reel if not already in memory
   */
  public async ensureReelLoaded(reelId: string): Promise<void> {
    if (this.reels.some(r => r.id === reelId)) return;
    try {
      const dSnap = await getDoc(doc(db, 'reels', reelId));
      if (dSnap.exists()) {
        const reel = this.parseDocToReel(dSnap);
        this.seenReelIds.add(reelId);
        // Place jump reel at top
        this.reels = [reel, ...this.reels.filter(r => r.id !== reelId)];
        const vidUrl = reel.videoUrl || reel.mediaUrls?.find(m => m.type === 'video')?.url;
        if (vidUrl) this.preloadVideoUrl(vidUrl);
        this.notify();
      }
    } catch (e) {
      console.error("Error loading jump reel:", e);
    }
  }

  /**
   * Update reel in local memory (e.g. likes/comments update)
   * Updates strictly in-place without changing feed array order.
   */
  public updateLocalReel(reelId: string, updater: (prev: Reel) => Reel) {
    this.reels = this.reels.map(r => r.id === reelId ? updater(r) : r);
    if (this.candidatePool.length > 0) {
      this.candidatePool = this.candidatePool.map(r => r.id === reelId ? updater(r) : r);
    }
    this.notify(reelId);
  }

  /**
   * Remove reel from local memory when deleted
   */
  public removeLocalReel(reelId: string) {
    this.seenReelIds.delete(reelId);
    this.reels = this.reels.filter(r => r.id !== reelId);
    this.candidatePool = this.candidatePool.filter(r => r.id !== reelId);
    this.notify();
  }

  /**
   * Refresh reels list from scratch
   */
  public async resetAndRefresh(): Promise<void> {
    this.lastDoc = null;
    this.hasMore = true;
    this.reels = [];
    this.candidatePool = [];
    this.seenReelIds.clear();
    preloadedVideoElements.forEach(v => {
      try {
        v.src = '';
        v.remove();
      } catch (e) {}
    });
    preloadedVideoElements.clear();
    this.preloadedVideoUrls.clear();
    await this.fetchInitialChunk('تحديث يدوي ومزامنة الجودة المضغوطة', { 
      Id_user: this.currentUserId || undefined, 
      interestVector: this.currentUserInterests 
    }, this.currentFilterHashtag);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('teblock_reels_refreshed'));
    }
  }

  private logServerActivity(event: string, detail: string) {
    try {
      fetch('/api/log-activity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event, detail })
      }).catch(() => {});
    } catch (e) {}
  }
}

export const reelsManager = new ReelsManager();
