class SoundManager {
  private audioCtx: AudioContext | null = null;

  private init() {
    if (!this.audioCtx) {
      this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  private playTone(freq: number, type: OscillatorType, duration: number, vol = 0.1, freqEnd?: number, sweepType: 'linear' | 'exponential' = 'exponential', startTimeOffset = 0) {
    try {
      const ctx = this.init();
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();

      const startTime = ctx.currentTime + startTimeOffset;

      osc.type = type;
      osc.frequency.setValueAtTime(freq, startTime);
      if (freqEnd) {
        if (sweepType === 'exponential') {
          osc.frequency.exponentialRampToValueAtTime(freqEnd, startTime + duration);
        } else {
          osc.frequency.linearRampToValueAtTime(freqEnd, startTime + duration);
        }
      }

      // Smooth envelope to avoid clicks (Attack & Decay)
      gainNode.gain.setValueAtTime(0, startTime);
      gainNode.gain.linearRampToValueAtTime(vol, startTime + duration * 0.1);
      gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

      osc.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + duration);
    } catch (e) {
      console.log('Audio playback failed', e);
    }
  }

  playOpenChatSound() {
    // Soft elegant slide up
    this.playTone(300, 'sine', 0.2, 0.05, 500, 'exponential');
  }

  playSendSound() {
    // Modern soft bloop up
    this.playTone(400, 'sine', 0.1, 0.05, 600, 'linear');
  }

  playReceiveSound() {
    // Elegant soft pop
    this.playTone(600, 'sine', 0.15, 0.05, 400, 'linear');
  }

  playLongPressSound() {
    // Bubble pops matching the emoji popIn animation (staggered by 0.06s)
    this.playTone(400, 'sine', 0.1, 0.03, 600, 'linear', 0);
    this.playTone(450, 'sine', 0.1, 0.03, 650, 'linear', 0.06);
    this.playTone(500, 'sine', 0.1, 0.03, 700, 'linear', 0.12);
    this.playTone(550, 'sine', 0.1, 0.03, 750, 'linear', 0.18);
    this.playTone(600, 'sine', 0.1, 0.03, 800, 'linear', 0.24);
    this.playTone(650, 'sine', 0.1, 0.03, 850, 'linear', 0.30);
  }

  playEditSound() {
    // Soft tick
    this.playTone(800, 'sine', 0.05, 0.05, 500, 'linear');
  }

  playDeleteSound() {
    // Soft low swish/thud
    this.playTone(300, 'sine', 0.2, 0.05, 100, 'exponential');
  }
}

export const soundManager = new SoundManager();
