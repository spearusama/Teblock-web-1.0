/**
 * User Utilities for 10-digit permanent ID-2, Age Calculation, and Profile Link formatting
 */

export const generatePermanentId2 = (): string => {
  // Generates a 10-digit unique integer string (1000000000 to 9999999999)
  const min = 1000000000;
  const max = 9999999999;
  const rand = Math.floor(min + Math.random() * (max - min + 1));
  return rand.toString();
};

export const calculateAge = (birthDateString?: string): number | null => {
  if (!birthDateString || typeof birthDateString !== 'string') return null;
  const birth = new Date(birthDateString);
  if (isNaN(birth.getTime())) return null;

  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age >= 0 && age < 130 ? age : null;
};

export const getUserProfileUrl = (id2?: string, fallbackId?: string): string => {
  const identifier = id2 || fallbackId || '';
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  return `${origin}/user/${identifier}`;
};
