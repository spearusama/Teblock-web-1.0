/**
 * Native Device / Browser Notifications Helper
 * Shows system-level notifications with the TEBLOCK app icon when messages or calls arrive.
 */

const APP_ICON = 'https://api.dicebear.com/7.x/shapes/svg?seed=TEBLOCK&backgroundColor=2563eb';

export const requestDeviceNotificationPermission = async (): Promise<boolean> => {
  if (typeof window === 'undefined' || !('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  try {
    const result = await Notification.requestPermission();
    return result === 'granted';
  } catch {
    return false;
  }
};

export const showDeviceNotification = (
  title: string,
  body: string,
  options?: {
    icon?: string;
    tag?: string;
    onClick?: () => void;
  }
) => {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission !== 'granted') return;

  try {
    const notification = new Notification(title, {
      body,
      icon: options?.icon || APP_ICON,
      badge: APP_ICON,
      tag: options?.tag,
      silent: false,
    });

    notification.onclick = () => {
      window.focus();
      options?.onClick?.();
      notification.close();
    };
  } catch (err) {
    console.warn('Device notification failed:', err);
  }
};
