import re

with open('components/ChatContainer.tsx', 'r') as f:
    content = f.read()

# 1. Import MenuView
if "import { MenuView }" not in content:
    content = content.replace("export const ChatContainer = ", "import { MenuView } from './MenuView';\nexport const ChatContainer = ")

# 2. Add 'menu' to views cases
view_cases_old = """    if (currentView === 'admin_reports') {
      return (
        <AdminReportsView 
          onBack={() => setCurrentView('chats')}
        />
      );
    }"""

view_cases_new = """    if (currentView === 'admin_reports') {
      return (
        <AdminReportsView 
          onBack={() => setCurrentView('chats')}
        />
      );
    }
    if (currentView === 'menu') {
      return (
        <MenuView 
          isDeveloper={isDeveloper}
          setIsDeveloper={setIsDeveloper}
          onNavigate={(view) => setCurrentView(view as any)}
          onBack={() => setCurrentView('chats')}
        />
      );
    }"""
content = content.replace(view_cases_old, view_cases_new)

# 3. Modify nav bar button for menu
nav_old = """           <button onClick={() => setShowMenu(true)} className={`p-3 transition-all ${showMenu ? 'text-blue-500 scale-110' : 'text-slate-500 opacity-40'}`}>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" strokeWidth={2.5}/></svg>
           </button>"""

nav_new = """           <button onClick={() => { setCurrentView('menu'); setJumpToReelId(null); }} className={`p-3 transition-all ${currentView === 'menu' ? 'text-blue-500 scale-110' : 'text-slate-500 opacity-40'}`}>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" strokeWidth={2.5}/></svg>
           </button>"""
content = content.replace(nav_old, nav_new)

# 4. Remove the old menu modal code and states
state_old = "  const [showMenu, setShowMenu] = useState(false);\n"
content = content.replace(state_old, "")

menu_modal_regex = re.compile(r'\{showMenu && \(\s*<div className="fixed inset-0 z-\[200\] flex flex-col justify-end bg-black/60 backdrop-blur-sm".*?</div>\s*\)\}', re.DOTALL)
content = re.sub(menu_modal_regex, '', content)

with open('components/ChatContainer.tsx', 'w') as f:
    f.write(content)
