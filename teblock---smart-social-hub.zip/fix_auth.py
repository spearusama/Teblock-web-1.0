import re

with open('components/AuthForm.tsx', 'r') as f:
    content = f.read()

# remove old one if exists
content = re.sub(r'<div className="flex items-start space-x-3 space-x-reverse mt-4 mb-4">.*?</div>\n', '', content, flags=re.DOTALL)

checkbox_ui = """
        <div className="flex items-start space-x-3 space-x-reverse mb-6">
          <input 
            type="checkbox" 
            id="agreeTerms" 
            checked={agreeTerms}
            onChange={(e) => setAgreeTerms(e.target.checked)}
            className="mt-1 w-4 h-4 rounded border-white/20 bg-black/40 text-blue-600 focus:ring-blue-600 focus:ring-offset-0 focus:ring-offset-transparent cursor-pointer"
          />
          <label htmlFor="agreeTerms" className="text-[10px] text-slate-400 leading-relaxed cursor-pointer select-none">
            أوافق على <button type="button" onClick={() => setShowTerms(true)} className="text-blue-400 font-bold hover:underline">شروط الاستخدام وسياسة الخصوصية</button> الخاصة بـ TeBLOCK. وأقر بأن التطبيق غير مسؤول قانونياً عن أي خرق أمني أو تسريب ناتج عن ثغرات في خوادم طرف ثالث.
          </label>
        </div>
"""

# Find <button and insert before it
content = re.sub(r'(        <button\s+type="submit")', checkbox_ui + r'\1', content)

# Also disable button if !agreeTerms
content = re.sub(r'disabled=\{isSubmitting\}', 'disabled={isSubmitting || !agreeTerms}', content)

with open('components/AuthForm.tsx', 'w') as f:
    f.write(content)
