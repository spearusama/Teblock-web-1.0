# Add terms states
sed -i 's/const \[isSubmitting, setIsSubmitting\] = useState(false);/const [isSubmitting, setIsSubmitting] = useState(false);\n  const [agreeTerms, setAgreeTerms] = useState(false);\n  const [showTerms, setShowTerms] = useState(false);/g' components/AuthForm.tsx

# Add validation
sed -i 's/if (mode === '"'"'signup'"'"') {/if (mode === '"'"'signup'"'"') {\n        if (!agreeTerms) { setError('"'"'يجب الموافقة على سياسة الخصوصية وشروط الاستخدام'"'"'); setIsSubmitting(false); return; }/g' components/AuthForm.tsx

