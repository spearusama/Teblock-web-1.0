// Function to get a smart response from Gemini AI via server-side proxy
export const getSmartResponse = async (
  userMessage: string, 
  userName: string, 
  history: { role: 'user' | 'model', text: string }[] = []
): Promise<string> => {
  try {
    const res = await fetch("/api/gemini/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userMessage, userName, history })
    });
    
    const data = await res.json();
    if (res.ok && data.text) {
      return data.text;
    }
    
    if (data.error) {
      console.warn("Gemini Chat API returned error:", data.error);
      const errStr = typeof data.error === 'string' ? data.error : JSON.stringify(data.error);
      if (errStr.includes("API key not valid") || errStr.includes("API_KEY_INVALID")) {
        return "خطأ: مفتاح الذكاء الاصطناعي (API Key) غير صالح. يرجى التحقق من المفتاح في الإعدادات.";
      }
      return errStr.length < 120 ? errStr : "حدث خطأ أثناء معالجة الرد من الذكاء الاصطناعي.";
    }

    return "عذراً، أواجه صعوبة في معالجة طلبك حالياً.";
  } catch (err: any) {
    console.error("Gemini Chat Network Error:", err);
    return "تعذر الاتصال بخادم الذكاء الاصطناعي، يرجى المحاولة لاحقاً.";
  }
};
