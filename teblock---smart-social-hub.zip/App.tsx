
import React, { useState, useEffect } from 'react';
import { User } from './types';
import AuthForm from './components/AuthForm';
import ChatContainer from './components/ChatContainer';
import AccountPicker from './components/AccountPicker';
import { db, handleFirestoreError, OperationType } from './firebase';
import { doc, onSnapshot, addDoc, collection, serverTimestamp, updateDoc } from 'firebase/firestore';
import { LanguageProvider, useLanguage } from './utils/i18n';

import { generatePermanentId2 } from './utils/userUtils';

export const checkAccess = (status: string, unlockTime: string) => {
  if (status === "يوجد") return { allowed: true };
  if (status === "مقفل") return { allowed: false, key: 'settings.accountLockedMessage', fallback: "هذا الحساب مقفل حالياً بناءً على طلبك. يمكنك إلغاء القفل لاستعادة الوصول.", isLocked: true };
  if (unlockTime === "{¥}") return { allowed: false, key: 'settings.accountBannedMessage', fallback: "تم حظر هذا الحساب نهائياً لمخالفته بنود الأمان" };
  const now = new Date();
  const unlockDate = new Date(unlockTime);
  if (!isNaN(unlockDate.getTime()) && now > unlockDate) return { allowed: true }; 
  return { allowed: false, message: `هذه الخاصية معطلة حالياً. موعد فك القيد: ${unlockDate.toLocaleString()}` };
};

// دالة لتنظيف كائن المستخدم قبل الحفظ لتجنب أخطاء JSON Circular
const sanitizeUserForStorage = (user: User): User => {
  return {
    Id_user: user.Id_user,
    'id-2': user['id-2'],
    UserData: user.UserData,
    photoURL: user.photoURL,
    accountType: user.accountType,
    gender: user.gender,
    country: user.country,
    birthDate: user.birthDate,
    bio: user.bio,
    // نحفظ البيانات الأساسية فقط للواجهة
    Contrôler: "", 
    Freechat: "", Freechat_unlock: "",
    Freepublishing: "", Freepublishing_unlock: "",
    Freeaccount: "", Freeaccount_unlock: ""
  };
};

const AppInner: React.FC = () => {
  const { t, dir, isRtl } = useLanguage();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [view, setView] = useState<'loading' | 'picker' | 'auth' | 'chat'>('loading');
  const [savedAccounts, setSavedAccounts] = useState<User[]>([]);
  
  // Appeal State
  const [showAppealModal, setShowAppealModal] = useState(false);
  const [appealType, setAppealType] = useState<'innocent' | 'apology' | null>(null);
  const [isSubmittingAppeal, setIsSubmittingAppeal] = useState(false);

  useEffect(() => {
    const activeId = localStorage.getItem('teblock_active_id');
    try {
      const accounts = JSON.parse(localStorage.getItem('teblock_multi_accounts') || '[]');
      setSavedAccounts(accounts);
      
      if (activeId) {
        syncUser(activeId);
      } else if (accounts.length > 0) {
        setView('picker');
      } else {
        setView('auth');
      }
    } catch (e) {
      console.error("Storage Error:", e);
      localStorage.removeItem('teblock_multi_accounts');
      setView('auth');
    }
  }, []);

  const saveAccountLocally = (user: User) => {
    try {
      const cleanUser = sanitizeUserForStorage(user);
      setSavedAccounts(prev => {
        const existing = prev.filter(u => u.Id_user !== user.Id_user);
        const newAccounts = [cleanUser, ...existing];
        localStorage.setItem('teblock_multi_accounts', JSON.stringify(newAccounts));
        return newAccounts;
      });
    } catch (e) {
      console.error("Failed to save account locally", e);
    }
  };

  const handleAuthSuccess = (user: User) => {
    localStorage.setItem('teblock_active_id', user.Id_user);
    saveAccountLocally(user); // حفظ الحساب في القائمة
    syncUser(user.Id_user);
  };

  const syncUser = (userId: string) => {
    setView('loading');
    return onSnapshot(doc(db, 'users', userId), (docSnap) => {
      if (docSnap.exists()) {
        const freshData = docSnap.data() as User;
        if (!freshData['id-2']) {
          const generatedId2 = generatePermanentId2();
          updateDoc(doc(db, 'users', userId), { 'id-2': generatedId2 }).catch(console.error);
          freshData['id-2'] = generatedId2;
        }
        setCurrentUser(freshData);
        setView('chat');
        // تحديث المعلومات المحلية في الخلفية
        saveAccountLocally(freshData);
      } else {
        // الحساب غير موجود في قاعدة البيانات
        handleLogout();
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${userId}`);
      handleLogout();
    });
  };

  const handleLogout = () => {
    localStorage.removeItem('teblock_active_id');
    setCurrentUser(null);
    setView(savedAccounts.length > 0 ? 'picker' : 'auth');
  };

  const submitAppeal = async () => {
    if (!currentUser || !appealType || isSubmittingAppeal) return;
    setIsSubmittingAppeal(true);
    try {
      await addDoc(collection(db, 'appeals'), {
        userId: currentUser.Id_user,
        userName: currentUser.UserData,
        userPhoto: currentUser.photoURL || "",
        restrictionType: 'account',
        reason: appealType,
        timestamp: serverTimestamp(),
        status: 'pending'
      });

      await updateDoc(doc(db, 'users', currentUser.Id_user), {
        hasAppealed: true
      });

      alert(t('chat.appealSuccessTitle'));
      setShowAppealModal(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'appeals or users');
      alert(t('common.error'));
    } finally {
      setIsSubmittingAppeal(false);
    }
  };

  const handleRemoveAccount = (userId: string) => {
    setSavedAccounts(prev => {
      const newAccounts = prev.filter(u => u.Id_user !== userId);
      localStorage.setItem('teblock_multi_accounts', JSON.stringify(newAccounts));
      if (newAccounts.length === 0) setView('auth');
      return newAccounts;
    });
  };

  if (view === 'loading') return <div className="min-h-screen bg-[var(--teblock-bg)] flex items-center justify-center animate-pulse text-blue-500 font-black tracking-[0.5em]">TeBLOCK...</div>;

  // شاشة حظر الحساب بالكامل
  if (currentUser) {
    const accCheck = checkAccess(currentUser.Freeaccount, currentUser.Freeaccount_unlock);
    if (!accCheck.allowed) {
      const handleUnlock = async () => {
        if (confirm(t('settings.unlockConfirm'))) {
          try {
            await updateDoc(doc(db, 'users', currentUser.Id_user), {
              Freeaccount: "يوجد",
              Freeaccount_unlock: ""
            });
          } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, `users/${currentUser.Id_user}`);
          }
        }
      };

      return (
        <div className="min-h-screen bg-[#1a0505] flex items-center justify-center p-6 text-center relative overflow-hidden">
          <div className="max-w-md w-full glass border-red-500/30 p-12 rounded-[3rem] shadow-[0_0_50px_rgba(239,68,68,0.2)] relative z-10">
            <div className="w-24 h-24 bg-red-600 rounded-[2rem] mx-auto mb-8 flex items-center justify-center shadow-2xl shadow-red-600/30 animate-bounce">
              <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" strokeWidth={2.5}/></svg>
            </div>
            <h1 className="text-3xl font-black text-white mb-2 uppercase tracking-tighter">
              {(accCheck as any).isLocked ? 'ACCOUNT LOCKED' : 'ACCESS DENIED'}
            </h1>
            <p className="text-red-500/60 text-[10px] font-black uppercase tracking-[0.4em] mb-8">Security Protocol Active</p>
            
            <p className="text-red-300 text-sm font-bold mb-10 leading-relaxed bg-red-950/30 p-6 rounded-3xl border border-red-500/10">
              {(accCheck as any).key ? t((accCheck as any).key, (accCheck as any).fallback) : accCheck.message}
            </p>

            <div className="space-y-3">
              {(accCheck as any).isLocked ? (
                <button 
                  onClick={handleUnlock} 
                  className="w-full py-4 bg-green-600 text-white rounded-2xl font-black text-xs hover:bg-green-500 transition-all shadow-lg shadow-green-600/20"
                >
                  {t('settings.unlockAccountBtn')}
                </button>
              ) : !currentUser.hasAppealed ? (
                <button 
                  onClick={() => setShowAppealModal(true)} 
                  className="w-full py-4 bg-red-600 text-white rounded-2xl font-black text-xs hover:bg-red-500 transition-all shadow-lg shadow-red-600/20"
                >
                  {t('publish.appealTitle') || 'Appeal'}
                </button>
              ) : (
                <div className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl text-slate-400 font-bold text-xs">
                  {t('chat.reportSent')}
                </div>
              )}

              <button onClick={handleLogout} className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl text-slate-400 font-black text-xs hover:bg-white/10 transition-all uppercase tracking-widest">
                {t('auth.logout')}
              </button>
            </div>
          </div>

          {showAppealModal && (
            <div dir={dir} className="absolute inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-6 animate-in zoom-in">
              <div className="w-full max-w-sm glass bg-slate-900 border border-white/10 p-8 rounded-[2.5rem] rtl:text-right ltr:text-left">
                <h3 className="text-xl font-black text-white mb-6 text-center">{t('publish.appealTitle')}</h3>
                <p className="text-xs text-slate-400 mb-6 text-center leading-relaxed">{t('publish.restrictedTitle')}</p>
                
                <div className="space-y-3 mb-8">
                  <button 
                    onClick={() => setAppealType('innocent')}
                    className={`w-full p-4 rounded-2xl border text-xs font-bold transition-all flex items-center justify-between ${appealType === 'innocent' ? 'bg-blue-600 border-blue-600 text-white' : 'bg-black/20 border-white/5 text-slate-300'}`}
                  >
                    <span>{t('publish.appealReasonInnocent')}</span>
                    {appealType === 'innocent' && <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>}
                  </button>
                  
                  <button 
                    onClick={() => setAppealType('apology')}
                    className={`w-full p-4 rounded-2xl border text-xs font-bold transition-all flex items-center justify-between ${appealType === 'apology' ? 'bg-blue-600 border-blue-600 text-white' : 'bg-black/20 border-white/5 text-slate-300'}`}
                  >
                    <span>{t('publish.appealReasonApology')}</span>
                    {appealType === 'apology' && <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>}
                  </button>
                </div>

                <div className="flex gap-3">
                  <button 
                    onClick={submitAppeal} 
                    disabled={!appealType || isSubmittingAppeal}
                    className="flex-1 bg-white text-black font-black py-3 rounded-xl disabled:opacity-50"
                  >
                    {isSubmittingAppeal ? '...' : t('publish.submitAppealBtn')}
                  </button>
                  <button 
                    onClick={() => setShowAppealModal(false)} 
                    className="px-6 py-3 bg-white/5 rounded-xl text-white font-bold"
                  >
                    {t('common.cancel')}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    }
  }

  return (
    <div dir={dir} className="fixed inset-0 w-full h-full bg-[var(--teblock-bg)] flex items-center justify-center overflow-hidden">
      {view === 'picker' && (
        <div className="w-full h-full overflow-y-auto custom-scrollbar flex items-start sm:items-center justify-center p-3 sm:p-6 animate-in fade-in duration-500">
          <AccountPicker 
            accounts={savedAccounts} 
            onSelect={(u) => { localStorage.setItem('teblock_active_id', u.Id_user); syncUser(u.Id_user); }} 
            onRemove={handleRemoveAccount}
            onAddNew={() => setView('auth')} 
          />
        </div>
      )}
      {view === 'auth' && (
        <div className="w-full h-full overflow-y-auto custom-scrollbar flex items-start sm:items-center justify-center p-3 sm:p-6 animate-in fade-in duration-500">
          <AuthForm 
            onAuthSuccess={handleAuthSuccess} 
            onBackToPicker={savedAccounts.length > 0 ? () => setView('picker') : undefined}
          />
        </div>
      )}
      {view === 'chat' && currentUser && (
        <ChatContainer 
          user={currentUser} 
          onLogout={handleLogout} 
          onSwitchAccount={(uid) => {
            localStorage.setItem('teblock_active_id', uid);
            syncUser(uid);
          }}
        />
      )}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <AppInner />
    </LanguageProvider>
  );
};

export default App;
