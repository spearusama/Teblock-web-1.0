import re

# Fix Giphy/Tenor in NotesSystem.tsx
with open('components/NotesSystem.tsx', 'r') as f:
    notes_content = f.read()

notes_old = """    try {
      const url = q.trim() 
        ? `/api/gifs?q=${encodeURIComponent(q)}`
        : `/api/gifs`;
        
      const response = await fetch(url);
      const data = await response.json();
      setGifResults(data.results ? data.results.map((item: any) => item.media[0].gif.url) : []);"""

notes_new = """    try {
      const apiKey = "LIVDSRZULELA"; // Public Tenor API Key
      const limit = 20;
      const url = q.trim() 
        ? `https://g.tenor.com/v1/search?q=${encodeURIComponent(q)}&key=${apiKey}&limit=${limit}`
        : `https://g.tenor.com/v1/trending?key=${apiKey}&limit=${limit}`;
        
      const response = await fetch(url);
      const data = await response.json();
      setGifResults(data.results ? data.results.map((item: any) => item.media[0].gif.url) : []);"""

notes_content = notes_content.replace(notes_old, notes_new)
with open('components/NotesSystem.tsx', 'w') as f:
    f.write(notes_content)


# Fix Music and AI in PublishModal.tsx
with open('components/PublishModal.tsx', 'r') as f:
    publish_content = f.read()

music_old = """      try {
        const res = await fetch(`/api/music/search?q=${encodeURIComponent(musicSearch)}`);
        const data = await res.json();
        setMusicResults(data.results || []);
      } catch (e) {"""

music_new = """      try {
        const res = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(musicSearch)}&entity=song&limit=15`);
        const data = await res.json();
        const results = (data.results || []).map((v: any) => ({
          id: v.trackId.toString(),
          name: v.trackName,
          artist: v.artistName,
          cover: v.artworkUrl100?.replace('100x100', '500x500') || '',
          previewUrl: v.previewUrl,
          duration: Math.floor((v.trackTimeMillis || 0) / 1000)
        })).filter((v: any) => v.previewUrl);
        setMusicResults(results);
      } catch (e) {"""

publish_content = publish_content.replace(music_old, music_new)

ai_old = """      try {
        if (caption) {
          const analyzeRes = await fetch('/api/reel/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ caption })
          });
          const analyzeData = await analyzeRes.json();
          keywords = analyzeData.keywords || [];
        }
      } catch (e) {
        console.error("Failed to analyze keywords", e);
      }"""

ai_new = """      try {
        if (caption) {
          // Client-side fallback for keywords extraction
          const stopWords = ['في', 'من', 'على', 'إلى', 'عن', 'مع', 'هذا', 'هذه', 'و', 'أو', 'لا', 'نعم', 'أن', 'هل'];
          const words = caption.split(/[\s،,.]+/).filter((w: string) => w.length > 2 && !stopWords.includes(w));
          keywords = Array.from(new Set(words)).slice(0, 5);
        }
      } catch (e) {
        console.error("Failed to analyze keywords", e);
      }"""

publish_content = publish_content.replace(ai_old, ai_new)

with open('components/PublishModal.tsx', 'w') as f:
    f.write(publish_content)

