import re

with open('server.ts', 'r') as f:
    content = f.read()

# Add the import
content = content.replace('import axios from "axios";', 'import axios from "axios";\nimport { GoogleGenAI, Type } from "@google/genai";')

# Add the new endpoint before app.post("/api/log-activity"
new_endpoint = """
  app.post("/api/reel/analyze", async (req, res) => {
    try {
      const { caption } = req.body;
      if (!caption) return res.json({ keywords: [] });
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `استخرج 5 كلمات مفتاحية (باللغة العربية) من هذا الوصف لمقطع فيديو لاستخدامها في خوارزمية التوصيات. الوصف: "${caption}". أرجع الإجابة كمصفوفة JSON من السلاسل النصية فقط.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        }
      });
      res.json({ keywords: JSON.parse(response.text || "[]") });
    } catch (e) {
      console.error("Gemini Analysis Error:", e);
      res.json({ keywords: [] });
    }
  });

"""

content = content.replace('  // API: Log Activity', new_endpoint + '  // API: Log Activity')

with open('server.ts', 'w') as f:
    f.write(content)

