import re

with open('components/AIChatView.tsx', 'r') as f:
    content = f.read()

# We need to add a check in send message functions to see if user is muted
mute_check_code = """
  const checkMute = (): boolean => {
    if (user.messagingRestrictedForever) {
      alert("حسابك مقيد من المراسلة نهائياً بسبب انتهاك السياسات.");
      return true;
    }
    if (user.messagingRestrictionUntil && user.messagingRestrictionUntil > Date.now()) {
      const remainingHours = Math.ceil((user.messagingRestrictionUntil - Date.now()) / (1000 * 60 * 60));
      alert(`حسابك مقيد من المراسلة مؤقتاً. يرجى المحاولة بعد ${remainingHours} ساعة.`);
      return true;
    }
    return false;
  };
"""

# Insert mute_check_code inside AIChatView component, before sendMessage
content = content.replace("  const sendMessage = async () => {", mute_check_code + "\n  const sendMessage = async () => {")

# Add mute check to sendMessage
send_msg_old = """  const sendMessage = async () => {
    if ((!inputMessage.trim() && !replyTo) || !activeChat) return;"""
send_msg_new = """  const sendMessage = async () => {
    if (checkMute()) return;
    if ((!inputMessage.trim() && !replyTo) && !quickEmoji || !activeChat) return;"""
content = content.replace(send_msg_old, send_msg_new)
content = content.replace("if ((!inputMessage.trim() && !replyTo) || !activeChat) return;", "if (checkMute()) return;\n    if ((!inputMessage.trim() && !replyTo) && !quickEmoji || !activeChat) return;")

# Add mute check to handleEmojiSelect
emoji_old = """  const handleEmojiSelect = async (emoji: string) => {
    if (emojiTarget === 'input') {"""
emoji_new = """  const handleEmojiSelect = async (emoji: string) => {
    if (checkMute()) return;
    if (emojiTarget === 'input') {"""
content = content.replace(emoji_old, emoji_new)

# Add mute check to handleFileUpload
file_old = """  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeChat) return;"""
file_new = """  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (checkMute()) return;
    const file = e.target.files?.[0];
    if (!file || !activeChat) return;"""
content = content.replace(file_old, file_new)

# Add mute check to startRecording
mic_old = """  const startRecording = async () => {
    try {"""
mic_new = """  const startRecording = async () => {
    if (checkMute()) return;
    try {"""
content = content.replace(mic_old, mic_new)

# Add mute check to sendGif
gif_old = """  const sendGif = async (gifUrl: string) => {
    if (!activeChat) return;"""
gif_new = """  const sendGif = async (gifUrl: string) => {
    if (checkMute()) return;
    if (!activeChat) return;"""
content = content.replace(gif_old, gif_new)


with open('components/AIChatView.tsx', 'w') as f:
    f.write(content)
