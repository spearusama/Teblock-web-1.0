import re

with open('components/ReelsView.tsx', 'r') as f:
    content = f.read()

badge_html = """          <ReelItem
            reel={reel}
            isActive={activeReelId === reel.id}
            isMuted={isMuted}
            onDoubleTap={toggleLike}
          />
          {((reel as any).matchPercentage || 0) > 0 && (
            <div className="absolute top-6 left-6 z-50">
              <div className="bg-blue-600/90 backdrop-blur-md border border-blue-400/30 px-4 py-2 rounded-2xl shadow-lg shadow-blue-500/20 flex items-center space-x-2 space-x-reverse">
                 <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                 <span className="text-xs font-black text-white">{Math.min(100, (reel as any).matchPercentage)}% تطابق</span>
              </div>
            </div>
          )}
"""

content = content.replace("""          <ReelItem
            reel={reel}
            isActive={activeReelId === reel.id}
            isMuted={isMuted}
            onDoubleTap={toggleLike}
          />""", badge_html)

with open('components/ReelsView.tsx', 'w') as f:
    f.write(content)

