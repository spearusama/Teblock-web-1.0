import re

with open('components/ReelsView.tsx', 'r') as f:
    content = f.read()

report_old = """  const handleReport = async (reelId: string) => {
    alert('تم الإبلاغ عن هذا الريلز. سنقوم بمراجعته.');
    setMenuId(null);
  };"""

report_new = """  const handleReport = async (reelId: string) => {
    try {
      await addDoc(collection(db, 'reports'), {
        reelId,
        reportedBy: user.Id_user,
        type: 'reel_report',
        timestamp: serverTimestamp()
      });
      alert('تم الإبلاغ عن هذا الريلز. سنقوم بمراجعته.');
    } catch (e) {
      alert("حدث خطأ أثناء الإبلاغ");
    }
    setMenuId(null);
  };"""

content = content.replace(report_old, report_new)

with open('components/ReelsView.tsx', 'w') as f:
    f.write(content)
