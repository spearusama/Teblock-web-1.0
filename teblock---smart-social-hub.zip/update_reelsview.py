import re

with open('components/ReelsView.tsx', 'r') as f:
    content = f.read()

like_logic = """  const toggleLike = async (reel: Reel) => {
    const ref = doc(db, 'reels', reel.id);
    const isLiked = reel.likes.includes(user.Id_user);
    await updateDoc(ref, { likes: isLiked ? arrayRemove(user.Id_user) : arrayUnion(user.Id_user) });

    // Update user interests based on keywords
    if (!isLiked && reel.keywords && reel.keywords.length > 0) {
      const currentVector = user.interestVector || {};
      const newVector = { ...currentVector };
      reel.keywords.forEach(kw => {
        newVector[kw] = (newVector[kw] || 0) + 1; // Increase weight
      });
      await updateDoc(doc(db, 'users', user.Id_user), { interestVector: newVector });
    }

    if (!isLiked && reel.userId !== user.Id_user) {"""

content = content.replace("""  const toggleLike = async (reel: Reel) => {
    const ref = doc(db, 'reels', reel.id);
    const isLiked = reel.likes.includes(user.Id_user);
    await updateDoc(ref, { likes: isLiked ? arrayRemove(user.Id_user) : arrayUnion(user.Id_user) });

    if (!isLiked && reel.userId !== user.Id_user) {""", like_logic)

save_logic = """  const toggleSave = async (reelId: string, reel: Reel) => {
    const isSaved = savedReels.includes(reelId);
    const updated = isSaved ? savedReels.filter(id => id !== reelId) : [...savedReels, reelId];
    setSavedReels(updated);
    await updateDoc(doc(db, 'users', user.Id_user), { savedReels: updated });

    // Update user interests on save
    if (!isSaved && reel.keywords && reel.keywords.length > 0) {
      const currentVector = user.interestVector || {};
      const newVector = { ...currentVector };
      reel.keywords.forEach(kw => {
        newVector[kw] = (newVector[kw] || 0) + 2; // Save gives higher weight (2)
      });
      await updateDoc(doc(db, 'users', user.Id_user), { interestVector: newVector });
    }
  };"""

content = re.sub(
    r'  const toggleSave = async \(reelId: string\) => \{.*?await updateDoc\(doc\(db, \'users\', user\.Id_user\), \{ savedReels: updated \}\);\n  \};',
    save_logic,
    content,
    flags=re.DOTALL
)

# We also need to change the call to toggleSave to pass `reel`
content = content.replace('toggleSave(reel.id)', 'toggleSave(reel.id, reel)')

with open('components/ReelsView.tsx', 'w') as f:
    f.write(content)

