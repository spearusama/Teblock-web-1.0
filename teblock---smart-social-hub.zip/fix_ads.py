import re

with open('components/AIChatView.tsx', 'r') as f:
    chat_content = f.read()

chat_old = """                 {(index + 1) % 8 === 0 && (
                   <div 
                      onClick={() => window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank')}
                      className="flex items-center p-4 bg-blue-500/10 border border-blue-500/20 rounded-[2.2rem] hover:bg-blue-500/20 transition-all cursor-pointer relative overflow-hidden"
                   >
                      <div className="absolute top-0 right-0 bg-blue-600 text-white text-[8px] font-black px-2 py-0.5 rounded-bl-lg">إعلان ممول</div>
                      <div className="relative ml-4">
                        <div className="w-12 h-12 rounded-2xl bg-blue-600/30 border border-blue-500/30 flex items-center justify-center">
                           <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11 19l-7-7 7-7m8 14l-7-7 7-7"/></svg>
                        </div>
                      </div>
                      <div className="flex-1 text-right overflow-hidden">
                         <div className="flex justify-between items-center mb-1">
                            <span className="text-[8px] text-blue-400 font-bold">الآن</span>
                            <h4 className="text-[11px] font-black text-blue-400">عروض مميزة</h4>
                         </div>
                         <p className="text-[10px] text-blue-300/80 truncate font-bold">اكتشف أحدث العروض والخدمات عبر شريكنا الإعلاني</p>
                      </div>
                   </div>
                 )}"""

chat_new = """                 {(index + 1) % 8 === 0 && (
                   <div 
                      onClick={() => window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank')}
                      className="flex items-center p-4 bg-white/[0.02] border border-blue-500/30 rounded-[2.2rem] hover:bg-white/[0.05] transition-all cursor-pointer relative overflow-hidden"
                   >
                      <div className="absolute top-0 right-0 bg-blue-600 text-white text-[8px] font-black px-2 py-0.5 rounded-bl-lg z-10">إعلان ممول</div>
                      <div className="relative ml-4">
                        <img src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=150&h=150&fit=crop" className="w-12 h-12 rounded-2xl border border-white/10 object-cover" alt="Ad" />
                      </div>
                      <div className="flex-1 text-right overflow-hidden">
                         <div className="flex justify-between items-center mb-1">
                            <span className="text-[8px] text-blue-400 font-bold">إعلان</span>
                            <h4 className="text-[11px] font-black text-blue-400">تطبيق جديد وحصري</h4>
                         </div>
                         <p className="text-[10px] text-slate-400 truncate font-bold">قم بتجربة أحدث الخدمات الآن مجاناً، اضغط هنا للمزيد.</p>
                      </div>
                   </div>
                 )}"""

chat_content = chat_content.replace(chat_old, chat_new)
with open('components/AIChatView.tsx', 'w') as f:
    f.write(chat_content)


with open('components/ReelsView.tsx', 'r') as f:
    reels_content = f.read()

reels_old = """        {(index + 1) % 5 === 0 && (
            <div className="h-full w-full snap-start snap-always relative flex flex-col items-center justify-center bg-slate-900 border-t border-b border-white/5 overflow-hidden">
               <div className="absolute inset-0 bg-gradient-to-b from-blue-900/40 to-slate-900 z-0 pointer-events-none"></div>
               <div className="z-10 flex flex-col items-center justify-center flex-1 w-full p-8 text-center mt-20">
                  <div className="w-24 h-24 bg-blue-600/20 rounded-full flex items-center justify-center mb-8 border border-blue-500/20 shadow-2xl shadow-blue-500/20">
                     <svg className="w-12 h-12 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7"/></svg>
                  </div>
                  <h3 className="text-3xl font-black text-white mb-4 uppercase tracking-wider">إعلان ممول</h3>
                  <p className="text-blue-200/80 text-sm leading-relaxed max-w-xs mx-auto font-bold">اكتشف أحدث العروض والخدمات المخصصة لك عبر شريكنا الإعلاني.</p>
               </div>
               <div className="z-10 w-full p-6 pb-24 shrink-0">
                   <button onClick={() => window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank')} className="w-full py-4 bg-blue-600 rounded-[2rem] font-black text-white shadow-lg shadow-blue-600/30 flex items-center justify-center space-x-2 space-x-reverse active:scale-95 transition-all text-lg hover:bg-blue-500">
                      <span>فتح الإعلان</span>
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                   </button>
               </div>
            </div>
        )}"""

reels_new = """        {(index + 1) % 5 === 0 && (
            <div className="h-full w-full snap-start snap-always relative flex flex-col items-center justify-center bg-black overflow-hidden group cursor-pointer" onClick={() => window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank')}>
               <video src="https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4" autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-500" />
               <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/90 pointer-events-none"></div>
               
               <div className="absolute top-6 right-6 z-50">
                  <div className="bg-blue-600 text-white text-[10px] font-black px-3 py-1.5 rounded-lg shadow-lg uppercase tracking-wider">
                     إعلان ممول
                  </div>
               </div>

               <div className="z-10 absolute bottom-32 left-4 right-20 text-right pointer-events-none">
                  <h3 className="text-2xl font-black text-white mb-2 drop-shadow-lg">عرض خاص وحصري</h3>
                  <p className="text-white/90 text-sm font-bold leading-relaxed drop-shadow-md">استفد من هذا العرض الرائع لفترة محدودة، تجربة فريدة بانتظارك الآن.</p>
               </div>

               <div className="z-20 absolute bottom-6 w-full px-6 shrink-0">
                   <button onClick={(e) => { e.stopPropagation(); window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank'); }} className="w-full py-4 bg-blue-600 rounded-[2rem] font-black text-white shadow-lg shadow-blue-600/30 flex items-center justify-center space-x-2 space-x-reverse active:scale-95 transition-all text-lg hover:bg-blue-500 hover:shadow-blue-500/40">
                      <span>فتح الرابط الآن</span>
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                   </button>
               </div>
            </div>
        )}"""

reels_content = reels_content.replace(reels_old, reels_new)
with open('components/ReelsView.tsx', 'w') as f:
    f.write(reels_content)

