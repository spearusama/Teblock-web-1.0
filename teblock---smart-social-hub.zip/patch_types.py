import re

with open('types.ts', 'r') as f:
    content = f.read()

content = content.replace("  savedReels?: string[];\n}", "  savedReels?: string[];\n  isDeveloper?: boolean;\n  messagingRestrictionUntil?: number;\n  messagingRestrictedForever?: boolean;\n}")

with open('types.ts', 'w') as f:
    f.write(content)
