with open('components/ChatContainer.tsx', 'r') as f:
    content = f.read()

if "import { AdminReportsView }" not in content:
    content = "import { AdminReportsView } from './AdminReportsView';\n" + content

with open('components/ChatContainer.tsx', 'w') as f:
    f.write(content)
