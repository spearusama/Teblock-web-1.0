sed -i '1s/.*/import React, { useState, useEffect } from '"'"'react'"'"';/' components/AuthForm.tsx
