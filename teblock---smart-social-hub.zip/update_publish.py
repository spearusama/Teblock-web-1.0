import re

with open('components/PublishModal.tsx', 'r') as f:
    content = f.read()

upload_logic = """
      let keywords: string[] = [];
      try {
        if (caption) {
          const analyzeRes = await fetch('/api/reel/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ caption })
          });
          const analyzeData = await analyzeRes.json();
          keywords = analyzeData.keywords || [];
        }
      } catch (e) {
        console.error("Failed to analyze keywords", e);
      }

      await addDoc(collection(db, 'reels'), {
        userId: user.Id_user,
        userName: user.UserData,
        userPhoto: user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.Id_user}`,
        videoUrl: primaryVideoUrl || mediaUrls[0].url,
        mediaUrls: mediaUrls,
        musicTrack: selectedSong ? { ...selectedSong, clipStart } : null,
        caption: encryptText(caption || ""),
        keywords: keywords,
        likes: [],
"""

content = content.replace("""      await addDoc(collection(db, 'reels'), {
        userId: user.Id_user,
        userName: user.UserData,
        userPhoto: user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.Id_user}`,
        videoUrl: primaryVideoUrl || mediaUrls[0].url,
        mediaUrls: mediaUrls,
        musicTrack: selectedSong ? { ...selectedSong, clipStart } : null,
        caption: encryptText(caption || ""),
        likes: [],""", upload_logic)

with open('components/PublishModal.tsx', 'w') as f:
    f.write(content)

