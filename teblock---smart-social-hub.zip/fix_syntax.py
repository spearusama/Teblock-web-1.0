import re

with open('components/ReelsView.tsx', 'r') as f:
    content = f.read()

content = content.replace("import { AdComponent } from './AdComponent';\\nimport React", "import { AdComponent } from './AdComponent';\nimport React")

with open('components/ReelsView.tsx', 'w') as f:
    f.write(content)

with open('components/AIChatView.tsx', 'r') as f:
    content = f.read()

content = content.replace("import { AdComponent } from './AdComponent';\\nimport React", "import { AdComponent } from './AdComponent';\nimport React")

with open('components/AIChatView.tsx', 'w') as f:
    f.write(content)
