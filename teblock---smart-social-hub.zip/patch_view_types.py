import re

with open('components/ChatContainer.tsx', 'r') as f:
    content = f.read()

view_type_old = "  const [currentView, setCurrentView] = useState<'chats' | 'reels' | 'notifications' | 'search' | 'profile' | 'settings'>(() => {"
view_type_new = "  const [currentView, setCurrentView] = useState<'chats' | 'reels' | 'notifications' | 'search' | 'profile' | 'settings' | 'menu' | 'admin_reports'>(() => {"

content = content.replace(view_type_old, view_type_new)

with open('components/ChatContainer.tsx', 'w') as f:
    f.write(content)
