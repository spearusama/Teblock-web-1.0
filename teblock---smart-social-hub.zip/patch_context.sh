sed -i '1341i \
    soundManager.playLongPressSound();\
' components/AIChatView.tsx
sed -i 's/setEditingMessage(contextMenu.message);/soundManager.playEditSound(); setEditingMessage(contextMenu.message);/g' components/AIChatView.tsx
sed -i 's/await updateDoc(doc(db, '"'"'messages'"'"', contextMenu.message.id), { deletedFor: arrayUnion(user.Id_user) });/soundManager.playDeleteSound(); await updateDoc(doc(db, '"'"'messages'"'"', contextMenu.message.id), { deletedFor: arrayUnion(user.Id_user) });/g' components/AIChatView.tsx
sed -i 's/await deleteDoc(doc(db, '"'"'messages'"'"', contextMenu.message.id));/soundManager.playDeleteSound(); await deleteDoc(doc(db, '"'"'messages'"'"', contextMenu.message.id));/g' components/AIChatView.tsx
