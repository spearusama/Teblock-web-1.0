import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

import axios from "axios";
import { GoogleGenAI, Type } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());


  app.get("/api/gifs", async (req, res) => {
    try {
      const q = req.query.q as string;
      const apiKey = "LIVDSRZULELA";
      const limit = 20;
      const url = q && q.trim() 
        ? `https://g.tenor.com/v1/search?q=${encodeURIComponent(q)}&key=${apiKey}&limit=${limit}`
        : `https://g.tenor.com/v1/trending?key=${apiKey}&limit=${limit}`;
      
      const response = await axios.get(url);
      res.json(response.data);
    } catch (error) {
      console.error("GIF Search Error:", error);
      res.status(500).json({ results: [] });
    }
  });


  const getGeminiApiKey = () => {
    // Prioritize user-provided secret names: Gemin, gemin, gemini, GEMINI, followed by standard keys and fallback key
    return (
      process.env.Gemin ||
      process.env.gemin ||
      process.env.gemini ||
      process.env.GEMINI ||
      process.env.GEMINI_API_KEY ||
      process.env.API_KEY ||
      "AQ.Ab8RN6K5Mrn8JdZ4ziYKYNIEtgDSFhyifgmPMGybCDJW6Qlf_Q"
    );
  };

  app.post("/api/gemini/chat", async (req, res) => {
    try {
      const { userMessage, userName, history } = req.body;
      const apiKey = getGeminiApiKey();
      if (!apiKey) {
        return res.status(500).json({ error: "مفتاح الذكاء الاصطناعي (API Key) غير معرف في النظام." });
      }

      const ai = new GoogleGenAI({ 
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });

      const contents = (history || []).map((msg: any) => ({
        role: msg.role === 'model' ? 'model' : 'user',
        parts: [{ text: msg.text }]
      }));
      contents.push({
        role: 'user',
        parts: [{ text: userMessage }]
      });

      const systemInstruction = `أنت "TeBLOCK AI"، مساعد ذكي ومتطور في منصة TEBLOCK الاجتماعية. أنت تتحدث الآن مع "${userName || 'المستخدم'}". 
تحدث بشكل طبيعي، ودي، وتلقائي كصديق حقيقي. تجنب تماماً العبارات المتكررة أو الرسمية الزائدة. 
أنت تدرك تماماً أنك ذكاء اصطناعي مدمج في تيبلوك (Teblock). 
قواعد هامة قبل الرد:
1. راجع الرسائل السابقة في المحادثة بعناية قبل أن تكتب أي كلمة: افهم ما هو الموضوع الذي يتحدث عنه المستخدمون، وحدد هل نبرة الكلام مزاح وضحك أم نقاش جدي ورسمي أم استفسار تقني/شخصي.
2. كيّف أسلوبك تماماً مع جو المحادثة: إذا كان الكلام مزاحاً فكن خفيف الظل ومرحاً معهم، وإذا كان جدياً فكن متزناً ومحترماً ومفيداً ومباشراً.
3. اجعل إجاباتك ذكية، منتقاة بعناية، ومبنية على سياق المحادثة السابق.
4. استخدم الرموز التعبيرية (Emojis) بشكل مناسب لجعل المحادثة ممتعة.
5. يجب أن تكون إجابتك موجزة ومركزة دائماً بحدود 320 إلى 500 توكن كحد أقصى أو أقل (بين 80 إلى 150 كلمة)، بدون إطالة أو حشو غير لازم.`;

      let responseText = "";
      const modelsToTry = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];
      let lastError: any = null;

      for (const modelName of modelsToTry) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents,
            config: { 
              systemInstruction,
              maxOutputTokens: 500
            }
          });
          responseText = response.text || "";
          if (responseText) break;
        } catch (err: any) {
          lastError = err;
          console.warn(`Model ${modelName} failed, trying next:`, err?.message);
        }
      }

      if (!responseText && lastError) {
        throw lastError;
      }

      res.json({ text: responseText });
    } catch (err: any) {
      console.error("Gemini Chat API Error:", err);
      res.status(500).json({ error: err.message || "حدث خطأ أثناء الاتصال بالذكاء الاصطناعي" });
    }
  });

  app.post("/api/reel/analyze", async (req, res) => {
    try {
      const { caption } = req.body;
      if (!caption) return res.json({ keywords: [] });
      const apiKey = getGeminiApiKey();
      if (!apiKey) return res.json({ keywords: [] });
      const ai = new GoogleGenAI({ 
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `استخرج 5 كلمات مفتاحية (باللغة العربية) من هذا الوصف لمقطع فيديو لاستخدامها في خوارزمية التوصيات. الوصف: "${caption}". أرجع الإجابة كمصفوفة JSON من السلاسل النصية فقط.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        }
      });
      res.json({ keywords: JSON.parse(response.text || "[]") });
    } catch (e) {
      console.error("Gemini Analysis Error:", e);
      res.json({ keywords: [] });
    }
  });

  // In-memory developer & system logs
  interface LogEntry {
    id: number;
    event: string;
    detail: string;
    time: string;
  }
  const activityLogs: LogEntry[] = [
    {
      id: Date.now(),
      event: 'SYSTEM_READY',
      detail: 'Developer diagnostics and system monitoring initialized successfully.',
      time: new Date().toISOString()
    }
  ];

  // API: Log Activity
  app.post("/api/log-activity", (req, res) => {
    const entry: LogEntry = {
      id: Date.now() + Math.floor(Math.random() * 1000),
      event: req.body?.event || 'USER_ACTIVITY',
      detail: typeof req.body?.detail === 'string' ? req.body.detail : JSON.stringify(req.body || {}),
      time: new Date().toISOString()
    };
    activityLogs.unshift(entry);
    if (activityLogs.length > 100) activityLogs.pop();
    console.log("[ACTIVITY_LOG]:", entry);
    res.json({ status: "logged", entry });
  });

  // API: Retrieve Logs
  app.get("/api/logs", (req, res) => {
    res.json({ logs: activityLogs });
  });

  // API: Temporary Client IP detection for P2P direct calling
  app.get("/api/client-ip", (req, res) => {
    const forwarded = req.headers["x-forwarded-for"];
    let ip = typeof forwarded === "string" ? forwarded.split(",")[0].trim() : req.socket.remoteAddress || "127.0.0.1";
    // Clean IPv6 IPv4-mapped prefix (e.g., ::ffff:192.168.1.1)
    ip = ip.replace(/^.*:/, "");
    res.json({ ip: ip || "127.0.0.1" });
  });

  // API: Cloudinary Connectivity & Diagnostic Check
  app.get("/api/developer/cloudinary-ping", async (req, res) => {
    try {
      const cloudName = "dei75gqcl";
      const start = Date.now();
      const checkRes = await axios.get(`https://res.cloudinary.com/${cloudName}/image/upload/sample.jpg`, {
        timeout: 5000,
        validateStatus: () => true
      });
      const latency = Date.now() - start;
      res.json({
        success: checkRes.status < 500,
        cloudName,
        status: checkRes.status,
        latencyMs: latency,
        timestamp: new Date().toISOString()
      });
    } catch (err: any) {
      res.json({
        success: false,
        cloudName: "dei75gqcl",
        error: err.message,
        timestamp: new Date().toISOString()
      });
    }
  });

  // In-memory cache for probed media sizes to avoid duplicate network calls
  const mediaSizeCache = new Map<string, number>();

  // API: Measure Exact Real File Sizes via HTTP Range Requests (Cloudinary live probe)
  app.post("/api/measure-video-urls", async (req, res) => {
    try {
      const { urls } = req.body;
      if (!Array.isArray(urls)) {
        return res.status(400).json({ error: "urls array required" });
      }

      const results: Record<string, { bytes: number; mb: number; formatted: string }> = {};

      await Promise.all(
        urls.slice(0, 30).map(async (u: string) => {
          if (!u || typeof u !== "string") return;
          
          if (mediaSizeCache.has(u)) {
            const cachedBytes = mediaSizeCache.get(u)!;
            results[u] = {
              bytes: cachedBytes,
              mb: Math.round((cachedBytes / (1024 * 1024)) * 100) / 100,
              formatted: (cachedBytes / (1024 * 1024)).toFixed(2) + " MB"
            };
            return;
          }

          try {
            const response = await axios.get(u, {
              headers: { Range: "bytes=0-0" },
              timeout: 8000,
              validateStatus: (status) => status < 400 || status === 206
            });

            let totalBytes = 0;
            const contentRange = response.headers["content-range"];
            if (contentRange && typeof contentRange === "string") {
              const parts = contentRange.split("/");
              if (parts.length > 1) {
                totalBytes = parseInt(parts[1], 10) || 0;
              }
            }

            if (!totalBytes && response.headers["content-length"]) {
              totalBytes = parseInt(String(response.headers["content-length"]), 10) || 0;
            }

            if (totalBytes > 0) {
              mediaSizeCache.set(u, totalBytes);
              results[u] = {
                bytes: totalBytes,
                mb: Math.round((totalBytes / (1024 * 1024)) * 100) / 100,
                formatted: (totalBytes / (1024 * 1024)).toFixed(2) + " MB"
              };
            }
          } catch (e: any) {
            // If range fails, try HEAD
            try {
              const headRes = await axios.head(u, { timeout: 5000 });
              const cl = parseInt(String(headRes.headers["content-length"] || ""), 10);
              if (!isNaN(cl) && cl > 0) {
                mediaSizeCache.set(u, cl);
                results[u] = {
                  bytes: cl,
                  mb: Math.round((cl / (1024 * 1024)) * 100) / 100,
                  formatted: (cl / (1024 * 1024)).toFixed(2) + " MB"
                };
              }
            } catch {}
          }
        })
      );

      res.json({ success: true, sizes: results, isLiveMeasured: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API: Server System Stats
  app.get("/api/developer/server-stats", (req, res) => {
    const mem = process.memoryUsage();
    res.json({
      uptimeSeconds: Math.floor(process.uptime()),
      memory: {
        rssMB: Math.round((mem.rss / 1024 / 1024) * 10) / 10,
        heapUsedMB: Math.round((mem.heapUsed / 1024 / 1024) * 10) / 10,
        heapTotalMB: Math.round((mem.heapTotal / 1024 / 1024) * 10) / 10
      },
      environment: process.env.NODE_ENV || 'development'
    });
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
