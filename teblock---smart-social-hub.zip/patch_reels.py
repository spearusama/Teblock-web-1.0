import re

with open('components/ReelsView.tsx', 'r') as f:
    content = f.read()

reels_map_orig = """      {reels.map(reel => (
        <div key={reel.id} className="h-full w-full snap-start snap-always relative flex items-center justify-center bg-black">"""

reels_map_new = """      {reels.map((reel, index) => (
        <React.Fragment key={reel.id}>
        <div className="h-full w-full snap-start snap-always relative flex items-center justify-center bg-black">"""

content = content.replace(reels_map_orig, reels_map_new)

reels_map_end_orig = """          <div className="absolute bottom-4 left-4 z-50 max-w-[70%]">
            <h4 className="text-white font-black text-sm mb-1">{reel.userName}</h4>
            <p className="text-white/80 text-[10px] whitespace-pre-wrap">{reel.caption}</p>
          </div>
        </div>
      ))}"""

reels_map_end_new = """          <div className="absolute bottom-4 left-4 z-50 max-w-[70%]">
            <h4 className="text-white font-black text-sm mb-1">{reel.userName}</h4>
            <p className="text-white/80 text-[10px] whitespace-pre-wrap">{reel.caption}</p>
          </div>
        </div>
        {(index + 1) % 5 === 0 && (
            <div className="h-full w-full snap-start snap-always relative flex flex-col items-center justify-center bg-slate-900 border-t border-b border-white/5">
               <div className="absolute inset-0 bg-gradient-to-b from-blue-900/40 to-slate-900 z-0 pointer-events-none"></div>
               <div className="z-10 flex flex-col items-center justify-center flex-1 w-full p-8 text-center mt-20">
                  <div className="w-24 h-24 bg-blue-600/20 rounded-full flex items-center justify-center mb-8 border border-blue-500/20 shadow-2xl shadow-blue-500/20">
                     <svg className="w-12 h-12 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7"/></svg>
                  </div>
                  <h3 className="text-3xl font-black text-white mb-4 uppercase tracking-wider">إعلان ممول</h3>
                  <p className="text-blue-200/80 text-sm leading-relaxed max-w-xs mx-auto font-bold">اكتشف أحدث العروض والخدمات المخصصة لك عبر شريكنا الإعلاني.</p>
               </div>
               <div className="z-10 w-full p-6 pb-24 shrink-0">
                   <button onClick={() => window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank')} className="w-full py-4 bg-blue-600 rounded-[2rem] font-black text-white shadow-lg shadow-blue-600/30 flex items-center justify-center space-x-2 space-x-reverse active:scale-95 transition-all text-lg hover:bg-blue-500">
                      <span>فتح الإعلان</span>
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                   </button>
               </div>
            </div>
        )}
        </React.Fragment>
      ))}"""

content = content.replace(reels_map_end_orig, reels_map_end_new)

with open('components/ReelsView.tsx', 'w') as f:
    f.write(content)

