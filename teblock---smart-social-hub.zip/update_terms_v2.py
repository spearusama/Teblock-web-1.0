import re

with open('components/AuthForm.tsx', 'r') as f:
    content = f.read()

new_terms = """
            <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-4 text-right text-[11px] text-slate-300 leading-relaxed">
               <div className="bg-blue-900/20 border border-blue-500/20 p-4 rounded-xl mb-6">
                 <p className="text-blue-400 font-bold mb-2">تنبيه هام وموافقة صريحة:</p>
                 <p className="text-[10px]">نظراً لأن منصة TeBLOCK هي تطبيق في مرحلة التطوير والتشغيل التجريبي، فإننا نؤكد على أهمية قراءتك وفهمك الكامل لهذه البنود، خاصة فيما يتعلق بالبيانات والأمان.</p>
               </div>

               <p><strong className="text-blue-400 text-sm block mb-1">1. إخلاء المسؤولية الأمنية والحماية (Security Disclaimer & Limitation of Liability)</strong></p>
               <p>يعتمد تطبيق TeBLOCK على خوادم وخدمات طرف ثالث (Firebase / Google Cloud) لتخزين البيانات ومعالجتها. نحن نتخذ تدابير أمنية معقولة ونطبق بروتوكولات تشفير من طرف إلى طرف (End-to-End Encryption) للرسائل والملاحظات، بحيث يتم تشفيرها قبل إرسالها للخوادم. وتوافق على الآتي:</p>
               <ul className="list-disc list-inside space-y-1 pr-2 mt-2 text-slate-400">
                 <li>في حال حدوث أي اختراق أمني، تقتصر مسؤوليتنا القصوى على 100 درهم مغربي.</li>
                 <li>نبذل جهد معقول في اختيار مزودي الخدمة، لكننا غير مسؤولين عن الاختراقات التي تصيب مزودينا مباشرة.</li>
                 <li>في حال نجاح هجمات سيبرانية، فإننا نلتزم باتخاذ تدابير أمنية معقولة للحد من الأضرار وفقاً للقوانين المعمول بها.</li>
               </ul>
               
               <p><strong className="text-blue-400 text-sm block mt-6 mb-1">2. سياسة التشفير وإدارة المفاتيح (Encryption & Key Management)</strong></p>
               <p>يتم تشفير بياناتك الحساسة. لا تمتلك إدارة TeBLOCK أي صلاحية أو مفاتيح لفك تشفير رسائلك، ولا يمكن قراءتها من قبل أي مسؤول في المنصة. نتيجة لذلك:</p>
               <ul className="list-disc list-inside space-y-1 pr-2 mt-2 text-slate-400">
                 <li>لا توجد استعادة كلمة مرور للبيانات المشفرة بـ E2E لأن المفتاح عند المستخدم فقط.</li>
                 <li>فقدانك لمعرف حسابك أو كلمة المرور يعني ضياع الوصول إلى بياناتك المشفرة.</li>
               </ul>

               <p><strong className="text-blue-400 text-sm block mt-6 mb-1">3. متطلبات العمر (Age Requirements)</strong></p>
               <p>التطبيق مخصص لمن هم 13 سنة فأكثر. بجمعك لتاريخ الميلاد أنت تقر أن عمرك 13+ وتوافق على شروط الاستخدام والقوانين السارية.</p>

               <p><strong className="text-blue-400 text-sm block mt-6 mb-1">4. جمع البيانات وتخزينها (Data Collection)</strong></p>
               <p>المنصة تقوم بجمع وتخزين البيانات الأساسية لتشغيل حسابك (مثل معرف الحساب، الاسم، الجنس، الدولة، تاريخ الميلاد). هذه البيانات تخزن كما هي وتكون مرئية للإدارة وللمستخدمين الآخرين وفقاً لإعدادات المنصة لدعم وظائف التواصل الاجتماعي.</p>
               
               <p><strong className="text-blue-400 text-sm block mt-6 mb-1">5. الاستخدام المقبول والسلوك (Acceptable Use Policy)</strong></p>
               <p>بصفتك مستخدماً للمنصة، تلتزم بالامتناع عن الآتي:</p>
               <ul className="list-disc list-inside space-y-1 pr-2 mt-2 text-slate-400">
                 <li>استخدام المنصة لأي نشاط غير قانوني أو ينتهك القوانين المحلية أو الدولية.</li>
                 <li>نشر أي محتوى يحرض على العنف، الكراهية، أو ينتهك خصوصية الآخرين.</li>
               </ul>

               <p><strong className="text-blue-400 text-sm block mt-6 mb-1">6. التعديل على الشروط (Amendments)</strong></p>
               <p>يحق لإدارة TeBLOCK تحديث هذه الشروط في أي وقت. استمرارك في استخدام التطبيق بعد التعديلات يعد موافقة صريحة منك.</p>
            </div>
"""

# Replace the existing content
content = re.sub(
    r'<div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-4 text-right text-\[11px\] text-slate-300 leading-relaxed">.*?</div>\n',
    new_terms,
    content,
    flags=re.DOTALL
)

with open('components/AuthForm.tsx', 'w') as f:
    f.write(content)

