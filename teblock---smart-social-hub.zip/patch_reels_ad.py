import re

with open('components/ReelsView.tsx', 'r') as f:
    content = f.read()

# Make sure to import AdComponent if not already there
if "import { AdComponent }" not in content:
    content = content.replace("import React", "import { AdComponent } from './AdComponent';\\nimport React")

reels_old = """        {(index + 1) % 5 === 0 && (
            <div className="h-full w-full snap-start snap-always relative flex flex-col items-center justify-center bg-black overflow-hidden group cursor-pointer" onClick={() => window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank')}>
               <video src="https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4" autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-500" />
               <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/90 pointer-events-none"></div>
               
               <div className="absolute top-6 right-6 z-50">
                  <div className="bg-blue-600 text-white text-[10px] font-black px-3 py-1.5 rounded-lg shadow-lg uppercase tracking-wider">
                     إعلان ممول
                  </div>
               </div>

               <div className="z-10 absolute bottom-32 left-4 right-20 text-right pointer-events-none">
                  <h3 className="text-2xl font-black text-white mb-2 drop-shadow-lg">عرض خاص وحصري</h3>
                  <p className="text-white/90 text-sm font-bold leading-relaxed drop-shadow-md">استفد من هذا العرض الرائع لفترة محدودة، تجربة فريدة بانتظارك الآن.</p>
               </div>

               <div className="z-20 absolute bottom-6 w-full px-6 shrink-0">
                   <button onClick={(e) => { e.stopPropagation(); window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank'); }} className="w-full py-4 bg-blue-600 rounded-[2rem] font-black text-white shadow-lg shadow-blue-600/30 flex items-center justify-center space-x-2 space-x-reverse active:scale-95 transition-all text-lg hover:bg-blue-500 hover:shadow-blue-500/40">
                      <span>فتح الرابط الآن</span>
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                   </button>
               </div>
            </div>
        )}"""

reels_new = """        {(index + 1) % 5 === 0 && (
            <div className="h-full w-full snap-start snap-always relative flex flex-col items-center justify-center bg-black overflow-hidden">
                <div className="absolute top-6 right-6 z-50">
                  <div className="bg-blue-600 text-white text-[10px] font-black px-3 py-1.5 rounded-lg shadow-lg uppercase tracking-wider">
                     إعلان ممول
                  </div>
               </div>
               <div className="flex-1 w-full h-full flex items-center justify-center">
                   <AdComponent />
               </div>
            </div>
        )}"""

content = content.replace(reels_old, reels_new)

with open('components/ReelsView.tsx', 'w') as f:
    f.write(content)
