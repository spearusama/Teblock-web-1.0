sed -i '5i import { decryptText } from "../utils/crypto";' components/NotificationsView.tsx
sed -i 's/const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Notification));/const data = snap.docs.map(d => { const ddata = d.data(); return { id: d.id, ...ddata, content: decryptText(ddata.content || "") } as Notification; });/g' components/NotificationsView.tsx
