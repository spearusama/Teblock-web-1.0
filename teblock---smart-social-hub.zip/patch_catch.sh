sed -i 's/} catch (e) { console.error(e); }/} catch (e) { console.error(e); setInputMessage(textToSend === quickEmoji ? "" : textToSend); }/g' components/AIChatView.tsx
