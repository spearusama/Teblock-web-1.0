sed -i '5i import { encryptText, decryptText } from "../utils/crypto";' components/ReelsView.tsx
sed -i 's/return { id: d.id, ...data, userName: uName, userPhoto: uPhoto } as Reel;/return { id: d.id, ...data, userName: uName, userPhoto: uPhoto, caption: decryptText(data.caption || "") } as Reel;/g' components/ReelsView.tsx
