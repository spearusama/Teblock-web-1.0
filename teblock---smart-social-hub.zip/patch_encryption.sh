sed -i '8i import { encryptText, decryptText } from "../utils/crypto";' components/AIChatView.tsx

# Update onSnapshot to decrypt messages
sed -i 's/allMsgs.forEach((m: any) => {/allMsgs.forEach((m: any) => {\
          m.text = decryptText(m.text);\
          if (m.replyToText) m.replyToText = decryptText(m.replyToText);/g' components/AIChatView.tsx

# Update search logic to decrypt messages before searching
sed -i 's/.map(d => ({ id: d.id, ...d.data() } as any))/.map(d => { const data = d.data() as any; return { id: d.id, ...data, text: decryptText(data.text || "") }; })/g' components/AIChatView.tsx

# Update sending logic
sed -i 's/text: textToSend,/text: encryptText(textToSend),/g' components/AIChatView.tsx
sed -i 's/messageData.replyToText = replyingTo.text || "";/messageData.replyToText = encryptText(replyingTo.text || "");/g' components/AIChatView.tsx
sed -i 's/text: aiResponse,/text: encryptText(aiResponse),/g' components/AIChatView.tsx

