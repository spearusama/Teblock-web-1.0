const fs = require('fs');
let code = fs.readFileSync('components/AIChatView.tsx', 'utf8');

code = code.replace(/nicknames\[u\.Id_user \|\| u\.id\]/g, 'nicknames[((u.Id_user || u.id) || "").replace(/\\./g, "_")]');
code = code.replace(/setEditingNicknameId\(u\.Id_user \|\| u\.id\)/g, 'setEditingNicknameId(((u.Id_user || u.id) || "").replace(/\\./g, "_"))');

fs.writeFileSync('components/AIChatView.tsx', code);
