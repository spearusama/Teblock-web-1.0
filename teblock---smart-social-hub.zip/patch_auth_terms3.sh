cat << 'INNER_EOF' > /tmp/terms_ui.txt
        {mode === 'signup' && (
          <div className="flex items-start space-x-3 space-x-reverse mt-2">
            <input 
              type="checkbox" 
              id="agreeTerms" 
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              className="mt-1 w-4 h-4 rounded border-white/20 bg-black/40 text-blue-600 focus:ring-blue-600 focus:ring-offset-0 focus:ring-offset-transparent cursor-pointer"
            />
            <label htmlFor="agreeTerms" className="text-[10px] text-slate-400 leading-relaxed cursor-pointer select-none">
              أوافق على <button type="button" onClick={() => setShowTerms(true)} className="text-blue-400 font-bold hover:underline">شروط الاستخدام وسياسة الخصوصية</button> الخاصة بـ TeBLOCK. وأقر بأن التطبيق غير مسؤول قانونياً عن أي خرق أمني أو تسريب ناتج عن ثغرات في خوادم طرف ثالث.
            </label>
          </div>
        )}
INNER_EOF

# Insert right before <button type="submit"
sed -i '/<button [ \t]*type="submit"/e cat /tmp/terms_ui.txt' components/AuthForm.tsx

