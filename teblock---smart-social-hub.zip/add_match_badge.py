import re

with open('components/ReelsView.tsx', 'r') as f:
    content = f.read()

badge_html = """          <ReelItem
            reel={reel}
            isMuted={isMuted}
            isActive={activeReelId === reel.id}
            onDoubleTap={toggleLike}
          />
          {((reel as any).matchPercentage || 0) > 0 && (
            <div className="absolute top-6 left-6 z-50">
              <div className="bg-blue-600/80 backdrop-blur-md border border-blue-400/30 px-3 py-1.5 rounded-2xl shadow-lg flex items-center space-x-1.5 space-x-reverse">
                 <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                 <span className="text-[10px] font-black text-white">{Math.min(100, (reel as any).matchPercentage)}% تطابق</span>
              </div>
            </div>
          )}
"""

content = content.replace("""          <ReelItem
            reel={reel}
            isMuted={isMuted}
            isActive={activeReelId === reel.id}
            onDoubleTap={toggleLike}
          />""", badge_html)

with open('components/ReelsView.tsx', 'w') as f:
    f.write(content)

