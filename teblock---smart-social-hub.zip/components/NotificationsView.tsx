
import React, { useState, useEffect } from 'react';
import { User, Notification } from '../types';
import { db } from '../firebase';
import { decryptText } from "../utils/crypto";
import { 
  collection, query, where, onSnapshot, doc, updateDoc, 
  deleteDoc, arrayUnion, arrayRemove, serverTimestamp, addDoc, limit 
} from 'firebase/firestore';
import { useLanguage } from '../utils/i18n';

interface NotificationsViewProps {
  user: User;
  onNavigateToChat?: (friend: any) => void;
  onNavigateProfile?: (userId: string) => void;
  onNavigateToReel?: (reelId: string) => void;
}

const NotificationsView: React.FC<NotificationsViewProps> = ({ user, onNavigateToChat, onNavigateProfile, onNavigateToReel }) => {
  const { t, dir } = useLanguage();
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'notifications'), where('toId', '==', user.Id_user), limit(100));
    return onSnapshot(q, (snap) => {
      const data = snap.docs.map(d => { const ddata = d.data(); return { id: d.id, ...ddata, content: decryptText(ddata.content || "") } as Notification; });
      data.sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
      setNotifications(data);
    });
  }, [user.Id_user]);

  const markAsRead = async (id: string) => {
    await updateDoc(doc(db, 'notifications', id), { read: true });
  };

  const handleFriendRequest = async (notif: Notification, accept: boolean) => {
    if (accept) {
      // إضافة لقائمة الأصدقاء للطرفين وإزالة من قوائم الطلبات
      await updateDoc(doc(db, 'users', user.Id_user), { 
        friendsList: arrayUnion(notif.fromId),
        pendingRequests: arrayRemove(notif.fromId)
      });
      await updateDoc(doc(db, 'users', notif.fromId), { 
        friendsList: arrayUnion(user.Id_user),
        sentRequests: arrayRemove(user.Id_user)
      });
      
      // إرسال إشعار للطرف الآخر بالقبول
      await addDoc(collection(db, 'notifications'), {
        toId: notif.fromId,
        fromId: user.Id_user,
        fromName: user.UserData,
        fromPhoto: user.photoURL,
        type: 'accept_friend',
        read: false,
        timestamp: serverTimestamp()
      });

      // الانتقال للمحادثة فوراً
      onNavigateToChat?.({
        id: notif.fromId,
        name: notif.fromName,
        photo: notif.fromPhoto
      });
    } else {
      // رفض الطلب: إزالة من قوائم الطلبات
      await updateDoc(doc(db, 'users', user.Id_user), { 
        pendingRequests: arrayRemove(notif.fromId)
      });
      await updateDoc(doc(db, 'users', notif.fromId), { 
        sentRequests: arrayRemove(user.Id_user)
      });
    }
    await deleteDoc(doc(db, 'notifications', notif.id));
  };

  return (
    <div dir={dir} className="flex-1 flex flex-col bg-[var(--teblock-bg)] h-full overflow-hidden animate-in fade-in duration-300">
      <div className="px-4 py-3 sm:px-6 sm:py-3.5 border-b border-[var(--teblock-border)] glass flex justify-between items-center shrink-0">
         <h2 className="text-xs sm:text-sm font-black uppercase tracking-wider text-blue-500">{t('notif.title')}</h2>
         <span className="text-[9px] font-black text-slate-500">{notifications.length} {t('notif.count')}</span>
      </div>
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2 custom-scrollbar">
        {notifications.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center opacity-20">
            <svg className="w-16 h-16 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" strokeWidth={1}/></svg>
            <p className="text-xs font-black uppercase tracking-[0.5em]">{t('search.noResults')}</p>
          </div>
        ) : (
          notifications.map(notif => (
            <div 
              key={notif.id} 
              onMouseEnter={() => !notif.read && markAsRead(notif.id)}
              onClick={() => {
                if (!notif.read) markAsRead(notif.id);
                if ((notif.type === 'like' || notif.type === 'comment') && notif.relatedId) {
                  onNavigateToReel?.(notif.relatedId);
                }
              }}
              className={`p-3 sm:p-3.5 rounded-2xl border transition-all flex items-start space-x-3 space-x-reverse cursor-pointer ${notif.read ? 'bg-white/5 border-white/5 opacity-60' : 'bg-blue-600/10 border-blue-600/20 shadow-md shadow-blue-600/5'}`}
            >
              <img 
                onClick={() => onNavigateProfile?.(notif.fromId)}
                src={notif.fromPhoto || `https://api.dicebear.com/7.x/bottts/svg?seed=${notif.fromId}`} 
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl border border-blue-500/20 cursor-pointer hover:scale-105 transition-transform shrink-0" 
              />
              <div className="flex-1 rtl:text-right ltr:text-left min-w-0">
                <p className="text-[11px] font-bold text-white mb-1 leading-snug">
                  <span onClick={() => onNavigateProfile?.(notif.fromId)} className="text-blue-500 font-black cursor-pointer hover:underline">@{notif.fromName}</span> 
                  {notif.type === 'friend_request' && (' ' + t('notif.friendRequest'))}
                  {notif.type === 'follow' && (' ' + t('notif.follow'))}
                  {notif.type === 'like' && (' ' + t('notif.like'))}
                  {notif.type === 'comment' && (' ' + t('notif.comment'))}
                  {notif.type === 'accept_friend' && (' ' + t('notif.acceptFriend'))}
                </p>
                {notif.content && <p className="text-[9px] text-slate-400 bg-black/20 px-2.5 py-1.5 rounded-lg border border-white/5 italic mb-2 truncate">"{notif.content}"</p>}
                
                {notif.type === 'friend_request' && (
                  <div className="flex space-x-2 space-x-reverse mt-1.5">
                    <button onClick={() => handleFriendRequest(notif, true)} className="bg-blue-600 px-4 py-1.5 rounded-lg text-[9px] font-black text-white hover:scale-105 transition-transform">{t('notif.accept')}</button>
                    <button onClick={() => handleFriendRequest(notif, false)} className="bg-white/5 border border-white/10 px-4 py-1.5 rounded-lg text-[9px] font-black text-slate-400">{t('notif.delete')}</button>
                  </div>
                )}
              </div>
              <div className="text-[7px] font-black text-slate-500 uppercase whitespace-nowrap">{t('notif.now')}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default NotificationsView;
