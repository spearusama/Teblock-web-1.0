import React, { useState } from 'react';
import { User } from '../types';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useLanguage } from '../utils/i18n';
import TermsModal from './TermsModal';

interface MenuViewProps {
  user: User;
  onNavigate: (view: string) => void;
  onBack: () => void;
}

export const MenuView: React.FC<MenuViewProps> = ({ user, onNavigate, onBack }) => {
  const { t, langInfo, dir } = useLanguage();
  const [code, setCode] = useState('');
  const [codeMessage, setCodeMessage] = useState({ text: '', type: '' });
  const [showTermsModal, setShowTermsModal] = useState(false);

  const handleRedeemCode = async () => {
    if (!code.trim()) return;
    const upperCode = code.trim().toUpperCase();

    try {
      if (upperCode === 'D3R5') {
        await updateDoc(doc(db, 'users', user.Id_user), {
          isDeveloper: true
        });
        setCodeMessage({ text: t('menu.codeSuccess'), type: 'success' });
        setCode('');
      } else {
        setCodeMessage({ text: t('menu.codeInvalid'), type: 'error' });
      }
    } catch (e) {
      setCodeMessage({ text: t('menu.codeError'), type: 'error' });
    }
  };

  return (
    <div dir={dir} className="flex flex-col h-full bg-[#0a0a0a] text-white animate-in fade-in">
      <header className="h-13 sm:h-14 flex items-center px-4 border-b border-white/10 glass shrink-0 relative">
        <button onClick={onBack} className="p-1.5 rtl:mr-1.5 ltr:ml-1.5 text-slate-400 hover:text-white transition-colors">
           <svg className="w-5 h-5 transform rtl:rotate-180 ltr:rotate-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7"/></svg>
        </button>
        <h2 className="text-base font-black tracking-tight text-blue-500">{t('nav.menu')}</h2>
      </header>

      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 custom-scrollbar">
        
        {/* Code Redemption Section */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-lg">
          <h3 className="text-xs sm:text-sm font-black mb-1.5 flex items-center rtl:text-right ltr:text-left">
            <svg className="w-4 h-4 rtl:ml-2 ltr:mr-2 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            {t('menu.giftCodes')}
          </h3>
          <p className="text-[11px] text-slate-400 mb-4 font-bold leading-relaxed rtl:text-right ltr:text-left">{t('menu.giftCodesDesc')}</p>
          
          <div className="flex space-x-2 space-x-reverse mb-1">
            <input 
              type="text" 
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder={t('menu.enterCode')}
              className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs font-bold text-center uppercase tracking-wider text-white outline-none focus:border-blue-500 transition-colors"
            />
            <button 
              onClick={handleRedeemCode}
              disabled={!code.trim()}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-black px-4 py-2 text-xs rounded-xl transition-colors shadow-md shadow-blue-600/20"
            >
              {t('menu.activate')}
            </button>
          </div>
          {codeMessage.text && (
            <p className={`mt-2 text-[11px] font-bold text-center animate-in zoom-in ${codeMessage.type === 'success' ? 'text-green-500' : 'text-red-500'}`}>
              {codeMessage.text}
            </p>
          )}
        </div>

        {/* Menu Options */}
        <div className="space-y-2.5">
          <button 
            onClick={() => onNavigate('language')}
            className="w-full flex items-center justify-between p-3.5 sm:p-4 bg-gradient-to-r from-blue-600/15 via-indigo-600/10 to-blue-600/15 hover:from-blue-600/25 hover:to-blue-600/25 border border-blue-500/20 rounded-xl transition-all text-white group shadow-md"
          >
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center rtl:ml-3 ltr:mr-3 group-hover:scale-105 transition-transform text-lg border border-blue-500/30 shrink-0">
                🌐
              </div>
              <div className="rtl:text-right ltr:text-left">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <span className="font-black text-xs sm:text-sm block">{t('lang.title')}</span>
                  <span className="text-[8px] bg-blue-500/20 text-blue-400 font-black px-2 py-0.5 rounded-full">
                    {langInfo.flag} {langInfo.nativeName}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-bold">{t('lang.subtitle')}</span>
              </div>
            </div>
            <svg className="w-4 h-4 text-slate-400 opacity-60 group-hover:translate-x-[-4px] flip-in-ltr transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7"/></svg>
          </button>

          {user.isDeveloper && (
            <>
              <button 
                onClick={() => onNavigate('developer_zone')}
                className="w-full flex items-center justify-between p-3.5 sm:p-4 bg-gradient-to-r from-blue-600/20 via-indigo-600/10 to-blue-600/20 hover:from-blue-600/30 hover:to-blue-600/30 border border-blue-500/30 rounded-xl transition-all text-white group shadow-md"
              >
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-blue-500/20 border border-blue-500/30 rounded-lg flex items-center justify-center rtl:ml-3 ltr:mr-3 group-hover:scale-105 transition-transform text-blue-400 shrink-0">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                  </div>
                  <div className="rtl:text-right ltr:text-left">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <span className="font-black text-xs sm:text-sm block">{t('menu.devZone')}</span>
                      <span className="text-[8px] bg-blue-500 text-white font-black px-1.5 py-0.5 rounded-full uppercase">Live</span>
                    </div>
                    <span className="text-[10px] text-blue-300/80 font-bold">{t('menu.devZoneDesc')}</span>
                  </div>
                </div>
                <svg className="w-4 h-4 text-blue-400 opacity-70 group-hover:translate-x-[-4px] flip-in-ltr transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7"/></svg>
              </button>

              <button 
                onClick={() => onNavigate('admin_reports')}
                className="w-full flex items-center justify-between p-3.5 sm:p-4 bg-red-600/10 hover:bg-red-600/20 border border-red-500/20 rounded-xl transition-colors text-red-500 group shadow-md"
              >
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-red-500/20 rounded-lg flex items-center justify-center rtl:ml-3 ltr:mr-3 group-hover:scale-105 transition-transform shrink-0">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                  </div>
                  <div className="rtl:text-right ltr:text-left">
                    <span className="font-black text-xs sm:text-sm block">{t('menu.reports')}</span>
                    <span className="text-[10px] text-red-400 font-bold">{t('menu.reportsDesc')}</span>
                  </div>
                </div>
                <svg className="w-4 h-4 opacity-50 flip-in-ltr" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7"/></svg>
              </button>
            </>
          )}
           
           <button 
             onClick={() => setShowTermsModal(true)}
             className="w-full flex items-center justify-between p-3.5 sm:p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-all text-white group shadow-sm"
           >
               <div className="flex items-center">
                 <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center rtl:ml-3 ltr:mr-3 shrink-0 text-blue-400">
                   <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                   </svg>
                 </div>
                 <div className="rtl:text-right ltr:text-left">
                   <span className="font-black text-xs sm:text-sm block">الشروط وسياسة الخصوصية</span>
                   <span className="text-[10px] text-slate-400 font-bold">اتفاقية الاستخدام والخصوصية لمنصة Teblock</span>
                 </div>
               </div>
               <svg className="w-4 h-4 text-slate-400 opacity-60 group-hover:translate-x-[-4px] flip-in-ltr transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7"/></svg>
           </button>

        </div>

      </div>

      <TermsModal 
        isOpen={showTermsModal}
        onClose={() => setShowTermsModal(false)}
        showAgreeBtn={false}
      />
    </div>
  );
};
