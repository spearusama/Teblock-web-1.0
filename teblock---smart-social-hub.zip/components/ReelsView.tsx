
import React, { useState, useEffect, useRef } from 'react';
import { User, Reel, Comment } from '../types';
import { ReelItem } from './ReelItem';
import { encryptText, decryptText } from "../utils/crypto";
import { db } from '../firebase';
import { EMOJI_CATEGORIES } from '../constants/emojis';
import { useLanguage } from '../utils/i18n';
import { EmojiImg } from '../utils/emoji';
import { reelsManager, ReelsManagerStats } from '../utils/reelsManager';
import { getVideoQualityPreference, setVideoQualityPreference, VideoQualityMode } from '../utils/mediaOptimizer';
import { 
  collection, query, onSnapshot, doc, getDoc, getDocs, orderBy, updateDoc, 
  limit, arrayUnion, arrayRemove, increment, deleteDoc, addDoc, serverTimestamp, where 
} from 'firebase/firestore';
import { getReelHashtags, calculateReelMatch, renderCaptionWithHashtags, extractHashtags, POPULAR_HASHTAGS } from '../utils/hashtagUtils';

interface ReelsViewProps {
  user: User;
  jumpToReelId?: string | null;
  showBackButton?: boolean;
  onBack?: () => void;
  onNavigateProfile?: (userId: string) => void;
}

const ReelsView: React.FC<ReelsViewProps> = ({ user, jumpToReelId, showBackButton, onBack, onNavigateProfile }) => {
  const { t, dir } = useLanguage();
  const [reels, setReels] = useState<Reel[]>([]);
  const [allRawReels, setAllRawReels] = useState<Reel[]>([]);
  const [selectedHashtag, setSelectedHashtag] = useState<string | null>(null);
  const [activeReelId, setActiveReelId] = useState<string | null>(null);
  const [hiddenIds, setHiddenIds] = useState<string[]>(JSON.parse(localStorage.getItem('teblock_hidden') || '[]'));
  const [activeCommentsReel, setActiveCommentsReel] = useState<Reel | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [commentText, setCommentText] = useState("");
  const [menuId, setMenuId] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(true);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [recentEmojis, setRecentEmojis] = useState<string[]>(JSON.parse(localStorage.getItem('recent_emojis') || '[]'));
  
  const [replyTo, setReplyTo] = useState<Comment | null>(null);
  const [showMentionList, setShowMentionList] = useState(false);
  const [mentionSearch, setMentionSearch] = useState("");
  const [friends, setFriends] = useState<any[]>([]);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareSearch, setShareSearch] = useState("");
  const [activeShareReel, setActiveShareReel] = useState<Reel | null>(null);
  const [savedReels, setSavedReels] = useState<string[]>(user.savedReels || []);
  const commentInputRef = useRef<HTMLInputElement>(null);
  
  const [userInterests, setUserInterests] = useState<Record<string, number>>(user.interestVector || {});
  const observerRef = useRef<IntersectionObserver | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isProcessingAction, setIsProcessingAction] = useState(false);
  const clickTimeout = useRef<any>(null);
  const longPressTimer = useRef<any>(null);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [managerStats, setManagerStats] = useState<ReelsManagerStats>(reelsManager.getStats());
  const [showDataSaverModal, setShowDataSaverModal] = useState(false);
  const [qualityMode, setQualityMode] = useState<VideoQualityMode>(getVideoQualityPreference);
  const [editingReel, setEditingReel] = useState<Reel | null>(null);
  const [editCaption, setEditCaption] = useState<string>("");
  const [isSavingEdit, setIsSavingEdit] = useState<boolean>(false);
  const [deletingReel, setDeletingReel] = useState<Reel | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [publisherMap, setPublisherMap] = useState<Record<string, { accountType?: string; followersList?: string[] }>>({});

  useEffect(() => {
    // Set user context in manager
    reelsManager.setUserContext(user.Id_user, user.interestVector);

    // Subscribe to manager stats for data saver insights
    const unsubStats = reelsManager.subscribeStats((st) => {
      setManagerStats(st);
    });

    // Subscribe to organized, interest-based chunked reels stream
    const unsubReels = reelsManager.subscribe((rawList, updatedReelId) => {
      // Map author details with friends list and current user
      const mapped = rawList.map(d => {
        let uName = d.userName;
        let uPhoto = d.userPhoto;
        if (d.userId === user.Id_user) {
          uName = user.UserData;
          uPhoto = user.photoURL || "";
        } else {
          const f = friends.find((fr: any) => fr.Id_user === d.userId);
          if (f) {
            uName = f.UserData;
            uPhoto = f.photoURL || "";
          }
        }
        return { ...d, userName: uName, userPhoto: uPhoto } as Reel;
      });

      const cleanList = mapped.filter(r => !hiddenIds.includes(r.id));

      if (jumpToReelId === 'SAVED_REELS') {
        const savedOnly = cleanList.filter(r => savedReels.includes(r.id));
        setReels(savedOnly);
        if (savedOnly.length > 0) {
          setActiveReelId(prev => (prev && savedOnly.some(r => r.id === prev)) ? prev : savedOnly[0].id);
        }
        return;
      }

      setReels(prevReels => {
        // If a specific reel was updated (likes, comments, etc.), update in-place without touching order
        if (updatedReelId) {
          const updatedTarget = cleanList.find(r => r.id === updatedReelId);
          if (!updatedTarget) return prevReels;
          return prevReels.map(r => r.id === updatedReelId ? { ...r, ...updatedTarget } : r);
        }

        const isJumpTarget = !!(jumpToReelId && jumpToReelId !== 'SAVED_REELS');

        // Initial load or feed refresh
        if (prevReels.length === 0) {
          if (cleanList.length > 0) {
            if (isJumpTarget) {
              const target = cleanList.find(r => r.id === jumpToReelId);
              if (target) {
                const ordered = [target, ...cleanList.filter(r => r.id !== jumpToReelId)];
                setActiveReelId(target.id);
                setTimeout(() => {
                  if (containerRef.current) containerRef.current.scrollTop = 0;
                }, 0);
                return ordered;
              }
            }
            setActiveReelId(cleanList[0].id);
          }
          return cleanList;
        }

        // If we jumped to a specific reel and it's already in prevReels but not first, move it to index 0
        if (isJumpTarget) {
          const targetInClean = cleanList.find(r => r.id === jumpToReelId);
          if (targetInClean && prevReels[0]?.id !== jumpToReelId) {
            const existingIds = new Set(prevReels.map(r => r.id));
            const newlyAppended = cleanList.filter(r => !existingIds.has(r.id) && r.id !== jumpToReelId);
            const restPrev = prevReels.filter(r => r.id !== jumpToReelId);
            setActiveReelId(targetInClean.id);
            setTimeout(() => {
              if (containerRef.current) containerRef.current.scrollTop = 0;
            }, 0);
            return [targetInClean, ...restPrev, ...newlyAppended];
          }
        }

        // When additional chunks arrive: APPEND ONLY new unseen items to the bottom!
        const existingIds = new Set(prevReels.map(r => r.id));
        const newlyAppended = cleanList.filter(r => !existingIds.has(r.id));

        if (newlyAppended.length === 0) {
          // Just update mutable fields in-place without changing order
          return prevReels.map(oldR => {
            const fresh = cleanList.find(r => r.id === oldR.id);
            return fresh ? { ...oldR, ...fresh } : oldR;
          });
        }

        // Append new items to the bottom, keeping existing feed order 100% frozen
        return [...prevReels, ...newlyAppended];
      });
    });

    // Ensure initial chunk is loaded with viewer context
    if (reelsManager.getLoadedReels().length === 0) {
      reelsManager.fetchInitialChunk('بدء تصفح الريلز', user, selectedHashtag);
    }
    if (jumpToReelId && jumpToReelId !== 'SAVED_REELS') {
      reelsManager.ensureReelLoaded(jumpToReelId);
    }

    return () => {
      unsubStats();
      unsubReels();
    };
  }, [user.Id_user, jumpToReelId, selectedHashtag, hiddenIds, savedReels, friends]);

  useEffect(() => {
    if (!user.friendsList || user.friendsList.length === 0) return;
    const q = query(collection(db, 'users'), where('Id_user', 'in', user.friendsList.slice(0, 10)));
    return onSnapshot(q, (snap) => {
      setFriends(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });
  }, [user.friendsList]);

  useEffect(() => {
    if (!activeCommentsReel) return;
    const q = query(collection(db, 'comments'), where('reelId', '==', activeCommentsReel.id));
    return onSnapshot(q, (snap) => {
      const data = snap.docs.map(d => {
        const cData = d.data();
        let uName = cData.userName;
        let uPhoto = cData.userPhoto;
        if (cData.userId === user.Id_user) {
          uName = user.UserData;
          uPhoto = user.photoURL || "";
        } else {
          const f = friends.find((fr: any) => fr.Id_user === cData.userId);
          if (f) {
            uName = f.UserData;
            uPhoto = f.photoURL || "";
          }
        }
        return { id: d.id, ...cData, userName: uName, userPhoto: uPhoto, text: decryptText(cData.text || "") } as Comment;
      });
      data.sort((a, b) => (a.timestamp?.seconds || 0) - (b.timestamp?.seconds || 0));
      setComments(data);
    });
  }, [activeCommentsReel, friends, user.photoURL, user.UserData]);

  useEffect(() => {
    if (activeReelId) {
      const newPath = `/reel/${activeReelId}`;
      if (window.location.pathname !== newPath && window.location.pathname.startsWith('/reel')) {
        window.history.replaceState(null, '', newPath);
      }
    }
  }, [activeReelId]);

  useEffect(() => {
    observerRef.current = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const reelId = entry.target.getAttribute('data-reel-id');
          if (reelId) {
            setActiveReelId(reelId);
            const idx = reels.findIndex(r => r.id === reelId);
            if (idx !== -1) {
              // 1. Proactively preload next 2 upcoming videos for instant zero-wait swiping
              reelsManager.preloadUpcoming(idx);

              // 2. Near-End condition: Check if user is nearing the end of current batch (within 2 items)
              if (idx >= reels.length - 2 && reelsManager.getHasMore() && !reelsManager.getIsLoading()) {
                setIsLoadingMore(true);
                reelsManager.fetchNextChunk(`الاقتراب من نهاية الريلزات المتوفرة (الريل ${idx + 1} من أصل ${reels.length})`, user)
                  .finally(() => setIsLoadingMore(false));
              }
            }
          }
        }
      });
    }, { threshold: 0.6 });
    document.querySelectorAll('.reel-item-container').forEach(v => observerRef.current?.observe(v));
    return () => observerRef.current?.disconnect();
  }, [reels, user]);

  const saveRecentEmoji = (emoji: string) => {
    const updated = [emoji, ...recentEmojis.filter(e => e !== emoji)].slice(0, 20);
    setRecentEmojis(updated);
    localStorage.setItem('recent_emojis', JSON.stringify(updated));
  };

  const handleEmojiSelect = (emoji: string) => {
    setCommentText(prev => prev + emoji);
    saveRecentEmoji(emoji);
  };

  const handleHashtagClick = (tag: string) => {
    const nextTag = selectedHashtag === tag ? null : tag;
    setSelectedHashtag(nextTag);
    setReels([]);
    reelsManager.fetchInitialChunk(nextTag ? `تصفية الهاشتاغ: ${nextTag}` : 'عرض الفيد المخصص', user, nextTag);

    if (nextTag) {
      const cleanTag = nextTag.toLowerCase();
      const currentVector = { ...(user.interestVector || {}) };
      currentVector[cleanTag] = (currentVector[cleanTag] || 0) + 1;
      user.interestVector = currentVector;
      reelsManager.setUserContext(user.Id_user, currentVector);
      updateDoc(doc(db, 'users', user.Id_user), { interestVector: currentVector }).catch(() => {});
    }
  };

  const toggleLike = async (reel: Reel) => {
    const isLiked = reel.likes.includes(user.Id_user);
    const newLikes = isLiked ? reel.likes.filter(id => id !== user.Id_user) : [...reel.likes, user.Id_user];
    
    // 1. In-place update to reels state: index and order NEVER shift
    setReels(prev => prev.map(r => r.id === reel.id ? { ...r, likes: newLikes } : r));

    // 2. In-place update to local manager
    reelsManager.updateLocalReel(reel.id, prev => ({
      ...prev,
      likes: newLikes
    }));

    const ref = doc(db, 'reels', reel.id);
    updateDoc(ref, { likes: isLiked ? arrayRemove(user.Id_user) : arrayUnion(user.Id_user) }).catch(console.error);

    // 3. Update user interests based on hashtags for FUTURE recommendations
    const reelTags = getReelHashtags(reel);
    if (!isLiked && reelTags.length > 0) {
      const currentVector = { ...(user.interestVector || {}) };
      reelTags.forEach(tag => {
        const cleanTag = tag.toLowerCase();
        currentVector[cleanTag] = (currentVector[cleanTag] || 0) + 1;
      });
      user.interestVector = currentVector;
      reelsManager.setUserContext(user.Id_user, currentVector);
      updateDoc(doc(db, 'users', user.Id_user), { interestVector: currentVector }).catch(console.error);
    }

    if (!isLiked && reel.userId !== user.Id_user) {
      addDoc(collection(db, 'notifications'), {
        toId: reel.userId,
        fromId: user.Id_user,
        fromName: user.UserData,
        fromPhoto: user.photoURL,
        type: 'like',
        read: false,
        timestamp: serverTimestamp(),
        relatedId: reel.id
      }).catch(console.error);
    }
  };

  const toggleSave = async (reelId: string, reel: Reel) => {
    const isSaved = savedReels.includes(reelId);
    const updated = isSaved ? savedReels.filter(id => id !== reelId) : [...savedReels, reelId];
    setSavedReels(updated);
    updateDoc(doc(db, 'users', user.Id_user), { savedReels: updated }).catch(console.error);

    // Update user interests on save with higher weight for hashtags (+2)
    const reelTags = getReelHashtags(reel);
    if (!isSaved && reelTags.length > 0) {
      const currentVector = { ...(user.interestVector || {}) };
      reelTags.forEach(tag => {
        const cleanTag = tag.toLowerCase();
        currentVector[cleanTag] = (currentVector[cleanTag] || 0) + 2;
      });
      user.interestVector = currentVector;
      reelsManager.setUserContext(user.Id_user, currentVector);
      updateDoc(doc(db, 'users', user.Id_user), { interestVector: currentVector }).catch(console.error);
    }
  };

  const shareToFriend = async (friend: any) => {
    if (!activeShareReel) return;
    await addDoc(collection(db, 'messages'), {
      senderId: user.Id_user,
      senderName: user.UserData,
      senderPhoto: user.photoURL || "",
      receiverId: friend.Id_user,
      text: activeShareReel.caption || "",
      reelId: activeShareReel.id,
      reelVideoUrl: activeShareReel.videoUrl || "",
      reelAuthorName: activeShareReel.userName || "",
      reelCaption: activeShareReel.caption || "",
      timestamp: serverTimestamp(),
      read: false
    });
    setShowShareModal(false);
    alert(t('reels.shareSuccess'));
  };

  const handleReport = async (reel: Reel) => {
    try {
      await addDoc(collection(db, 'reports'), {
        reelId: reel.id,
        reportedUser: reel.userId,
        reportedBy: user.Id_user,
        text: reel.caption || t('reels.defaultCaption'),
        type: 'reel_report',
        timestamp: serverTimestamp()
      });
      alert(t('reels.reportSuccess'));
    } catch (e) {
      alert(t("menu.codeError"));
    }
    setMenuId(null);
  };

  const handleNotInterested = async (reelId: string) => {
    const reel = reels.find(r => r.id === reelId);
    if (reel) {
      const reelTags = getReelHashtags(reel);
      if (reelTags.length > 0) {
        const currentVector = { ...(user.interestVector || {}) };
        reelTags.forEach(tag => {
          const cleanTag = tag.toLowerCase();
          if (currentVector[cleanTag]) {
            currentVector[cleanTag] = Math.max(0, currentVector[cleanTag] - 2);
            if (currentVector[cleanTag] === 0) delete currentVector[cleanTag];
          }
        });
        updateDoc(doc(db, 'users', user.Id_user), { interestVector: currentVector }).catch(() => {});
      }
    }
    const updated = [...hiddenIds, reelId];
    setHiddenIds(updated);
    localStorage.setItem('teblock_hidden', JSON.stringify(updated));
    setMenuId(null);
  };

  const handleStartEditReel = (reel: Reel) => {
    setMenuId(null);
    setEditingReel(reel);
    setEditCaption(reel.caption || "");
  };

  const handleSaveEditReel = async () => {
    if (!editingReel || isSavingEdit) return;
    setIsSavingEdit(true);
    try {
      const newHashtags = extractHashtags(editCaption || "");
      const encCaption = encryptText(editCaption || "");

      await updateDoc(doc(db, 'reels', editingReel.id), {
        caption: encCaption,
        keywords: newHashtags,
        hashtags: newHashtags,
        updatedAt: serverTimestamp()
      });

      // Update in reelsManager
      reelsManager.updateLocalReel(editingReel.id, prev => ({
        ...prev,
        caption: editCaption,
        keywords: newHashtags,
        hashtags: newHashtags
      }));

      // Update local state so UI updates immediately
      setAllRawReels(prev => prev.map(r => r.id === editingReel.id ? {
        ...r,
        caption: editCaption,
        keywords: newHashtags,
        hashtags: newHashtags
      } : r));

      setReels(prev => prev.map(r => r.id === editingReel.id ? {
        ...r,
        caption: editCaption,
        keywords: newHashtags,
        hashtags: newHashtags
      } : r));

      setEditingReel(null);
    } catch (err) {
      console.error("Failed to update reel:", err);
      alert("تعذر حفظ التعديلات، يرجى التحقق من اتصالك والمحاولة مرة أخرى.");
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleConfirmDeleteReel = async () => {
    if (!deletingReel || isDeleting) return;
    setIsDeleting(true);
    try {
      const targetId = deletingReel.id;
      await deleteDoc(doc(db, 'reels', targetId));

      // Remove from reelsManager
      reelsManager.removeLocalReel(targetId);

      // Update local states
      setAllRawReels(prev => prev.filter(r => r.id !== targetId));
      setReels(prev => {
        const updated = prev.filter(r => r.id !== targetId);
        if (activeReelId === targetId && updated.length > 0) {
          setActiveReelId(updated[0].id);
        }
        return updated;
      });

      setDeletingReel(null);
    } catch (err) {
      console.error("Failed to delete reel:", err);
      alert("تعذر حذف الريلز، يرجى المحاولة مرة أخرى.");
    } finally {
      setIsDeleting(false);
    }
  };

  // Fetch publisher profile details (to know if author is a page and get followersList)
  useEffect(() => {
    if (reels.length === 0) return;
    const userIds: string[] = Array.from(new Set(reels.map(r => r.userId))).filter(
      (id): id is string => Boolean(id && id !== user.Id_user && !publisherMap[id])
    );
    if (userIds.length === 0) return;

    userIds.forEach(async (pubId) => {
      try {
        const snap = await getDoc(doc(db, 'users', pubId));
        if (snap.exists()) {
          const uData = snap.data() as User;
          setPublisherMap(prev => ({
            ...prev,
            [pubId]: {
              accountType: uData.accountType || 'user',
              followersList: uData.followersList || []
            }
          }));
        }
      } catch (e) {
        console.warn("Failed to fetch publisher info", pubId, e);
      }
    });
  }, [reels, user.Id_user, publisherMap]);

  const handleToggleFollowPage = async (pageUserId: string) => {
    const currentInfo = publisherMap[pageUserId];
    const isFollowing = (currentInfo?.followersList || []).includes(user.Id_user) || (user.followingList || []).includes(pageUserId);

    // Optimistic local update
    setPublisherMap(prev => {
      const existingList = prev[pageUserId]?.followersList || [];
      return {
        ...prev,
        [pageUserId]: {
          accountType: 'page',
          followersList: isFollowing
            ? existingList.filter(id => id !== user.Id_user)
            : [...existingList, user.Id_user]
        }
      };
    });

    try {
      const pageRef = doc(db, 'users', pageUserId);
      const currentUserRef = doc(db, 'users', user.Id_user);

      await updateDoc(pageRef, {
        followersList: isFollowing ? arrayRemove(user.Id_user) : arrayUnion(user.Id_user),
        followersCount: increment(isFollowing ? -1 : 1)
      });

      await updateDoc(currentUserRef, {
        followingList: isFollowing ? arrayRemove(pageUserId) : arrayUnion(pageUserId),
        followingCount: increment(isFollowing ? -1 : 1)
      });

      if (!isFollowing) {
        await addDoc(collection(db, 'notifications'), {
          toId: pageUserId,
          fromId: user.Id_user,
          fromName: user.UserData,
          fromPhoto: user.photoURL || "",
          type: 'follow',
          read: false,
          timestamp: serverTimestamp(),
          content: `${user.UserData} بدأ بمتابعة صفحتك`
        });
      }
    } catch (err) {
      console.error("Failed to toggle follow page:", err);
    }
  };

  const toggleCommentLike = async (comment: Comment) => {
    const ref = doc(db, 'comments', comment.id);
    const isLiked = comment.likes?.includes(user.Id_user);
    await updateDoc(ref, { 
      likes: isLiked ? arrayRemove(user.Id_user) : arrayUnion(user.Id_user) 
    });

    if (!isLiked && comment.userId !== user.Id_user) {
      await addDoc(collection(db, 'notifications'), {
        toId: comment.userId,
        fromId: user.Id_user,
        fromName: user.UserData,
        fromPhoto: user.photoURL,
        type: 'like',
        read: false,
        timestamp: serverTimestamp(),
        relatedId: activeCommentsReel?.id,
        content: `${user.UserData} ${t('reels.likedYourComment')}`
      });
    }
  };

  const postComment = async () => {
    if (!commentText.trim() || !activeCommentsReel || isProcessingAction) return;
    setIsProcessingAction(true);
    const text = commentText;
    setCommentText("");
    setShowEmojiPicker(false);
    const parentId = replyTo?.id;
    const replyToName = replyTo?.userName;
    setReplyTo(null);

    try {
      const commentDoc = await addDoc(collection(db, 'comments'), {
        reelId: activeCommentsReel.id, 
        userId: user.Id_user, 
        userName: user.UserData,
        userPhoto: user.photoURL, 
        text: encryptText(text), 
        timestamp: serverTimestamp(),
        likes: [],
        parentId: parentId || null,
        replyToName: replyToName || null
      });

      await updateDoc(doc(db, 'reels', activeCommentsReel.id), { commentsCount: increment(1) });
      setReels(prev => prev.map(r => r.id === activeCommentsReel.id ? { ...r, commentsCount: (r.commentsCount || 0) + 1 } : r));
      reelsManager.updateLocalReel(activeCommentsReel.id, prev => ({ ...prev, commentsCount: (prev.commentsCount || 0) + 1 }));

      // Notifications
      if (parentId && replyTo?.userId !== user.Id_user) {
        await addDoc(collection(db, 'notifications'), {
          toId: replyTo.userId,
          fromId: user.Id_user,
          fromName: user.UserData,
          fromPhoto: user.photoURL,
          type: 'comment',
          content: encryptText(text),
          read: false,
          timestamp: serverTimestamp(),
          relatedId: activeCommentsReel.id
        });
      } else if (!parentId && activeCommentsReel.userId !== user.Id_user) {
        await addDoc(collection(db, 'notifications'), {
          toId: activeCommentsReel.userId,
          fromId: user.Id_user,
          fromName: user.UserData,
          fromPhoto: user.photoURL,
          type: 'comment',
          content: encryptText(text),
          read: false,
          timestamp: serverTimestamp(),
          relatedId: activeCommentsReel.id
        });
      }

      // Check for mentions in text
      const mentions = text.match(/@(\S+)/g);
      if (mentions) {
        for (const m of mentions) {
          const mentionedName = m.substring(1);
          const friend = friends.find(f => f.UserData === mentionedName);
          if (friend && friend.Id_user !== user.Id_user) {
            await addDoc(collection(db, 'notifications'), {
              toId: friend.Id_user,
              fromId: user.Id_user,
              fromName: user.UserData,
              fromPhoto: user.photoURL,
              type: 'comment',
              content: `${user.UserData} ${t('reels.mentionedYou')}`,
              read: false,
              timestamp: serverTimestamp(),
              relatedId: activeCommentsReel.id
            });
          }
        }
      }
    } catch (e) { console.error(e); } finally { setIsProcessingAction(false); }
  };

  const handleInputChange = (val: string) => {
    setCommentText(val);
    const lastAtPos = val.lastIndexOf('@');
    if (lastAtPos !== -1 && lastAtPos >= val.length - 15) {
      setMentionSearch(val.substring(lastAtPos + 1));
      setShowMentionList(true);
    } else {
      setShowMentionList(false);
    }
  };

  const insertMention = (name: string) => {
    const lastAtPos = commentText.lastIndexOf('@');
    const beforeAt = commentText.substring(0, lastAtPos);
    setCommentText(beforeAt + "@" + name + " ");
    setShowMentionList(false);
    commentInputRef.current?.focus();
  };

  const handleOpenProfileById = (targetId?: string) => {
    if (!targetId || !onNavigateProfile) return;
    setActiveCommentsReel(null);
    onNavigateProfile(targetId);
  };

  const handleOpenProfileByMention = async (mentionName: string) => {
    if (!onNavigateProfile) return;
    const clean = mentionName.replace(/^@/, '').trim();
    if (!clean) return;
    const friendMatch = friends.find(
      f => f.UserData?.toLowerCase() === clean.toLowerCase() || f.Id_user?.toLowerCase() === clean.toLowerCase()
    );
    if (friendMatch) {
      handleOpenProfileById(friendMatch['id-2'] || friendMatch.Id_user);
      return;
    }
    try {
      const snap = await getDocs(query(collection(db, 'users'), where('UserData', '==', clean), limit(1)));
      if (!snap.empty) {
        const d = snap.docs[0].data() as any;
        handleOpenProfileById(d['id-2'] || d.Id_user || snap.docs[0].id);
        return;
      }
      const snapId = await getDocs(query(collection(db, 'users'), where('Id_user', '==', clean), limit(1)));
      if (!snapId.empty) {
        const d = snapId.docs[0].data() as any;
        handleOpenProfileById(d['id-2'] || d.Id_user || snapId.docs[0].id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const renderCommentTextWithMentions = (text: string) => {
    if (!text) return null;
    const parts = text.split(/(@\S+)/g);
    return parts.map((part, idx) => {
      if (part.startsWith('@') && part.length > 1) {
        return (
          <button
            key={idx}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleOpenProfileByMention(part);
            }}
            className="text-blue-400 font-black hover:underline mx-0.5 inline"
          >
            {part}
          </button>
        );
      }
      return <React.Fragment key={idx}>{part}</React.Fragment>;
    });
  };

  return (
    <div ref={containerRef} dir={dir} className="flex-1 h-full overflow-y-scroll snap-y snap-mandatory custom-scrollbar scroll-smooth bg-black relative" onClick={() => setShowEmojiPicker(false)}>
      {/* Active Hashtag Filter Banner */}
      {selectedHashtag && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[80] bg-blue-600/95 backdrop-blur-md px-4 py-1.5 rounded-full border border-blue-400/40 text-white text-xs font-black shadow-xl flex items-center space-x-2 space-x-reverse animate-in fade-in slide-in-from-top-2">
          <span>تصفية: {selectedHashtag.startsWith('#') ? selectedHashtag : `#${selectedHashtag}`}</span>
          <button 
            onClick={(e) => { e.stopPropagation(); setSelectedHashtag(null); }} 
            className="bg-black/30 hover:bg-black/50 rounded-full p-1 text-white mr-1 active:scale-90 transition-transform"
            title="إلغاء التصفية"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
          </button>
        </div>
      )}

      {reels.length === 0 && selectedHashtag && (
        <div className="h-full w-full flex flex-col items-center justify-center text-center p-6 text-white space-y-4">
          <div className="w-16 h-16 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-2xl font-bold text-blue-400">#</div>
          <h3 className="text-base font-black">لا توجد مقاطع حالياً لهاشتاغ {selectedHashtag}</h3>
          <p className="text-xs text-slate-400 max-w-xs">يمكنك نشر أول مقطع بهذا الهاشتاغ أو استكشاف هاشتاغات أخرى!</p>
          <button 
            onClick={() => setSelectedHashtag(null)}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 rounded-2xl font-black text-xs text-white shadow-lg shadow-blue-600/30 transition-all"
          >
            عرض جميع الفيديوهات
          </button>
        </div>
      )}

      {reels.map((reel, index) => (
        <React.Fragment key={reel.id}>
        <div className="h-full w-full snap-start snap-always relative flex items-center justify-center bg-black">
          <ReelItem
            reel={reel}
            isActive={activeReelId === reel.id}
            isMuted={isMuted}
            onDoubleTap={toggleLike}
          />

          {showBackButton && onBack && (
            <div className="absolute top-4 left-4 z-50">
              <button
                onClick={onBack}
                className="px-3 py-2 rounded-xl glass text-white border border-white/15 active:scale-95 transition-all flex items-center gap-1.5 shadow-lg"
                title="رجوع"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
                <span className="text-xs font-black">رجوع</span>
              </button>
            </div>
          )}

          <div className="absolute top-4 right-4 z-50">
            <button onClick={() => setIsMuted(!isMuted)} className="p-2 sm:p-2.5 rounded-xl glass text-white border border-white/10 active:scale-95 transition-all">
              {isMuted ? <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5.586 15L4 16.586V7.414L5.586 9H8l4-4v14l-4-4H5.586zM17 14l2-2" strokeWidth={2}/></svg> : <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z" strokeWidth={2}/></svg>}
            </button>
          </div>
          <div className="absolute right-2 bottom-3 flex flex-col space-y-2 z-50 items-center">
            {/* Like */}
            <button onClick={() => toggleLike(reel)} className="flex flex-col items-center group">
              <div className={`p-2 sm:p-2.5 rounded-xl glass border border-white/10 active:scale-90 transition-transform ${reel.likes.includes(user.Id_user) ? 'text-blue-500' : 'text-white'}`}>
                <svg className="w-5 h-5" fill={reel.likes.includes(user.Id_user) ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" strokeWidth={2}/></svg>
              </div>
              <span className="text-white text-[7.5px] font-black mt-0.5">{reel.likes.length}</span>
            </button>

            {/* Comment */}
            <button onClick={() => setActiveCommentsReel(reel)} className="flex flex-col items-center group">
              <div className="p-2 sm:p-2.5 rounded-xl glass border border-white/10 text-white active:scale-90 transition-transform">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 12h.01M12 12h.01M16 12h.01" strokeWidth={2}/><path d="M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" strokeWidth={2}/></svg>
              </div>
              <span className="text-white text-[7.5px] font-black mt-0.5">{reel.commentsCount}</span>
            </button>

            {/* Share */}
            <button onClick={() => { setActiveShareReel(reel); setShowShareModal(true); }} className="flex flex-col items-center group">
              <div className="p-2 sm:p-2.5 rounded-xl glass border border-white/10 text-white active:scale-90 transition-transform">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" strokeWidth={2}/></svg>
              </div>
              <span className="text-white text-[7.5px] font-black mt-0.5">{t('reels.shareBtn')}</span>
            </button>

            {/* Save */}
            <button onClick={() => toggleSave(reel.id, reel)} className="flex flex-col items-center group">
              <div className={`p-2 sm:p-2.5 rounded-xl glass border border-white/10 active:scale-90 transition-transform ${savedReels.includes(reel.id) ? 'text-yellow-500' : 'text-white'}`}>
                <svg className="w-5 h-5" fill={savedReels.includes(reel.id) ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24"><path d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" strokeWidth={2}/></svg>
              </div>
              <span className="text-white text-[7.5px] font-black mt-0.5">{t('reels.saveBtn')}</span>
            </button>

            {/* More Menu */}
            <div className="relative">
              <button 
                onClick={() => setMenuId(menuId === reel.id ? null : reel.id)} 
                className={`p-2 sm:p-2.5 rounded-xl glass border active:scale-90 transition-transform ${reel.userId === user.Id_user ? 'border-blue-500/40 text-blue-400' : 'border-white/10 text-white'}`}
                title={reel.userId === user.Id_user ? "خيارات المنشور (تعديل / حذف)" : "خيارات"}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z" strokeWidth={2}/></svg>
              </button>
              {menuId === reel.id && (
                <div className="absolute bottom-full right-0 mb-2 w-36 bg-slate-900/95 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200 z-50">
                  {reel.userId === user.Id_user ? (
                    <>
                      <button 
                        onClick={() => handleStartEditReel(reel)} 
                        className="w-full p-2.5 text-right text-[11px] font-black text-blue-400 hover:bg-white/5 flex items-center justify-between border-b border-white/5 transition-colors"
                      >
                        <span>تعديل المنشور</span>
                        <svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                      </button>
                      <button 
                        onClick={() => { setMenuId(null); setDeletingReel(reel); }} 
                        className="w-full p-2.5 text-right text-[11px] font-black text-red-500 hover:bg-red-500/10 flex items-center justify-between transition-colors"
                      >
                        <span>حذف الريلز</span>
                        <svg className="w-4 h-4 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                      </button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => handleReport(reel)} className="w-full p-2.5 text-right text-[10px] font-black text-red-500 hover:bg-white/5 border-b border-white/5">{t('reels.reportBtn')}</button>
                      <button onClick={() => handleNotInterested(reel.id)} className="w-full p-2.5 text-right text-[10px] font-black text-slate-300 hover:bg-white/5">{t('reels.notInterestedBtn')}</button>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
          <div className="absolute left-4 bottom-5 right-20 text-white text-right pointer-events-none z-30">
            <div className="flex items-center mb-2 space-x-2 space-x-reverse flex-wrap gap-y-1">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleOpenProfileById(reel.userId);
                }}
                className="pointer-events-auto flex items-center space-x-2 space-x-reverse hover:opacity-80 transition-opacity cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg border border-white/20 overflow-hidden ml-2 shrink-0">
                  <img src={reel.userPhoto || `https://api.dicebear.com/7.x/bottts/svg?seed=${reel.userId}`} className="w-full h-full object-cover" />
                </div>
                <h4 className="font-black text-xs">@{reel.userName}</h4>
              </button>

              {/* Follow Button if publisher is a Page */}
              {(() => {
                const isPage = reel.accountType === 'page' || publisherMap[reel.userId]?.accountType === 'page';
                if (!isPage || reel.userId === user.Id_user) return null;

                const isFollowing = (publisherMap[reel.userId]?.followersList || []).includes(user.Id_user) || (user.followingList || []).includes(reel.userId);

                return (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleFollowPage(reel.userId);
                    }}
                    className={`pointer-events-auto text-[10px] font-black px-3 py-1 rounded-full transition-all flex items-center space-x-1 space-x-reverse shadow-md active:scale-95 mr-2 ${
                      isFollowing
                        ? 'bg-white/10 hover:bg-white/20 text-slate-200 border border-white/20 backdrop-blur-md'
                        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/40 border border-blue-400/40'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <svg className="w-3 h-3 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>
                        <span>متابع</span>
                      </>
                    ) : (
                      <>
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4"/></svg>
                        <span>متابعة</span>
                      </>
                    )}
                  </button>
                );
              })()}
            </div>
            <div className="text-[11px] font-bold leading-relaxed bg-black/60 px-3 py-1.5 rounded-xl backdrop-blur-md border border-white/10 inline-block max-w-[88%] pointer-events-auto shadow-lg">
              {renderCaptionWithHashtags(reel.caption, (tag) => handleHashtagClick(tag))}
            </div>
          </div>
        </div>

        </React.Fragment>
      ))}

      {showShareModal && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in" onClick={() => setShowShareModal(false)}>
          <div className="w-full max-w-sm bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
            <div className="p-6 border-b border-white/5 flex justify-between items-center">
              <h3 className="text-xs font-black text-white uppercase tracking-widest">{t('reels.shareWithFriends')}</h3>
              <button onClick={() => setShowShareModal(false)} className="text-slate-500"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6" strokeWidth={3}/></svg></button>
            </div>
            <div className="p-4">
              <div className="relative mb-4">
                <input 
                  type="text" 
                  value={shareSearch || ""}
                  onChange={e => setShareSearch(e.target.value)}
                  placeholder={t('reels.searchFriendPlaceholder')}
                  className="w-full bg-black/40 border border-white/5 rounded-2xl px-4 py-3 text-[10px] font-bold text-white outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
              <div className="max-h-64 overflow-y-auto custom-scrollbar space-y-2">
                {friends.filter(f => f.UserData.toLowerCase().includes(shareSearch.toLowerCase())).map(f => (
                  <button 
                    key={f.id}
                    onClick={() => shareToFriend(f)}
                    className="w-full flex items-center justify-between p-3 hover:bg-white/5 rounded-2xl transition-colors group"
                  >
                    <div className="flex items-center space-x-3 space-x-reverse">
                      <img src={f.photoURL} className="w-10 h-10 rounded-xl border border-white/10" />
                      <span className="text-[10px] font-black text-slate-200">{f.UserData}</span>
                    </div>
                    <div className="w-8 h-8 bg-blue-600/20 text-blue-500 rounded-lg flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
                    </div>
                  </button>
                ))}
                {friends.length === 0 && <p className="text-center text-[9px] text-slate-500 py-4">{t('reels.noFriendsToShare')}</p>}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeCommentsReel && (
        <div className="fixed inset-0 z-[200] flex items-end justify-center backdrop-blur-md bg-black/40 animate-in slide-in-from-bottom" onClick={() => setShowEmojiPicker(false)}>
          <div className="w-full max-w-lg bg-slate-900 rounded-t-[3.5rem] h-[75vh] flex flex-col shadow-2xl border-t border-white/10" onClick={e => e.stopPropagation()}>
            <div className="p-7 border-b border-white/5 flex justify-between items-center">
              <h3 className="font-black text-sm text-blue-500 uppercase">{t('reels.commentsTitle')}</h3>
              <button onClick={() => setActiveCommentsReel(null)} className="glass p-3 rounded-2xl"><svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6" strokeWidth={3}/></svg></button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
              {comments.filter(c => !c.parentId).map(c => (
                <div key={c.id} className="space-y-4">
                  <div className="flex space-x-4 space-x-reverse items-start">
                    <button type="button" onClick={() => handleOpenProfileById(c.userId)} className="shrink-0 hover:opacity-80 transition-opacity">
                      <img src={c.userPhoto || `https://api.dicebear.com/7.x/bottts/svg?seed=${c.userId}`} className="w-10 h-10 rounded-xl object-cover" />
                    </button>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <button type="button" onClick={() => handleOpenProfileById(c.userId)} className="text-[11px] font-black text-blue-400 mb-1 hover:underline">@{c.userName}</button>
                        <button onClick={() => toggleCommentLike(c)} className={`flex items-center space-x-1 space-x-reverse ${c.likes?.includes(user.Id_user) ? 'text-blue-500' : 'text-slate-500'}`}>
                          <svg className="w-4 h-4" fill={c.likes?.includes(user.Id_user) ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" strokeWidth={2}/></svg>
                          <span className="text-[9px] font-bold">{c.likes?.length || 0}</span>
                        </button>
                      </div>
                      <p className="text-xs text-slate-200 bg-white/5 p-3 rounded-2xl rounded-tr-none mb-2">{renderCommentTextWithMentions(c.text)}</p>
                      <button onClick={() => { setReplyTo(c); setCommentText(`@${c.userName} `); commentInputRef.current?.focus(); }} className="text-[9px] font-black text-slate-500 uppercase hover:text-blue-500 transition-colors">{t('reels.replyBtn')}</button>
                    </div>
                  </div>
                  
                  {/* Replies */}
                  {comments.filter(r => r.parentId === c.id).map(r => (
                    <div key={r.id} className="flex space-x-4 space-x-reverse items-start mr-10 border-r-2 border-white/5 pr-4">
                      <button type="button" onClick={() => handleOpenProfileById(r.userId)} className="shrink-0 hover:opacity-80 transition-opacity">
                        <img src={r.userPhoto || `https://api.dicebear.com/7.x/bottts/svg?seed=${r.userId}`} className="w-8 h-8 rounded-lg object-cover" />
                      </button>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <button type="button" onClick={() => handleOpenProfileById(r.userId)} className="text-[10px] font-black text-blue-400 mb-1 hover:underline">@{r.userName}</button>
                          <button onClick={() => toggleCommentLike(r)} className={`flex items-center space-x-1 space-x-reverse ${r.likes?.includes(user.Id_user) ? 'text-blue-500' : 'text-slate-500'}`}>
                            <svg className="w-3.5 h-3.5" fill={r.likes?.includes(user.Id_user) ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" strokeWidth={2}/></svg>
                            <span className="text-[8px] font-bold">{r.likes?.length || 0}</span>
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-300 bg-white/5 p-2 rounded-xl rounded-tr-none mb-1">{renderCommentTextWithMentions(r.text)}</p>
                        <button onClick={() => { setReplyTo(c); setCommentText(`@${r.userName} `); commentInputRef.current?.focus(); }} className="text-[8px] font-black text-slate-600 uppercase hover:text-blue-500 transition-colors">{t('reels.replyBtn')}</button>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
            <div className="p-6 glass border-t border-white/5 flex flex-col space-y-3 relative">
              {replyTo && (
                <div className="flex justify-between items-center bg-blue-600/10 p-2 rounded-xl border border-blue-500/20">
                  <span className="text-[9px] font-bold text-blue-400">{t('reels.replyingTo')}{replyTo.userName}</span>
                  <button onClick={() => setReplyTo(null)} className="text-slate-500"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6" strokeWidth={2}/></svg></button>
                </div>
              )}
              <div className="flex items-center space-x-3 space-x-reverse relative">
                <div className="relative flex-1">
                   {showMentionList && friends.length > 0 && (
                     <div className="absolute bottom-full mb-2 left-0 w-full bg-slate-900 border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-[300]">
                       {friends.filter(f => f.UserData.toLowerCase().includes(mentionSearch.toLowerCase())).map(f => (
                         <button 
                          key={f.id} 
                          onMouseDown={(e) => {
                            e.preventDefault();
                            insertMention(f.UserData);
                          }} 
                          className="w-full p-3 flex items-center space-x-3 space-x-reverse hover:bg-white/5 text-right border-b border-white/5 last:border-0"
                         >
                           <img src={f.photoURL} className="w-6 h-6 rounded-lg" />
                           <span className="text-[10px] font-bold text-white">{f.UserData}</span>
                         </button>
                       ))}
                     </div>
                   )}
                   <button onClick={(e) => { e.stopPropagation(); setShowEmojiPicker(!showEmojiPicker); }} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-yellow-500 transition-colors">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01" strokeWidth={2}/></svg>
                   </button>
                   <input 
                    ref={commentInputRef}
                    value={commentText || ""} 
                    onChange={e => handleInputChange(e.target.value)} 
                    onKeyPress={e => e.key === 'Enter' && postComment()} 
                    className="w-full bg-black/20 border border-white/5 rounded-2xl pl-12 pr-5 py-4 text-xs font-bold text-white outline-none focus:ring-2 focus:ring-blue-600" 
                    placeholder={t('reels.addComment')} 
                   />
                </div>
                <button disabled={isProcessingAction || !commentText.trim()} onClick={postComment} className="bg-blue-600 w-14 h-14 rounded-2xl text-white flex items-center justify-center shadow-xl shadow-blue-600/30">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14" /></svg>
                </button>
              </div>
              {showEmojiPicker && (
                <div className="absolute bottom-24 right-0 w-72 h-64 bg-slate-900 border border-white/10 rounded-[2rem] shadow-3xl overflow-hidden z-[300] flex flex-col">
                   <div className="flex-1 overflow-y-auto p-3 custom-scrollbar space-y-4">
                      {recentEmojis.length > 0 && (
                        <div>
                          <p className="text-[7px] font-black text-slate-600 uppercase mb-2">{t('reels.recentEmojis')}</p>
                          <div className="grid grid-cols-6 gap-2">{recentEmojis.map(e => <button key={e} onClick={() => handleEmojiSelect(e)} className="p-1 flex items-center justify-center hover:bg-white/10 rounded-lg active:scale-125 transition-transform"><EmojiImg emoji={e} size={22} /></button>)}</div>
                        </div>
                      )}
                      {EMOJI_CATEGORIES.map(cat => (
                        <div key={cat.name}>
                          <p className="text-[7px] font-black text-slate-600 uppercase mb-2">{cat.name}</p>
                          <div className="grid grid-cols-6 gap-2">{cat.emojis.map(e => <button key={e} onClick={() => handleEmojiSelect(e)} className="p-1 flex items-center justify-center hover:bg-white/10 rounded-lg active:scale-125 transition-transform"><EmojiImg emoji={e} size={22} /></button>)}</div>
                        </div>
                      ))}
                   </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Loading next chunk indicator */}
      {isLoadingMore && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 bg-blue-600/90 backdrop-blur-xl text-white px-5 py-2.5 rounded-full text-xs font-black shadow-2xl flex items-center space-x-2 space-x-reverse border border-blue-400/40 z-[250] animate-in fade-in slide-in-from-bottom-2">
          <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          <span>{t('reels.autoFetchingNext')}</span>
        </div>
      )}

      {/* Data Saver & Preload Info Modal */}
      {showDataSaverModal && (
        <div className="fixed inset-0 z-[400] flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in" onClick={() => setShowDataSaverModal(false)}>
          <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-[2.5rem] p-6 shadow-2xl space-y-5 text-right animate-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center space-x-2 space-x-reverse">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                </div>
                <div>
                  <h3 className="font-black text-sm text-white">{t('reels.dataSaverModalTitle')}</h3>
                  <span className="text-[10px] text-emerald-400 font-bold">{t('reels.dataSaverTech')}</span>
                </div>
              </div>
              <button onClick={() => setShowDataSaverModal(false)} className="p-2 text-slate-500 hover:text-white">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>

            {/* Compression Information Callout */}
            <div className="bg-emerald-950/40 border border-emerald-500/30 p-3.5 rounded-2xl space-y-1">
              <div className="flex items-center space-x-2 space-x-reverse text-emerald-400 font-black text-xs">
                <span>⚡</span>
                <span>فيديوهات الريلز الحالية مضغوطة بالكامل:</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
                تم ضغط جميع المقاطع الـ 8 من <strong>100 MB</strong> إلى <strong>~12.5 MB</strong> فقط عبر تقنية Transcoding الذكية (720p HD). وفرت أكثر من 82% من استهلاك الباقة وتعمل فوراً بدون تقطيع.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="bg-white/5 border border-white/10 p-3 rounded-2xl">
                <span className="text-[10px] text-slate-400 font-bold block mb-1">{t("reels.estSavings")}</span>
                <span className="text-xl font-black text-emerald-400">~82%</span>
              </div>
              <div className="bg-white/5 border border-white/10 p-3 rounded-2xl">
                <span className="text-[10px] text-slate-400 font-bold block mb-1">{t("reels.dataSaved")}</span>
                <span className="text-xl font-black text-blue-400">~88 MB</span>
              </div>
            </div>

            <div className="space-y-3 bg-black/40 p-4 rounded-2xl border border-white/5 text-[11px] leading-relaxed text-slate-300">
              <div className="flex items-start space-x-2 space-x-reverse">
                <span className="text-emerald-400 font-bold ml-1">✓</span>
                <p><strong className="text-white">{t('reels.chunkUnit')}:</strong> {t('reels.chunkUnitDesc')}</p>
              </div>
              <div className="flex items-start space-x-2 space-x-reverse">
                <span className="text-emerald-400 font-bold ml-1">✓</span>
                <p><strong className="text-white">{t('reels.fetchReason')}:</strong> {t('reels.fetchReasonDesc')}</p>
              </div>
              <div className="flex items-start space-x-2 space-x-reverse">
                <span className="text-emerald-400 font-bold ml-1">✓</span>
                <p><strong className="text-white">{t('reels.zeroWait')}:</strong> {t('reels.zeroWaitDesc')}</p>
              </div>
            </div>

            <div className="text-[10px] text-slate-400 flex justify-between px-1">
              <span>{t('reels.loadedReels')} <strong>{reels.length}</strong></span>
              <span>{t('reels.batchesLoaded')} <strong>{managerStats.totalChunksLoaded}</strong></span>
              <span>{t('reels.preloadedVideos')} <strong>{managerStats.preloadedVideosCount}</strong></span>
            </div>

            {/* Video Streaming Quality Selector */}
            <div className="space-y-2 bg-black/40 p-3.5 rounded-2xl border border-white/5 rtl:text-right ltr:text-left">
              <label className="text-[10px] font-black text-slate-300 block">{t('reels.qualityTitle') || 'جودة البث وسرعة التحميل'}</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setVideoQualityPreference('saver');
                    setQualityMode('saver');
                    reelsManager.resetAndRefresh();
                  }}
                  className={`p-2 rounded-xl text-[10px] font-bold border transition-all ${qualityMode === 'saver' ? 'bg-emerald-600 border-emerald-500 text-white shadow-md' : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'}`}
                >
                  <span className="block font-black">{t('reels.qualitySaver') || 'توفير فائق'}</span>
                  <span className="text-[8px] opacity-75">540p / 850k</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setVideoQualityPreference('auto');
                    setQualityMode('auto');
                    reelsManager.resetAndRefresh();
                  }}
                  className={`p-2 rounded-xl text-[10px] font-bold border transition-all ${qualityMode === 'auto' ? 'bg-blue-600 border-blue-500 text-white shadow-md' : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'}`}
                >
                  <span className="block font-black">{t('reels.qualityAuto') || 'تلقائي ذكي'}</span>
                  <span className="text-[8px] opacity-75">720p HD</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setVideoQualityPreference('high');
                    setQualityMode('high');
                    reelsManager.resetAndRefresh();
                  }}
                  className={`p-2 rounded-xl text-[10px] font-bold border transition-all ${qualityMode === 'high' ? 'bg-purple-600 border-purple-500 text-white shadow-md' : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'}`}
                >
                  <span className="block font-black">{t('reels.qualityHigh') || 'دقة عالية'}</span>
                  <span className="text-[8px] opacity-75">1080p FHD</span>
                </button>
              </div>
            </div>

            <button 
              onClick={() => setShowDataSaverModal(false)}
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-xs transition-colors"
            >
              {t('reels.gotItBtn')}
            </button>
          </div>
        </div>
      )}

      {/* Edit Reel Modal */}
      {editingReel && (
        <div 
          className="fixed inset-0 z-[350] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in" 
          onClick={() => !isSavingEdit && setEditingReel(null)}
        >
          <div 
            dir={dir}
            className="w-full max-w-md bg-slate-900 border border-white/10 rounded-[2rem] shadow-2xl overflow-hidden p-6 animate-in zoom-in-95 duration-200 text-right" 
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-white/5">
              <div className="flex items-center space-x-2.5 space-x-reverse">
                <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">تعديل الريلز</h3>
                  <p className="text-[10px] text-slate-400 font-bold">تعديل الوصف والهاشتاغات لتحديث التوصيات</p>
                </div>
              </div>
              <button 
                onClick={() => setEditingReel(null)} 
                disabled={isSavingEdit}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1.5">الوصف والهاشتاغات:</label>
                <textarea
                  value={editCaption}
                  onChange={e => setEditCaption(e.target.value)}
                  rows={4}
                  placeholder="اكتب وصفاً للفيديو مع هاشتاغات (مثال: #fortnite #العاب #ترند)..."
                  className="w-full bg-black/50 border border-white/10 rounded-2xl p-3.5 text-xs text-white outline-none focus:border-blue-500 resize-none transition-colors"
                />
              </div>

              {/* Quick Hashtag Suggestions */}
              <div>
                <div className="flex items-center justify-between mb-1.5 px-0.5">
                  <span className="text-[10px] text-slate-400 font-bold">إضافة هاشتاغ مقترح:</span>
                  <span className="text-[9px] text-blue-400 font-mono">#هاشتاغ</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {POPULAR_HASHTAGS.map(tag => {
                    const isSelected = editCaption.toLowerCase().includes(tag.toLowerCase());
                    return (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => {
                          setEditCaption(prev => {
                            if (prev.toLowerCase().includes(tag.toLowerCase())) return prev;
                            return prev ? `${prev.trim()} ${tag}` : tag;
                          });
                        }}
                        className={`text-[10px] px-2.5 py-1 rounded-xl font-bold transition-all ${
                          isSelected 
                            ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30 border border-blue-400/40' 
                            : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                        }`}
                      >
                        {tag}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Extracted Hashtags Preview */}
              {extractHashtags(editCaption).length > 0 && (
                <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-[10px] text-blue-300 font-bold flex items-center justify-between">
                  <span className="text-slate-400">الهاشتاغات المكتشفة:</span>
                  <span className="font-mono text-blue-400 font-black">{extractHashtags(editCaption).join(' ')}</span>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button
                  onClick={handleSaveEditReel}
                  disabled={isSavingEdit}
                  className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 text-white font-black text-xs rounded-2xl shadow-lg shadow-blue-600/30 transition-all disabled:opacity-50 flex items-center justify-center space-x-1.5 space-x-reverse"
                >
                  {isSavingEdit ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <span>حفظ التعديلات</span>
                  )}
                </button>
                <button
                  onClick={() => setEditingReel(null)}
                  disabled={isSavingEdit}
                  className="px-5 py-3 bg-white/5 hover:bg-white/10 text-slate-300 font-black text-xs rounded-2xl border border-white/10 transition-all"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Reel Confirmation Modal */}
      {deletingReel && (
        <div 
          className="fixed inset-0 z-[350] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in" 
          onClick={() => !isDeleting && setDeletingReel(null)}
        >
          <div 
            dir={dir}
            className="w-full max-w-sm bg-slate-900 border border-white/10 rounded-[2rem] shadow-2xl overflow-hidden p-6 text-center animate-in zoom-in-95 duration-200" 
            onClick={e => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-500 flex items-center justify-center mx-auto mb-3">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            </div>
            <h3 className="text-sm font-black text-white mb-1.5">حذف مقطع الريلز</h3>
            <p className="text-[11px] text-slate-400 font-bold mb-5 leading-relaxed">
              هل أنت متأكد من رغبتك في حذف هذا الفيديو نهائياً؟ لن يتمكن أي شخص من مشاهدته مرة أخرى ولا يمكن التراجع عن هذا الإجراء.
            </p>
            
            <div className="flex gap-3">
              <button
                onClick={handleConfirmDeleteReel}
                disabled={isDeleting}
                className="flex-1 py-3 bg-red-600 hover:bg-red-500 text-white font-black text-xs rounded-2xl shadow-lg shadow-red-600/30 transition-all disabled:opacity-50 flex items-center justify-center space-x-1.5 space-x-reverse"
              >
                {isDeleting ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <span>نعم، حذف نهائي</span>
                )}
              </button>
              <button
                onClick={() => setDeletingReel(null)}
                disabled={isDeleting}
                className="px-5 py-3 bg-white/5 hover:bg-white/10 text-slate-300 font-black text-xs rounded-2xl border border-white/10 transition-all"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReelsView;
