import React from 'react';
import { useLanguage } from '../utils/i18n';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAgree?: () => void;
  showAgreeBtn?: boolean;
}

export const TermsModal: React.FC<TermsModalProps> = ({
  isOpen,
  onClose,
  onAgree,
  showAgreeBtn = false
}) => {
  const { dir } = useLanguage();

  if (!isOpen) return null;

  return (
    <div dir={dir} className="fixed inset-0 z-[1100] bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-slate-900 border border-white/10 rounded-3xl sm:rounded-[2.5rem] p-5 sm:p-8 flex flex-col max-h-[88vh] shadow-2xl relative overflow-hidden">
        
        {/* Header */}
        <div className="flex justify-between items-start gap-4 pb-4 border-b border-white/10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-black uppercase tracking-wider mb-2">
              <span>📜 وثيقة قانونية ملزمة</span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-white leading-tight">
              الشروط والأحكام العامة وسياسة الخصوصية لمنصة "تِبلوك" (Teblock)
            </h3>
            <p className="text-[10px] text-slate-400 font-bold mt-1">
              تاريخ النشر أو آخر تحديث: 28 أكتوبر 2026
            </p>
          </div>
          <button 
            type="button" 
            onClick={onClose} 
            className="p-2 bg-white/5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors shrink-0" 
            title="إغلاق"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar pr-1 pl-1 py-4 space-y-6 text-right text-xs text-slate-300 leading-relaxed font-normal">
          
          {/* المقدمة والتمهيد */}
          <div className="bg-blue-950/30 border border-blue-500/20 p-4 rounded-2xl">
            <h4 className="text-sm font-black text-blue-400 mb-2">مقدمة وتمهيد</h4>
            <p className="text-[11px] leading-relaxed text-slate-200 mb-3">
              مرحباً بك في منصة وتطبيق <strong className="text-white">"تِبلوك" (Teblock)</strong>. يُرجى قراءة شروط وسياسة الاستخدام هذه بعناية فائقة وتأمل قبل الشروع في إنشاء حساب، أو تصفح المنصة، أو استخدام أي من خدماتها (بما في ذلك المراسلات، رفع الوسائط، والمكالمات الصوتية).
            </p>
            <p className="text-[11px] leading-relaxed text-slate-200 mb-3">
              إن استخدامك لتطبيق Teblock بأي شكل من الأشكال، أو الضغط على "موافق" أو "تسجيل حساب"، يُمثل إقراراً صريحاً وموافقة قانونية ملزمة منك على قبول كافة البنود، الشروط، والإشعارات الواردة في هذه الوثيقة دون تعديل أو تحفظ. إذا كنت لا توافق على أي بند من هذه الشروط، فعليك التوقف فوراً عن استخدام التطبيق وحذف التطبيق من جهازك.
            </p>
            <p className="text-[10px] text-slate-400 font-semibold">
              تُدار منصة Teblock كمشروع برمجي وتقني فردي ومستقل من قِبل المطور (المشار إليه فيما بعد بـ "نحن"، "المطور"، "الجهة المشرفة"، أو "إدارة التطبيق")، وتخضع لضوابط تشغيلية تقنية تعتمد على خدمات السحابية الخارجية مثل Firebase وCloudinary.
            </p>
          </div>

          {/* البند الأول */}
          <section className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl space-y-2">
            <h4 className="text-sm font-black text-blue-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-black">1</span>
              البند الأول: التعريفات الأساسية
            </h4>
            <p className="text-[11px] text-slate-400">في هذه الشروط، تكون للكلمات والعبارات التالية المعاني المخصصة لها أدناه، ما لم يقتضِ السياق خلاف ذلك:</p>
            <ul className="space-y-2 text-[11px] pr-2">
              <li>
                <strong className="text-white">"المنصة" أو "التطبيق" أو "Teblock":</strong> يشير إلى تطبيق التواصل الاجتماعي بجميع نسخه الرقمية (تطبيقات الهواتف الذكية، واجهات الويب، والمواقع المرتبطة بالدومين الرسمي والمطور).
              </li>
              <li>
                <strong className="text-white">"المستخدم" أو "أنت" أو "صاحب الحساب":</strong> كل شخص طبيعي يقوم بالوصول إلى التطبيق، أو تصفحه، أو إنشاء حساب شخصي واستخدامه للتواصل أو رفع المحتوى.
              </li>
              <li>
                <strong className="text-white">"المحتوى":</strong> كافة البيانات، النصوص، الروابط، الصور، المقاطع المرئية (الفيديوهات)، والتسجيلات التي يتم رفعها أو تخزينها أو تبادلها عبر المنصة.
              </li>
              <li>
                <strong className="text-white">"خدمات الجهات الخارجية":</strong> تشمل الخدمات التقنية المرتبطة بالبنية التحتية مثل منصة Firebase (للمصادقة وقاعدة البيانات) ومنصة Cloudinary (لإدارة ومعالجة الوسائط).
              </li>
            </ul>
          </section>

          {/* البند الثاني */}
          <section className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl space-y-2">
            <h4 className="text-sm font-black text-blue-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-black">2</span>
              البند الثاني: شروط الأهلية والتحقق من العمر
            </h4>
            <ul className="space-y-2 text-[11px] pr-2">
              <li>
                <strong className="text-white">الحد الأدنى للسن القانوني:</strong> التطبيق مخصص حصرياً للمستخدمين البالغين أو القادرين قانوناً على استخدام منصات التواصل الاجتماعي. بناءً على سياسة المنصة وحماية للقصر، يشترط ألا يقل عمر المستخدم عن السن القانوني المسموح به محلياً ودولياً (13 عاماً فما فوق كحد أدنى، أو حسب قوانين بلد الإقامة).
              </li>
              <li>
                <strong className="text-white">بيانات التحقق من العمر:</strong> لغرض حصر استخدام التطبيق ومنع القصر غير المسموح لهم، نطلب فقط إدخال تاريخ الميلاد والجنس أثناء عملية إنشاء الحساب. لا نطلب ولا نجمع أي أرقام هواتف شخصية أو وثائق رسمية تدل على الهوية الشخصية الحقيقية أثناء التسجيل العادي.
              </li>
              <li>
                <strong className="text-white">مسؤولية الحساب:</strong> أنت وحدك المسؤول عن سرية بيانات الدخول الخاصة بك، وتتحمل المسؤولية الكاملة عن أي نشاط يتم من خلال حسابك.
              </li>
            </ul>
          </section>

          {/* البند الثالث */}
          <section className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl space-y-2">
            <h4 className="text-sm font-black text-blue-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-black">3</span>
              البند الثالث: طبيعة المكالمات الصوتية وتقنية الاتصال المباشر (P2P)
            </h4>
            <ul className="space-y-2 text-[11px] pr-2">
              <li>
                <strong className="text-white">آلية الاتصال المباشر (Peer-to-Peer):</strong> يوفر التطبيق ميزة المكالمات الصوتية بنظام الاتصال المباشر بين الطرفين (P2P)، مما يعني أن تدفق الصوت يتم مباشرة بين جهازي المستخدمين المتصلين.
              </li>
              <li>
                <strong className="text-white">الخوادم الوسيطة المؤقتة:</strong> لا تملك المنصة أي سيرفرات وسيطة تقوم بتسجيل، مراقبة، أو تخزين محتوى المكالمات الصوتية أو تفاصيلها الكلامية. يتم استخدام خوادم تشغيلية مؤقتة فقط لغرض تبادل وتخزين عناوين بروتوكول الإنترنت (IP Addresses) بشكل مؤقت ولازم لإنشاء وتوجيه الاتصال بين الطرفين. وبمجرد إنهاء المكالمة أو إتمامها، تُحذف هذه العناوين المؤقتة فوراً وبشكل نهائي من الذاكرة المؤقتة.
              </li>
            </ul>
          </section>

          {/* البند الرابع */}
          <section className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl space-y-3">
            <h4 className="text-sm font-black text-blue-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-black">4</span>
              البند الرابع: سياسة البيانات والخصوصية (Firebase و Cloudinary)
            </h4>
            
            <div className="space-y-2">
              <h5 className="text-xs font-black text-white">1. معلومات الحساب والتخزين (Firebase):</h5>
              <ul className="list-disc list-inside space-y-1 text-[11px] pr-2 text-slate-300">
                <li>نعتمد على بنية Firebase لتسجيل وحفظ مُعرف الحساب الفريد (User ID) وكلمات المرور المشفرة بأحدث خوارزميات التشفير.</li>
                <li>الأسماء المستخدمة في الحسابات هي أسماء اختيارية وغير ملزمة بأن تكون أسماء حقيقية.</li>
                <li>لا تقوم المنصة بجمع أو تتبع أي بيانات للموقع الجغرافي (GPS) الخاص بالمستخدمين.</li>
              </ul>
            </div>

            <div className="space-y-2 pt-2 border-t border-white/5">
              <h5 className="text-xs font-black text-white">2. إدارة الوسائط والملفات (Cloudinary):</h5>
              <ul className="list-disc list-inside space-y-1 text-[11px] pr-2 text-slate-300">
                <li>يتم رفع ومعالجة الصور، الرموز التعبيرية، الملفات، والفيديوهات التي يشاركها المستخدمون عبر خدمة التخزين السحابي الموثوقة Cloudinary.</li>
                <li>يتحمل المستخدم المسؤولية الكاملة عن طبيعة ونوعية الملفات التي يقوم برفعها وتخزينها عبر هذه الخدمة.</li>
              </ul>
            </div>

            <div className="space-y-2 pt-2 border-t border-white/5">
              <h5 className="text-xs font-black text-white">3. التحكم وحذف البيانات:</h5>
              <p className="text-[11px]">يمنحك تطبيق Teblock سيطرة كاملة ومرنة على حسابك وبياناتك، حيث يمكنك في أي وقت اختيار:</p>
              <ul className="list-disc list-inside space-y-1 text-[11px] pr-2 text-slate-300">
                <li>تجميد الحساب مؤقتاً وإيقاف ظهوره.</li>
                <li>حذف الحساب نهائياً من قواعد البيانات.</li>
                <li>حذف بيانات محددة بشكل انتقائي (مثل رسائل معينة، فيديوهات، أو وسائط مرفوعة على Cloudinary) دون الحاجة إلى حذف الحساب الكامل إن لم ترغب في ذلك.</li>
              </ul>
            </div>
          </section>

          {/* البند الخامس */}
          <section className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl space-y-2">
            <h4 className="text-sm font-black text-blue-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-black">5</span>
              البند الخامس: قواعد السلوك والاستخدام المقبول
            </h4>
            <p className="text-[11px] text-slate-400">
              بصفتك عضواً في مجتمع Teblock، فإنك تتعهد وتلتزم بالامتناع تماماً عن أي ممارسات تضر بالمنصة أو مستخدميها، ويُحظر تماماً:
            </p>
            <ul className="space-y-1.5 text-[11px] pr-2 text-slate-300">
              <li className="flex items-start gap-1.5">
                <span className="text-red-400">✖</span>
                <span>نشر أو تداول أي محتوى يخالف الآداب العامة، أو ينتهك القوانين والتشريعات المحلية أو القوانين الدولية.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-400">✖</span>
                <span>استخدام التطبيق في التهديد، المضايقة، الابتزاز، التشهير، أو إزعاج المستخدمين الآخرين بأي شكل من الأشكال.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-400">✖</span>
                <span>نشر محتوى يحض على الكراهية، العنف، التمييز العنصري، أو الطائفي، أو نشر المواد الإباحية والمخالفة للآداب العامة.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-400">✖</span>
                <span>محاولة اختراق التطبيق، التلاعب بقواعد بيانات Firebase، استغلال الثغرات الأمنية، أو استخدام برمجيات غير مرخصة (Bots / Scrappers) لجمع بيانات المستخدمين الآخرين.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-400">✖</span>
                <span>انتحال صفة أي شخص، جهة، أو علامة تجارية أخرى من خلال الحساب.</span>
              </li>
            </ul>
          </section>

          {/* البند السادس */}
          <section className="bg-red-950/20 border border-red-500/20 p-4 rounded-2xl space-y-2">
            <h4 className="text-sm font-black text-red-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center text-[10px] font-black">6</span>
              البند السادس: إخلاء المسؤولية القانونية (مشروع فردي)
            </h4>
            <p className="text-[11px] text-amber-300/90 font-bold mb-1">يُرجى قراءة هذا البند بعناية بالغة وحرفية:</p>
            <ul className="space-y-2 text-[11px] pr-2 text-slate-300">
              <li>
                <strong className="text-white">طبيعة الكيان:</strong> إن تطبيق وموقع Teblock هو "مشروع فردي وتقني مستقل" يطوره مطور برمجيات فرد، وليس شركة تجارية أو كيان اعتباري مسجل رسمياً حتى تاريخه.
              </li>
              <li>
                <strong className="text-white">الخدمة بحالتها الراهنة ("As Is"):</strong> يتم توفير التطبيق والخدمات المرتبطة به على أساس "حسب المتاح" و"بالحالة التي عليها"، ودون أي ضمانات صريحة أو ضمنية من أي نوع، بما في ذلك ضمانات ملاءمة الاستخدام التجاري أو الأمان المطلق.
              </li>
              <li>
                <strong className="text-white">إخلاء المسؤولية عن المحتوى:</strong> لا يتحمل المطور الفردي أو التطبيق أي مسؤولية قانونية أو أدبية عن المحتوى الذي ينشره المستخدمون أو يتبادلونه أو يخزنونه عبر Cloudinary، والمستخدم وحده هو المسؤول مسؤولية تامة وقانونية عن أي أضرار أو نتائج مترتبة على ما ينشره.
              </li>
              <li>
                <strong className="text-white">الانقطاع والأعطال التقنية:</strong> لا يضمن المطور أن يكون التطبيق خالياً من الأخطاء التقنية، أو انقطاعات الخدمة، أو المشاكل المتعلقة بسلاسل سحابات التخزين الخارجية (مثل Firebase أو Cloudinary)، ولا يتحمل المطور أي مسؤولية عن أي فقدان للبيانات، أو أضرار مباشرة أو غير مباشرة تنشأ عن استخدام أو عدم القدرة على استخدام التطبيق.
              </li>
            </ul>
          </section>

          {/* البند السابع */}
          <section className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl space-y-2">
            <h4 className="text-sm font-black text-blue-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-black">7</span>
              البند السابع: تعديل الشروط وتحديثاتها
            </h4>
            <p className="text-[11px] text-slate-300">
              يحق لمطور تطبيق Teblock تعديل، تغيير، أو تحديث هذه الشروط والأحكام في أي وقت ووفقاً لما تقتضيه مصلحة العمل أو التحديثات البرمجية والقانونية. يتم نشر النسخة المحدثة هنا، ويُعد استمرارك في استخدام التطبيق بعد تاريخ النشر موافقة قاطعة لا رجعة فيها على هذه التعديلات.
            </p>
          </section>

          {/* البند الثامن */}
          <section className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl space-y-2">
            <h4 className="text-sm font-black text-blue-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-black">8</span>
              البند الثامن: القانون الواجب التطبيق وتسوية النزاعات
            </h4>
            <ul className="space-y-2 text-[11px] pr-2 text-slate-300">
              <li>
                <strong className="text-white">القانون الحاكم:</strong> تُفسر هذه الشروط وتخضع كافة النزاعات المتعلقة بها للتشريعات والقوانين المعمول بها في الدولة المحلية للأطراف المعنية.
              </li>
              <li>
                <strong className="text-white">تسوية النزاعات:</strong> في حال نشوب أي مشكل أو خلاف بين أي طرفين، يتم حله بين الطرفين بالطرق الودية أولاً، وفي حال تعذر ذلك يتم حل كل مشكل بين الطرفين في دولتهما المحلية وفقاً للقوانين والأنظمة المعمول بها فيها.
              </li>
            </ul>
          </section>

          {/* البند التاسع */}
          <section className="bg-blue-900/10 border border-blue-500/20 p-4 rounded-2xl space-y-2">
            <h4 className="text-sm font-black text-blue-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-black">9</span>
              البند التاسع: تواصل معنا والدعم الفني
            </h4>
            <p className="text-[11px] text-slate-300">
              نحن هنا دائماً للاستماع إلى استفساراتكم أو تلقي طلباتكم المتعلقة بإدارة الحسابات أو حذف البيانات. يمكنك التواصل معنا حصرياً عبر البريد الإلكتروني الرسمي للمشروع:
            </p>
            <div className="bg-black/30 p-3 rounded-xl border border-white/5 space-y-1 text-[11px]">
              <p>
                <span className="text-slate-400">البريد الإلكتروني للدعم: </span>
                <a href="mailto:samaspearu@gmail.com" className="text-blue-400 font-bold hover:underline dir-ltr inline-block">
                  samaspearu@gmail.com
                </a>
              </p>
              <p>
                <span className="text-slate-400">صفحة المنصة الرسمية: </span>
                <span className="text-slate-200 font-mono">teblock.web.app</span>
              </p>
            </div>
            <p className="text-center text-[10px] font-black text-slate-500 pt-2">
              جميع الحقوق محفوظة لمنصة ومشروع Teblock © 2026
            </p>
          </section>

          {/* البند العاشر: الذكاء الاصطناعي ومراجعة سياق المحادثات */}
          <section className="bg-blue-950/20 border border-blue-500/20 p-4 rounded-2xl space-y-2">
            <h4 className="text-sm font-black text-blue-400 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-black">10</span>
              البند العاشر: الذكاء الاصطناعي ومراجعة سياق المحادثات (TeBLOCK AI)
            </h4>
            <ul className="space-y-2 text-[11px] pr-2">
              <li>
                <strong className="text-white">التفاعل عبر التاغ في المحادثات الخاصة والمجموعات:</strong> يتيح التطبيق إمكانية استدعاء المساعد الذكي <span className="text-blue-300 font-bold">@TeBLOCK AI</span> أو <span className="text-blue-300 font-bold">@ai</span> داخل المحادثات الخاصة أو المجموعات.
              </li>
              <li>
                <strong className="text-white">مراجعة السياق ونبرة الحديث:</strong> عند قيامك بالإشارة إلى المساعد الذكي (تاغ)، يقوم النظام تلقائياً بمراجعة آخر الرسائل في تلك المحادثة بشكل لحظي ومؤقت فقط لفهم الموضوع المطروح ومعرفة نبرة الكلام (سواء كان مزاحاً أو نقاشاً جدياً) لتقديم أفضل وأدق إجابة ممكنة.
              </li>
              <li>
                <strong className="text-white">الخصوصية وعدم التدريب:</strong> لا يطلع المساعد الذكي على محادثاتك الخاصة إلا في اللحظة التي تقوم فيها باستدعائه عبر التاغ، وتُستخدم الرسائل المراجعة حصرياً لتوليد الرد الفوري دون تخزينها بشكل دائم أو مشاركتها مع أي طرف آخر.
              </li>
            </ul>
          </section>

        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row gap-2 shrink-0">
          {showAgreeBtn && onAgree && (
            <button 
              type="button" 
              onClick={onAgree} 
              className="flex-1 bg-blue-600 text-white font-black py-3 rounded-xl hover:bg-blue-500 transition-all shadow-lg shadow-blue-600/20 text-xs sm:text-sm"
            >
              أوافق على كافة الشروط وسياسة الخصوصية
            </button>
          )}
          <button 
            type="button" 
            onClick={onClose} 
            className={`${showAgreeBtn ? 'sm:w-32 bg-white/5 hover:bg-white/10 text-slate-300' : 'w-full bg-blue-600 hover:bg-blue-500 text-white'} font-black py-3 rounded-xl transition-all text-xs sm:text-sm`}
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};

export default TermsModal;
