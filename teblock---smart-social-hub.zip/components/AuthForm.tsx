import React, { useState, useEffect, useRef } from 'react';
import { AuthMode, User } from '../types';
import { db } from '../firebase';
import { encryptText, decryptText } from "../utils/crypto";
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { generatePermanentId2 } from '../utils/userUtils';
import { useLanguage } from '../utils/i18n';
import LanguageModal from './LanguageModal';
import TermsModal from './TermsModal';

interface AuthFormProps {
  onAuthSuccess: (user: User) => void;
  onBackToPicker?: () => void;
}

const COUNTRIES_LIST = [
  { id: 'morocco', key: 'country.morocco', fallback: 'المغرب' },
  { id: 'saudi', key: 'country.saudi', fallback: 'السعودية' },
  { id: 'uae', key: 'country.uae', fallback: 'الإمارات' },
  { id: 'qatar', key: 'country.qatar', fallback: 'قطر' },
  { id: 'egypt', key: 'country.egypt', fallback: 'مصر' },
  { id: 'algeria', key: 'country.algeria', fallback: 'الجزائر' },
  { id: 'tunisia', key: 'country.tunisia', fallback: 'تونس' },
  { id: 'jordan', key: 'country.jordan', fallback: 'الأردن' },
  { id: 'kuwait', key: 'country.kuwait', fallback: 'الكويت' },
  { id: 'oman', key: 'country.oman', fallback: 'عمان' },
  { id: 'other', key: 'country.other', fallback: 'أخرى' },
];

const AuthForm: React.FC<AuthFormProps> = ({ onAuthSuccess, onBackToPicker }) => {
  const { t, langInfo, dir } = useLanguage();
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  const [mode, setMode] = useState<AuthMode>('login');
  const formRef = useRef<HTMLFormElement>(null);
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    password: '',
    gender: 'male',
    country: 'المغرب',
    birthDate: '',
    accountType: 'user'
  });
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [showTerms, setShowTerms] = useState(false);

  // Scroll to top of form when switching between login and signup
  useEffect(() => {
    if (formRef.current) {
      formRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [mode]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    if (!formData.id || !formData.password) {
      setError(t('auth.errFillAll'));
      setIsSubmitting(false);
      return;
    }

    try {
      const userDocRef = doc(db, 'users', formData.id);

      if (mode === 'signup') {
        if (!agreeTerms) { setError(t('auth.errAgreeTerms')); setIsSubmitting(false); return; }
        if (!formData.name) { setError(t('auth.errNameRequired')); setIsSubmitting(false); return; }
        if (!formData.birthDate) { setError(t('auth.errBirthRequired')); setIsSubmitting(false); return; }

        const checkDoc = await getDoc(userDocRef);
        if (checkDoc.exists()) { setError(t('auth.errIdTaken')); setIsSubmitting(false); return; }

        const controlToken = Math.random().toString(36).substring(2, 15);

        const newUser: any = {
          Id_user: formData.id,
          'id-2': generatePermanentId2(),
          UserData: formData.name,
          gender: formData.gender,
          country: formData.country,
          birthDate: formData.birthDate,
          accountType: formData.accountType,
          Contrôler: controlToken,
          password: encryptText(formData.password),
          createdAt: new Date().toISOString(),
          Freechat: "يوجد",
          Freechat_unlock: "",
          Freepublishing: "يوجد",
          Freepublishing_unlock: "",
          Freeaccount: "يوجد",
          Freeaccount_unlock: "",
          postsCount: 0,
          followersCount: 0,
          followingCount: 0,
          photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${formData.id}`,
          hasAppealed: false // Default to false
        };

        await setDoc(userDocRef, newUser);
        
        // Log registration to server
        fetch('/api/log-activity', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'x-control-key': 'admin123'
          },
          body: JSON.stringify({ event: `New Registration: ${formData.id} (${formData.name})` })
        }).catch(console.error);

        const { password, ...userProfile } = newUser;
        onAuthSuccess(userProfile as User);
      } else {
        if (!agreeTerms) { setError(t('auth.errAgreeTerms')); setIsSubmitting(false); return; }
        const userDoc = await getDoc(userDocRef);
        if (!userDoc.exists()) { setError(t('auth.errNotFound')); setIsSubmitting(false); return; }
        const userData = userDoc.data();
        if (decryptText(userData.password) !== formData.password) { setError(t('auth.errWrongPassword')); setIsSubmitting(false); return; }

        if (userData.isDeactivated) {
          await updateDoc(userDocRef, { isDeactivated: false, deactivatedAt: null });
          userData.isDeactivated = false;
        }

        // Guarantee permanent 10-digit id-2 exists on the account
        if (!userData['id-2']) {
          const generatedId2 = generatePermanentId2();
          await updateDoc(userDocRef, { 'id-2': generatedId2 });
          userData['id-2'] = generatedId2;
        }
        
        onAuthSuccess(userData as User);
      }
    } catch (err: any) {
      setError(`${t('auth.errorPrefix')} ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return ( <>
    <div dir={dir} className="w-full max-w-md glass rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-500 my-auto flex flex-col max-h-[calc(100dvh-2rem)] sm:max-h-[92vh] relative">
      <div className="bg-gradient-to-b from-blue-600/20 to-transparent p-6 sm:p-7 text-center relative shrink-0">
        {onBackToPicker && (
          <button 
            type="button" 
            onClick={onBackToPicker} 
            className="absolute top-5 rtl:right-5 ltr:left-5 p-2 bg-white/5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-all"
            title={t('auth.backToPicker')}
          >
             <svg className="w-5 h-5 flip-in-ltr" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
          </button>
        )}

        {/* زر تبديل اللغة السريع للزوار الأجانب */}
        <button 
          type="button" 
          onClick={() => setShowLanguageModal(true)} 
          className="absolute top-5 rtl:left-5 ltr:right-5 p-2 bg-white/5 hover:bg-white/10 rounded-xl text-slate-300 flex items-center space-x-1.5 space-x-reverse font-bold text-xs border border-white/5 transition-all shadow-md active:scale-95"
          title={t('lang.title')}
        >
          <span>{langInfo.flag}</span>
          <span className="text-[10px] font-black">{langInfo.nativeName}</span>
        </button>

        <div className="inline-block p-3.5 bg-blue-600 rounded-3xl shadow-lg shadow-blue-500/20 mb-3">
          <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white tracking-tighter uppercase">TeBLOCK</h2>
        <p className="text-blue-400 text-[9px] font-bold uppercase tracking-[0.3em] mb-4">Identity Gateway</p>

        {/* Tab switchers at top for immediate clarity */}
        <div className="flex bg-black/40 p-1 rounded-2xl border border-white/5">
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`flex-1 py-2 rounded-xl text-xs font-black transition-all ${mode === 'login' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30' : 'text-slate-400 hover:text-white'}`}
          >
            {t('auth.login')}
          </button>
          <button
            type="button"
            onClick={() => setMode('signup')}
            className={`flex-1 py-2 rounded-xl text-xs font-black transition-all ${mode === 'signup' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30' : 'text-slate-400 hover:text-white'}`}
          >
            {t('auth.signup')}
          </button>
        </div>
      </div>

      <form 
        ref={formRef} 
        onSubmit={handleSubmit} 
        className="px-6 sm:px-10 pb-8 pt-2 space-y-4 overflow-y-auto custom-scrollbar flex-1 overscroll-contain"
      >
        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-2xl text-[10px] font-bold text-center animate-pulse">
            {error}
          </div>
        )}

        <div className="space-y-3">
          <input 
            type="text" 
            name="id" 
            value={formData.id || ""} 
            onChange={(e) => setFormData({...formData, id: e.target.value.toLowerCase().replace(/[^a-z0-9\-._]/g, '')})} 
            placeholder={t('auth.userId')} 
            className="w-full bg-black/40 border border-white/5 rounded-2xl px-5 py-3.5 text-white placeholder:text-slate-600 focus:ring-2 focus:ring-blue-600 outline-none text-sm font-bold transition-all" 
          />

          {mode === 'signup' && (
            <>
              <input 
                type="text" 
                name="name" 
                value={formData.name || ""} 
                onChange={(e) => setFormData({...formData, name: e.target.value})} 
                placeholder={t('auth.name')} 
                className="w-full bg-black/40 border border-white/5 rounded-2xl px-5 py-3.5 text-white placeholder:text-slate-600 focus:ring-2 focus:ring-blue-600 outline-none text-sm font-bold transition-all" 
              />
              
              <div className="space-y-1">
                <label className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">{t('auth.birthDate')}</label>
                <input 
                  type="date" 
                  value={formData.birthDate || ""}
                  onChange={(e) => setFormData({...formData, birthDate: e.target.value})}
                  className="w-full bg-black/40 border border-white/5 rounded-2xl px-5 py-3.5 text-white outline-none text-sm font-bold focus:ring-2 focus:ring-blue-600 transition-all appearance-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                   <label className="text-[8px] text-slate-500 font-bold uppercase">{t('auth.gender')}</label>
                   <select 
                    value={formData.gender || "male"}
                    onChange={(e) => setFormData({...formData, gender: e.target.value})}
                    className="w-full bg-black/40 border border-white/5 rounded-2xl px-4 py-3.5 text-white outline-none text-xs font-bold focus:ring-2 focus:ring-blue-600"
                  >
                    <option value="male" className="bg-slate-900">{t('auth.genderMale')}</option>
                    <option value="female" className="bg-slate-900">{t('auth.genderFemale')}</option>
                  </select>
                </div>

                <div className="space-y-1">
                   <label className="text-[8px] text-slate-500 font-bold uppercase">{t('auth.country')}</label>
                   <select 
                    value={formData.country || "المغرب"}
                    onChange={(e) => setFormData({...formData, country: e.target.value})}
                    className="w-full bg-black/40 border border-white/5 rounded-2xl px-4 py-3.5 text-white outline-none text-xs font-bold focus:ring-2 focus:ring-blue-600"
                  >
                    {COUNTRIES_LIST.map(c => (
                      <option key={c.id} value={c.fallback} className="bg-slate-900">
                        {t(c.key, c.fallback)}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                 <label className="text-[8px] text-slate-500 font-bold uppercase">{t('auth.accountType')}</label>
                 <div className="grid grid-cols-2 gap-3">
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, accountType: 'user'})}
                      className={`py-3 rounded-2xl border text-xs font-black transition-all ${formData.accountType === 'user' ? 'bg-blue-600 border-blue-600 text-white shadow-lg' : 'bg-black/20 border-white/5 text-slate-500'}`}
                    >{t('auth.typeUser')}</button>
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, accountType: 'page'})}
                      className={`py-3 rounded-2xl border text-xs font-black transition-all ${formData.accountType === 'page' ? 'bg-blue-600 border-blue-600 text-white shadow-lg' : 'bg-black/20 border-white/5 text-slate-500'}`}
                    >{t('auth.typePage')}</button>
                 </div>
              </div>
            </>
          )}

          <input 
            type="password" 
            name="password" 
            value={formData.password || ""} 
            onChange={(e) => setFormData({...formData, password: e.target.value})} 
            placeholder={t('auth.password')} 
            className="w-full bg-black/40 border border-white/5 rounded-2xl px-5 py-3.5 text-white placeholder:text-slate-600 focus:ring-2 focus:ring-blue-600 outline-none text-sm font-bold transition-all" 
          />
        </div>


        <div className="flex items-start space-x-3 space-x-reverse mb-6">
          <input 
            type="checkbox" 
            id="agreeTerms" 
            checked={agreeTerms}
            onChange={(e) => setAgreeTerms(e.target.checked)}
            className="mt-1 w-4 h-4 rounded border-white/20 bg-black/40 text-blue-600 focus:ring-blue-600 focus:ring-offset-0 focus:ring-offset-transparent cursor-pointer"
          />
          <label htmlFor="agreeTerms" className="text-[10px] text-slate-400 leading-relaxed cursor-pointer select-none">
            {t('auth.agreeTerms')} <button type="button" onClick={() => setShowTerms(true)} className="text-blue-400 font-bold hover:underline">({t('auth.agreeTerms')})</button>
          </label>
        </div>
        <button 
          type="submit" 
          disabled={isSubmitting || !agreeTerms} 
          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-3.5 rounded-2xl transition-all shadow-xl active:scale-95 disabled:opacity-50 relative overflow-hidden text-sm"
        >
          {isSubmitting ? '...' : (mode === 'login' ? t('auth.submitLogin') : t('auth.submitSignup'))}
        </button>
        
        <button 
          type="button" 
          onClick={() => setMode(mode === 'login' ? 'signup' : 'login')} 
          className="w-full text-slate-500 text-[10px] font-bold uppercase tracking-widest hover:text-blue-400 transition-colors"
        >
          {mode === 'login' ? t('auth.noAccount') : t('auth.haveAccount')}
        </button>
      </form>
    </div>
      <TermsModal 
        isOpen={showTerms}
        onClose={() => setShowTerms(false)}
        onAgree={() => {
          setAgreeTerms(true);
          setShowTerms(false);
        }}
        showAgreeBtn={true}
      />

      {showLanguageModal && (
        <LanguageModal onClose={() => setShowLanguageModal(false)} />
      )}
    </>
  );
};
export default AuthForm;
