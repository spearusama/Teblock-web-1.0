import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, deleteDoc, updateDoc, orderBy, getDocs, limit, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { Appeal } from '../types';
import { useLanguage } from '../utils/i18n';

export const AdminReportsView = ({ onBack }: { onBack: () => void }) => {
  const { t, dir } = useLanguage();
  const [activeTab, setActiveTab] = useState<'reports' | 'appeals'>('reports');
  const [reports, setReports] = useState<any[]>([]);
  const [appeals, setAppeals] = useState<Appeal[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Custom Modals State
  const [alertConfig, setAlertConfig] = useState<{ message: string, type: 'success' | 'error' } | null>(null);
  const [confirmConfig, setConfirmConfig] = useState<{ message: string, onConfirm: () => void } | null>(null);
  const [promptConfig, setPromptConfig] = useState<{ message: string, onConfirm: (val: string) => void } | null>(null);
  const [promptValue, setPromptValue] = useState("");

  // Penalty Modal State
  const [penaltyModal, setPenaltyModal] = useState<{ userId: string, reportId: string } | null>(null);
  const [penaltyType, setPenaltyType] = useState<'mute' | 'publishing' | 'ban'>('mute');
  const [penaltyDuration, setPenaltyDuration] = useState<number | 'forever'>(1); // hours
  const [penaltyReason, setPenaltyReason] = useState("");

  // Chat Context Modal State
  const [chatContextModal, setChatContextModal] = useState<{ chatId: string, reportId: string } | null>(null);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [loadingChat, setLoadingChat] = useState(false);

  useEffect(() => {
    const qReports = query(collection(db, 'reports'), orderBy('timestamp', 'desc'));
    const unsubReports = onSnapshot(qReports, (snap) => {
      setReports(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    }, () => setLoading(false));

    const qAppeals = query(collection(db, 'appeals'), orderBy('timestamp', 'desc'));
    const unsubAppeals = onSnapshot(qAppeals, (snap) => {
      setAppeals(snap.docs.map(d => ({ id: d.id, ...d.data() } as Appeal)));
    }, () => {});

    return () => {
      unsubReports();
      unsubAppeals();
    };
  }, []);

  const handleDeleteReport = (id: string) => {
    setConfirmConfig({
      message: t("admin.confirmDeleteReport"),
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'reports', id));
          setAlertConfig({ message: t("admin.reportDeleted"), type: 'success' });
        } catch (e) {
          setAlertConfig({ message: t("common.error"), type: 'error' });
        }
      }
    });
  };

  const handleDeleteContent = (report: any) => {
    setConfirmConfig({
      message: t("admin.confirmDeleteContent"),
      onConfirm: async () => {
        try {
          if (report.messageId && report.reportedChat) {
            await deleteDoc(doc(db, `chats/${report.reportedChat}/messages`, report.messageId));
          } else if (report.reelId) {
            await deleteDoc(doc(db, 'reels', report.reelId));
          }
          await deleteDoc(doc(db, 'reports', report.id));
          setAlertConfig({ message: t("admin.contentDeleted"), type: 'success' });
        } catch (e) {
          setAlertConfig({ message: t("common.error"), type: 'error' });
        }
      }
    });
  };

  const handleApplyPenalty = async () => {
    if (!penaltyModal) return;
    try {
      const userRef = doc(db, 'users', penaltyModal.userId);
      const reason = penaltyReason.trim() || t("admin.reasonGuidelines");

      if (penaltyType === 'mute') {
        if (penaltyDuration === 'forever') {
          await updateDoc(userRef, { 
            messagingRestrictedForever: true, 
            messagingRestrictionUntil: null,
            messagingRestrictionReason: reason,
            Freechat: "0",
            Freechat_unlock: "{¥}",
            hasAppealed: false
          });
        } else {
          const restrictedUntil = Date.now() + (penaltyDuration * 60 * 60 * 1000);
          await updateDoc(userRef, { 
            messagingRestrictionUntil: restrictedUntil, 
            messagingRestrictedForever: false,
            messagingRestrictionReason: reason,
            Freechat: "0",
            Freechat_unlock: new Date(restrictedUntil).toISOString(),
            hasAppealed: false
          });
        }
      } else if (penaltyType === 'publishing') {
        if (penaltyDuration === 'forever') {
          await updateDoc(userRef, {
            publishingRestrictedForever: true,
            publishingRestrictionUntil: null,
            publishingRestrictionReason: reason,
            Freepublishing: "0",
            Freepublishing_unlock: "{¥}",
            hasAppealed: false
          });
        } else {
          const restrictedUntil = Date.now() + (penaltyDuration * 60 * 60 * 1000);
          await updateDoc(userRef, {
            publishingRestrictionUntil: restrictedUntil,
            publishingRestrictedForever: false,
            publishingRestrictionReason: reason,
            Freepublishing: "0",
            Freepublishing_unlock: new Date(restrictedUntil).toISOString(),
            hasAppealed: false
          });
        }
      } else if (penaltyType === 'ban') {
        const unlockVal = penaltyDuration === 'forever' 
          ? "{¥}" 
          : new Date(Date.now() + (penaltyDuration * 60 * 60 * 1000)).toISOString();

        await updateDoc(userRef, {
          Freeaccount: "مقفول",
          Freeaccount_unlock: unlockVal,
          accountBanReason: reason,
          hasAppealed: false
        });
      }
      
      await deleteDoc(doc(db, 'reports', penaltyModal.reportId));
      setAlertConfig({ message: t("admin.penaltyApplied"), type: 'success' });
      setPenaltyModal(null);
      setPenaltyType('mute');
      setPenaltyReason('');
      setPenaltyDuration(1);
    } catch (e) {
      console.error(e);
      setAlertConfig({ message: t("common.error"), type: 'error' });
    }
  };

  const openChatContext = async (chatId: string, reportId: string) => {
    setChatContextModal({ chatId, reportId });
    setLoadingChat(true);
    try {
      const q = query(collection(db, `chats/${chatId}/messages`), orderBy('timestamp', 'desc'), limit(50));
      const snapshot = await getDocs(q);
      const msgs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })).reverse();
      setChatMessages(msgs);
    } catch (e) {
      setAlertConfig({ message: t("admin.chatEmptyOrDeleted"), type: 'error' });
    } finally {
      setLoadingChat(false);
    }
  };

  const handleUnban = () => {
    setPromptConfig({
      message: t("admin.unbanPromptMsg"),
      onConfirm: async (code) => {
        if (!code || !code.trim()) return;
        try {
          await updateDoc(doc(db, 'users', code.trim()), {
            Freeaccount: "يوجد",
            Freeaccount_unlock: "",
            accountBanReason: "",
            Freechat: "يوجد",
            Freechat_unlock: "",
            messagingRestrictionUntil: null,
            messagingRestrictedForever: false,
            messagingRestrictionReason: "",
            Freepublishing: "يوجد",
            Freepublishing_unlock: "",
            publishingRestrictionUntil: null,
            publishingRestrictedForever: false,
            publishingRestrictionReason: "",
            hasAppealed: false
          });
          setAlertConfig({ message: t("admin.allUnbannedSuccess"), type: 'success' });
        } catch (e) {
          setAlertConfig({ message: t("common.error"), type: 'error' });
        }
      }
    });
  };

  const handleApproveAppeal = (appeal: Appeal) => {
    setConfirmConfig({
      message: `${t("admin.confirmApproveAppeal")} (${appeal.userName || appeal.userId})?`,
      onConfirm: async () => {
        try {
          const userRef = doc(db, 'users', appeal.userId);
          await updateDoc(userRef, {
            Freeaccount: "يوجد",
            Freeaccount_unlock: "",
            accountBanReason: "",
            Freechat: "يوجد",
            Freechat_unlock: "",
            messagingRestrictionUntil: null,
            messagingRestrictedForever: false,
            messagingRestrictionReason: "",
            Freepublishing: "يوجد",
            Freepublishing_unlock: "",
            publishingRestrictionUntil: null,
            publishingRestrictedForever: false,
            publishingRestrictionReason: "",
            hasAppealed: false
          });

          await updateDoc(doc(db, 'appeals', appeal.id), {
            status: 'approved',
            resolvedAt: serverTimestamp()
          });

          setAlertConfig({ message: t("admin.appealApprovedSuccess"), type: 'success' });
        } catch (e) {
          console.error(e);
          setAlertConfig({ message: t("common.error"), type: 'error' });
        }
      }
    });
  };

  const handleRejectAppeal = (appeal: Appeal) => {
    setConfirmConfig({
      message: `${t("admin.confirmRejectAppeal")} (${appeal.userName || appeal.userId})?`,
      onConfirm: async () => {
        try {
          await updateDoc(doc(db, 'appeals', appeal.id), {
            status: 'rejected',
            resolvedAt: serverTimestamp()
          });
          setAlertConfig({ message: t("admin.appealRejectedSuccess"), type: 'success' });
        } catch (e) {
          setAlertConfig({ message: t("common.error"), type: 'error' });
        }
      }
    });
  };

  const handleDeleteAppeal = (appealId: string) => {
    setConfirmConfig({
      message: t("admin.confirmDeleteAppeal"),
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'appeals', appealId));
          setAlertConfig({ message: t("admin.appealDeletedSuccess"), type: 'success' });
        } catch (e) {
          setAlertConfig({ message: t("common.error"), type: 'error' });
        }
      }
    });
  };

  const pendingAppealsCount = appeals.filter(a => a.status === 'pending').length;

  return (
    <div dir={dir} className="flex flex-col h-full bg-[#0a0a0a] text-white animate-in fade-in select-none">
      {/* Header */}
      <header className="h-16 flex items-center justify-between px-4 border-b border-white/10 glass z-10 shrink-0">
        <div className="flex items-center space-x-2 space-x-reverse">
          <button onClick={onBack} className="p-2 text-slate-400 hover:text-white transition-colors">
             <svg className="w-6 h-6 transform rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7"/></svg>
          </button>
          <div>
            <h2 className="text-base font-black tracking-tighter text-red-500">{t("admin.dashboardTitle")}</h2>
            <p className="text-[10px] text-slate-400 font-bold">{t("admin.dashboardSub")}</p>
          </div>
        </div>
        <button onClick={handleUnban} className="px-3 py-1.5 bg-green-600/20 text-green-400 border border-green-500/30 rounded-xl text-[10px] font-black hover:bg-green-600/40 transition-colors shadow-lg">{t("admin.unbanManual")}</button>
      </header>

      {/* Tabs */}
      <div className="flex border-b border-white/10 bg-white/[0.02] px-4 pt-2 shrink-0">
        <button
          onClick={() => setActiveTab('reports')}
          className={`flex-1 py-3 text-xs font-black relative flex items-center justify-center space-x-2 space-x-reverse transition-colors ${activeTab === 'reports' ? 'text-red-400 border-b-2 border-red-500' : 'text-slate-400 hover:text-white'}`}
        >
          <span>{t("admin.reportsTab")}</span>
          {reports.length > 0 && (
            <span className="bg-red-500/20 text-red-400 text-[10px] px-2 py-0.5 rounded-full font-bold border border-red-500/30">
              {reports.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('appeals')}
          className={`flex-1 py-3 text-xs font-black relative flex items-center justify-center space-x-2 space-x-reverse transition-colors ${activeTab === 'appeals' ? 'text-blue-400 border-b-2 border-blue-500' : 'text-slate-400 hover:text-white'}`}
        >
          <span>{t("admin.appealsTab")}</span>
          {pendingAppealsCount > 0 && (
            <span className="bg-blue-500/20 text-blue-400 text-[10px] px-2 py-0.5 rounded-full font-bold border border-blue-500/30 animate-pulse">
              {pendingAppealsCount}
            </span>
          )}
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center p-12 text-slate-500">
            <div className="w-8 h-8 border-4 border-red-500 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-xs font-bold">{t("admin.loadingData")}</p>
          </div>
        ) : activeTab === 'reports' ? (
          // REPORTS TAB
          reports.length === 0 ? (
            <div className="text-center p-12 text-slate-500 font-bold bg-white/[0.02] border border-white/5 rounded-2xl">
              <svg className="w-12 h-12 mx-auto text-slate-600 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              <p>{t("admin.noReports")}</p>
            </div>
          ) : (
            reports.map(report => (
              <div key={report.id} className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col space-y-3 relative overflow-hidden group shadow-lg">
                <div className="absolute top-0 right-0 w-1.5 h-full bg-red-500 opacity-60"></div>
                
                <div className="flex justify-between items-start">
                  <div className="text-right flex-1">
                     <div className="flex items-center justify-end space-x-2 space-x-reverse mb-1">
                       <span className="text-[10px] bg-white/10 px-2 py-1 rounded border border-white/5 font-bold text-slate-300">{t("admin.reporter")}: {report.reportedBy}</span>
                       <button onClick={() => setPenaltyModal({ userId: report.reportedBy, reportId: report.id })} className="text-[10px] text-orange-400 font-bold hover:underline">{t("admin.spitePenalty")}</button>
                     </div>
                     
                     {report.reportedUser && (
                       <div className="flex items-center justify-end space-x-2 space-x-reverse mt-2">
                         <span className="text-xs font-black text-red-400">{t("admin.reportedUser")}: {report.reportedUser}</span>
                       </div>
                     )}
                     {report.type && (
                       <p className="text-[10px] text-blue-400 font-bold mt-1">
                         {t("admin.reportType")}: {report.type === "chat_report" ? t("admin.typePrivateChat") : report.type === "reel_report" ? t("admin.typeReel") : report.type}
                       </p>
                     )}
                  </div>
                  <span className="text-[10px] text-slate-500 bg-black/40 px-2 py-1 rounded-lg border border-white/5">
                    {report.timestamp?.toDate ? new Date(report.timestamp.toDate()).toLocaleDateString('ar-EG') : ''}
                  </span>
                </div>
                
                {report.text && (
                  <div className="bg-black/30 p-4 rounded-xl border border-white/5 text-sm mt-2">
                    <p className="font-bold text-slate-400 text-xs mb-2">{t("admin.reportContent")}</p>
                    <p className="text-white break-words leading-relaxed">{report.text}</p>
                  </div>
                )}

                <div className="flex flex-wrap gap-2 pt-3 mt-2 border-t border-white/5">
                   {report.reportedUser && (
                     <button 
                       onClick={() => setPenaltyModal({ userId: report.reportedUser, reportId: report.id })}
                       className="px-4 py-2.5 bg-red-600/20 text-red-400 border border-red-500/30 rounded-xl text-[11px] font-black hover:bg-red-600/40 transition-colors shadow-lg shadow-red-900/20"
                     >{t("admin.setPenalty")}</button>
                   )}
                   {(report.messageId || report.reelId) && (
                     <button 
                       onClick={() => handleDeleteContent(report)}
                       className="px-4 py-2.5 bg-orange-600/20 text-orange-400 border border-orange-500/30 rounded-xl text-[11px] font-black hover:bg-orange-600/40 transition-colors"
                     >{t("admin.deleteContent")}</button>
                   )}
                   
                   {report.reportedChat && (
                     <button 
                       onClick={() => openChatContext(report.reportedChat, report.id)}
                       className="px-4 py-2.5 bg-blue-600/20 text-blue-400 border border-blue-500/30 rounded-xl text-[11px] font-black hover:bg-blue-600/40 transition-colors"
                     >{t("admin.viewChat")}</button>
                   )}

                   <button 
                     onClick={() => handleDeleteReport(report.id)}
                     className="px-4 py-2.5 bg-white/5 text-slate-400 border border-white/10 rounded-xl text-[11px] font-black hover:bg-white/10 transition-colors mr-auto"
                   >{t("admin.dismissReport")}</button>
                </div>
              </div>
            ))
          )
        ) : (
          // APPEALS TAB
          appeals.length === 0 ? (
            <div className="text-center p-12 text-slate-500 font-bold bg-white/[0.02] border border-white/5 rounded-2xl">
              <svg className="w-12 h-12 mx-auto text-slate-600 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
              <p>{t("admin.noAppeals")}</p>
            </div>
          ) : (
            appeals.map(appeal => (
              <div key={appeal.id} className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col space-y-3 relative overflow-hidden group shadow-lg">
                <div className={`absolute top-0 right-0 w-1.5 h-full ${appeal.status === 'approved' ? 'bg-green-500' : appeal.status === 'rejected' ? 'bg-red-500' : 'bg-blue-500'}`}></div>

                <div className="flex justify-between items-start">
                  <div className="text-right flex-1">
                    <div className="flex items-center justify-end space-x-2 space-x-reverse mb-1">
                      <span className="text-xs font-black text-white">{appeal.userName || t('admin.user')}</span>
                      <span className="text-[10px] text-slate-400 font-bold bg-black/40 px-2 py-0.5 rounded border border-white/5">ID: {appeal.userId}</span>
                    </div>

                    <div className="flex items-center justify-end space-x-2 space-x-reverse mt-2">
                      <span className="text-[10px] px-2 py-1 rounded font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                        {appeal.restrictionType === 'messaging' ? t('admin.appealMessaging') : appeal.restrictionType === 'publishing' ? t('admin.appealPublishing') : appeal.restrictionType === 'account' ? t('admin.appealAccount') : t('admin.appealGeneral')}
                      </span>
                      <span className={`text-[10px] px-2 py-1 rounded font-bold border ${
                        appeal.status === 'approved' ? 'bg-green-500/10 text-green-400 border-green-500/20' :
                        appeal.status === 'rejected' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                        'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                      }`}>
                        {appeal.status === 'approved' ? t('admin.statusApproved') : appeal.status === 'rejected' ? t('admin.statusRejected') : t('admin.statusPending')}
                      </span>
                    </div>
                  </div>

                  <span className="text-[10px] text-slate-500 bg-black/40 px-2 py-1 rounded-lg border border-white/5">
                    {appeal.timestamp?.toDate ? new Date(appeal.timestamp.toDate()).toLocaleDateString('ar-EG') : ''}
                  </span>
                </div>

                {/* Appeal Reason & Notes */}
                <div className="bg-black/30 p-4 rounded-xl border border-white/5 text-sm mt-2">
                  <p className="font-bold text-slate-400 text-xs mb-1">{t("admin.appealReasonNotes")}</p>
                  <p className="text-white font-bold text-xs mb-2">
                    {appeal.reason === 'innocent' ? t('admin.reasonInnocent') : appeal.reason === 'apology' ? t('admin.reasonApology') : appeal.reason}
                  </p>
                  {appeal.userExplanation && (
                    <p className="text-slate-300 text-xs bg-white/5 p-2 rounded-lg leading-relaxed border border-white/5">
                      {appeal.userExplanation}
                    </p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-2 pt-3 mt-2 border-t border-white/5">
                  {appeal.status === 'pending' && (
                    <>
                      <button
                        onClick={() => handleApproveAppeal(appeal)}
                        className="px-4 py-2.5 bg-green-600/20 text-green-400 border border-green-500/30 rounded-xl text-[11px] font-black hover:bg-green-600/40 transition-colors shadow-lg shadow-green-900/20 flex items-center space-x-1.5 space-x-reverse"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7"/></svg>
                        <span>{t("admin.approveAppeal")}</span>
                      </button>

                      <button
                        onClick={() => handleRejectAppeal(appeal)}
                        className="px-4 py-2.5 bg-red-600/20 text-red-400 border border-red-500/30 rounded-xl text-[11px] font-black hover:bg-red-600/40 transition-colors"
                      >{t("admin.rejectAppeal")}</button>
                    </>
                  )}

                  <button
                    onClick={() => handleDeleteAppeal(appeal.id)}
                    className="px-4 py-2.5 bg-white/5 text-slate-400 border border-white/10 rounded-xl text-[11px] font-black hover:bg-white/10 transition-colors mr-auto"
                  >{t("admin.deleteRecord")}</button>
                </div>
              </div>
            ))
          )
        )}
      </div>

      {/* Alert Modal */}
      {alertConfig && (
        <div className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-6 animate-in zoom-in">
          <div className="bg-slate-900 border border-white/10 p-6 rounded-2xl w-full max-w-sm text-center shadow-2xl">
            <p className={`text-sm font-bold mb-6 ${alertConfig.type === 'error' ? 'text-red-400' : 'text-green-400'}`}>
              {alertConfig.message}
            </p>
            <button onClick={() => setAlertConfig(null)} className="w-full bg-white/10 hover:bg-white/20 text-white font-bold py-3 rounded-xl transition-colors">{t("common.ok")}</button>
          </div>
        </div>
      )}

      {/* Confirm Modal */}
      {confirmConfig && (
        <div className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-6 animate-in zoom-in">
          <div className="bg-slate-900 border border-white/10 p-6 rounded-2xl w-full max-w-sm text-right shadow-2xl">
            <p className="text-sm font-bold text-white mb-6 leading-relaxed">
              {confirmConfig.message}
            </p>
            <div className="flex gap-3">
              <button onClick={() => { confirmConfig.onConfirm(); setConfirmConfig(null); }} className="flex-1 bg-red-600 hover:bg-red-500 text-white font-bold py-3 rounded-xl transition-colors shadow-lg shadow-red-600/20">{t("common.confirm") || "Confirm"}</button>
              <button onClick={() => setConfirmConfig(null)} className="flex-1 bg-white/10 hover:bg-white/20 text-white font-bold py-3 rounded-xl transition-colors">{t("common.cancel")}</button>
            </div>
          </div>
        </div>
      )}

      {/* Prompt Modal */}
      {promptConfig && (
        <div className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-6 animate-in zoom-in">
          <div className="bg-slate-900 border border-white/10 p-6 rounded-2xl w-full max-w-sm text-right shadow-2xl">
            <p className="text-sm font-bold text-white mb-4">
              {promptConfig.message}
            </p>
            <input 
               type="text"
               value={promptValue}
               onChange={(e) => setPromptValue(e.target.value)}
               className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white text-xs outline-none focus:border-blue-500 mb-6"
               placeholder={t("admin.unbanPromptPlaceholder")}
               autoFocus
            />
            <div className="flex gap-3">
              <button onClick={() => { promptConfig.onConfirm(promptValue); setPromptConfig(null); setPromptValue(""); }} className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition-colors shadow-lg shadow-blue-600/20">{t("admin.confirmUnbanBtn")}</button>
              <button onClick={() => { setPromptConfig(null); setPromptValue(""); }} className="flex-1 bg-white/10 hover:bg-white/20 text-white font-bold py-3 rounded-xl transition-colors">{t("common.cancel")}</button>
            </div>
          </div>
        </div>
      )}

      {/* Penalty Modal */}
      {penaltyModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-6 animate-in zoom-in">
          <div className="bg-slate-900 border border-white/10 p-6 rounded-[2rem] w-full max-w-md text-right shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">{t("admin.penaltyTitle")}</h3>
            <p className="text-[10px] text-slate-400 font-bold mb-4">{t("admin.offenderId")} {penaltyModal.userId}</p>
            
            {/* Penalty Type Tabs */}
            <p className="text-xs text-slate-300 font-bold mb-2">{t("admin.penaltyRequired")}</p>
            <div className="grid grid-cols-3 gap-2 mb-4">
               <button 
                 onClick={() => setPenaltyType('mute')} 
                 className={`p-2.5 rounded-xl font-black text-[11px] transition-colors border ${penaltyType === 'mute' ? 'bg-orange-600 border-orange-500 text-white shadow-lg shadow-orange-600/30' : 'bg-black/40 border-white/10 text-slate-400'}`}
               >
                 {t('admin.restrictMessaging')}
               </button>
               <button 
                 onClick={() => setPenaltyType('publishing')} 
                 className={`p-2.5 rounded-xl font-black text-[11px] transition-colors border ${penaltyType === 'publishing' ? 'bg-purple-600 border-purple-500 text-white shadow-lg shadow-purple-600/30' : 'bg-black/40 border-white/10 text-slate-400'}`}
               >
                 {t('admin.restrictPublishing')}
               </button>
               <button 
                 onClick={() => setPenaltyType('ban')} 
                 className={`p-2.5 rounded-xl font-black text-[11px] transition-colors border ${penaltyType === 'ban' ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-600/30' : 'bg-black/40 border-white/10 text-slate-400'}`}
               >
                 {t('admin.banAccount')}
               </button>
            </div>

            {/* Duration */}
            <div className="space-y-2 mb-4">
               <p className="text-xs text-slate-300 font-bold">{t("admin.penaltyDuration")}</p>
               <div className="grid grid-cols-4 gap-2">
                  {[1, 72, 168, 'forever'].map(val => (
                    <button 
                      key={val} 
                      onClick={() => setPenaltyDuration(val as any)}
                      className={`p-2.5 rounded-xl border text-[10px] font-black transition-colors ${penaltyDuration === val ? 'bg-blue-600 border-blue-500 text-white shadow-md' : 'bg-black/20 border-white/10 text-slate-400'}`}
                    >
                      {val === 1 ? t('admin.hour1') : val === 72 ? t('admin.days3') : val === 168 ? t('admin.week1') : t('admin.forever')}
                    </button>
                  ))}
               </div>
            </div>

            {/* Reason */}
            <div className="mb-6">
               <p className="text-xs text-slate-300 font-bold mb-2">{t("admin.penaltyReasonSelect")}</p>
               <select 
                  value={penaltyReason} 
                  onChange={e => setPenaltyReason(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white text-xs font-bold outline-none mb-2 focus:border-red-500"
               >
                  <option value="">{t("admin.selectReasonPlaceholder")}</option>
                  <option value="posts">{t("admin.reasonPosts")}</option>
                  <option value="spam">{t("admin.reasonSpam")}</option>
                  <option value="impersonation">{t("admin.reasonImpersonation")}</option>
                  <option value="guidelines">{t("admin.reasonGuidelines")}</option>
               </select>
               <input 
                  type="text"
                  value={penaltyReason}
                  onChange={e => setPenaltyReason(e.target.value)}
                  placeholder={t("admin.customReason")}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white text-xs outline-none focus:border-blue-500"
               />
            </div>

            <div className="flex gap-3 pt-4 border-t border-white/5">
              <button 
                onClick={handleApplyPenalty}
                className="flex-1 bg-red-600 hover:bg-red-500 text-white font-black py-3 rounded-xl transition-colors shadow-lg shadow-red-600/30 text-xs"
              >{t("admin.applyPenaltyBtn")}</button>
              <button 
                onClick={() => setPenaltyModal(null)}
                className="px-6 py-3 bg-white/5 border border-white/10 text-white font-bold rounded-xl text-xs hover:bg-white/10"
              >{t("common.cancel")}</button>
            </div>
          </div>
        </div>
      )}

      {/* Chat Context Modal */}
      {chatContextModal && (
        <div className="fixed inset-0 z-[60] bg-[#0a0a0a] flex flex-col animate-in slide-in-from-bottom">
           <header className="h-14 flex items-center justify-between px-4 border-b border-white/10 glass shrink-0">
             <h3 className="text-sm font-black text-white">{t("admin.fullChatReview")}</h3>
             <button onClick={() => setChatContextModal(null)} className="p-2 bg-white/10 rounded-full text-white"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={3}/></svg></button>
           </header>
           <div className="flex-1 overflow-y-auto p-4 flex flex-col space-y-3 bg-black/50">
             {loadingChat ? (
                <div className="flex justify-center mt-10"><div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin"></div></div>
             ) : chatMessages.length === 0 ? (
                <p className="text-center text-slate-500 font-bold text-xs mt-10">{t("admin.chatEmptyOrDeleted")}</p>
             ) : (
                chatMessages.map(msg => (
                  <div key={msg.id} className="bg-white/5 p-3 rounded-2xl max-w-[85%] self-end">
                     <p className="text-[9px] font-black text-orange-400 mb-1">{msg.senderName || msg.senderId} (@{msg.senderId})</p>
                     <p className="text-xs text-white break-words">{msg.text}</p>
                     <div className="flex justify-end mt-2 pt-2 border-t border-white/5">
                        <button onClick={() => setPenaltyModal({ userId: msg.senderId, reportId: chatContextModal.reportId })} className="text-[10px] text-red-400 font-black px-2 py-1 bg-red-500/10 rounded-lg hover:bg-red-500/20">{t("admin.penalizeSender")}</button>
                     </div>
                  </div>
                ))
             )}
           </div>
        </div>
      )}
    </div>
  );
};
