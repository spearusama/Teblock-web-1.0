import React from 'react';
import { EMOJI_STYLES, useEmojiStyle, setStoredEmojiStyle, EmojiImg, EmojiStyle } from '../utils/emoji';
import { useLanguage } from '../utils/i18n';

interface EmojiStyleModalProps {
  onClose: () => void;
}

const PREVIEW_EMOJIS = ['😍', '🔥', '😂', '❤️', '👍', '🎉', '🥺', '😎'];

export const EmojiStyleModal: React.FC<EmojiStyleModalProps> = ({ onClose }) => {
  const currentStyle = useEmojiStyle();
  const { t, dir } = useLanguage();

  return (
    <div className="fixed inset-0 z-[650] flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        dir={dir}
        className="w-full max-w-md bg-slate-900 border border-white/10 rounded-[2.5rem] p-6 shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col space-y-6"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <button 
            onClick={onClose}
            className="w-10 h-10 rounded-2xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <div className="rtl:text-right ltr:text-left">
            <h3 className="text-base font-black text-white">{t('emoji.modalTitle')}</h3>
            <p className="text-[10px] text-slate-400 font-bold">{t('emoji.modalDesc')}</p>
          </div>
        </div>

        {/* Style Options */}
        <div className="space-y-3 max-h-[60vh] overflow-y-auto custom-scrollbar p-1">
          {EMOJI_STYLES.map((st) => {
            const isSelected = currentStyle === st.id;
            return (
              <div 
                key={st.id}
                onClick={() => {
                  setStoredEmojiStyle(st.id);
                }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col space-y-3 ${
                  isSelected 
                    ? 'bg-blue-600/15 border-blue-500 shadow-lg shadow-blue-500/10' 
                    : 'bg-white/[0.03] border-white/5 hover:bg-white/[0.07] hover:border-white/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <span className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                      isSelected ? 'border-blue-500 bg-blue-500' : 'border-slate-500'
                    }`}>
                      {isSelected && <span className="w-1.5 h-1.5 bg-white rounded-full"></span>}
                    </span>
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      isSelected ? 'bg-blue-500/20 text-blue-400' : 'bg-white/5 text-slate-400'
                    }`}>
                      {st.nameEn}
                    </span>
                    {st.license && (
                      <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-bold">
                        ✓ {st.license}
                      </span>
                    )}
                  </div>

                  <div className="rtl:text-right ltr:text-left">
                    <h4 className="text-xs font-black text-white">{st.name}</h4>
                  </div>
                </div>

                <p className="text-[10px] text-slate-400 font-bold rtl:text-right ltr:text-left">{st.description}</p>

                {/* Live Emoji Preview Grid for this style */}
                <div className="flex items-center justify-end space-x-2 space-x-reverse bg-black/40 p-2.5 rounded-xl border border-white/5">
                  {PREVIEW_EMOJIS.map((e) => (
                    <EmojiImg 
                      key={e} 
                      emoji={e} 
                      size={24} 
                      styleOverride={st.id as EmojiStyle} 
                      className="transition-transform hover:scale-125"
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="border-t border-white/10 pt-4 flex items-center justify-between">
          <button
            onClick={onClose}
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-black text-xs rounded-xl shadow-lg shadow-blue-600/30 transition-all active:scale-95"
          >
            {t('emoji.applyAndSave')}
          </button>
        </div>
      </div>
    </div>
  );
};
