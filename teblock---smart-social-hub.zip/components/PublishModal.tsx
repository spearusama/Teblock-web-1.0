import React, { useState, useRef, useEffect } from 'react';
import { User } from '../types';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { checkAccess } from '../App';
import { encryptText } from "../utils/crypto";
import { collection, addDoc, serverTimestamp, updateDoc, doc } from 'firebase/firestore';
import { useLanguage } from '../utils/i18n';
import { compressVideoFile, compressImageFile, optimizeMediaUrl, formatBytes } from '../utils/mediaOptimizer';
import { extractHashtags } from '../utils/hashtagUtils';

interface PublishModalProps {
  user: User;
  onClose: () => void;
}

const CLOUD_NAME = "dei75gqcl";
const UPLOAD_PRESET = "TEBLOCK";
const POPULAR_HASHTAGS = ['#fortnite', '#العاب', '#ترند', '#ضحك', '#تحديات', '#gaming', '#فلوق', '#تيك_توك'];

export const PublishModal: React.FC<PublishModalProps> = ({ user, onClose }) => {
  const { t, dir } = useLanguage();
  const [files, setFiles] = useState<{ file: File; type: 'video' | 'image'; previewUrl: string; duration?: number }[]>([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [compressing, setCompressing] = useState(false);
  const [compressionProgress, setCompressionProgress] = useState(0);
  const [compressionStatus, setCompressionStatus] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  
  const [view, setView] = useState<'main' | 'appeal'>('main');
  const [captionText, setCaptionText] = useState("");

  // Appeal state
  const [appealReason, setAppealReason] = useState<'innocent' | 'apology'>('innocent');
  const [appealExplanation, setAppealExplanation] = useState("");
  const [isSubmittingAppeal, setIsSubmittingAppeal] = useState(false);
  const [appealSent, setAppealSent] = useState(false);

  const publishAccess = checkAccess(user.Freepublishing, user.Freepublishing_unlock);

  const isPublishingRestricted = Boolean(
    user.publishingRestrictedForever === true ||
    (user.publishingRestrictionUntil && user.publishingRestrictionUntil > Date.now()) ||
    user.Freepublishing === '0' ||
    user.Freepublishing === 'مقفل' ||
    user.Freepublishing === 'مقفول' ||
    !publishAccess.allowed
  );

  const getRestrictionDetail = () => {
    if (user.publishingRestrictedForever) {
      return t('publish.restrictedTitle');
    }
    if (user.publishingRestrictionUntil && user.publishingRestrictionUntil > Date.now()) {
      return `${t('publish.restrictedTitle')}: ${new Date(user.publishingRestrictionUntil).toLocaleString()}`;
    }
    if (user.publishingRestrictionReason) {
      return user.publishingRestrictionReason;
    }
    if (publishAccess && !publishAccess.allowed) {
      return publishAccess.message;
    }
    return t('notes.restrictedNotice');
  };

  const handleSendAppeal = async () => {
    if (isSubmittingAppeal) return;
    setIsSubmittingAppeal(true);
    try {
      await addDoc(collection(db, 'appeals'), {
        userId: user.Id_user,
        userName: user.UserData,
        userPhoto: user.photoURL || "",
        restrictionType: 'publishing',
        reason: appealReason,
        userExplanation: appealExplanation.trim(),
        timestamp: serverTimestamp(),
        status: 'pending'
      });

      await updateDoc(doc(db, 'users', user.Id_user), {
        hasAppealed: true
      });

      setAppealSent(true);
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (e) {
      console.error(e);
      alert(t('publish.appealReceivedDesc'));
    } finally {
      setIsSubmittingAppeal(false);
    }
  };


  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isPublishingRestricted) return;
    const selectedFiles: File[] = e.target.files ? Array.from(e.target.files) : [];
    if (!selectedFiles.length) return;

    const newFiles = [...files];
    let videosCount = newFiles.filter(f => f.type === 'video').length;

    for (const file of selectedFiles) {
      if (newFiles.length >= 8) {
        alert(t('publish.maxFilesLimit'));
        break;
      }
      
      const type = file.type.startsWith('video/') ? 'video' : 'image';
      
      if (type === 'video') {
        if (videosCount >= 1) {
          alert(t('publish.maxVideoLimit'));
          continue;
        }
        const video = document.createElement('video');
        video.preload = 'metadata';
        video.onloadedmetadata = function() {
          window.URL.revokeObjectURL(video.src);
          if (video.duration > 60) {
            alert(t('publish.videoDurationLimit'));
          } else {
            setFiles(prev => [...prev, { file, type, previewUrl: URL.createObjectURL(file), duration: video.duration }]);
          }
        }
        video.src = URL.createObjectURL(file);
        videosCount++;
      } else {
        newFiles.push({ file, type, previewUrl: URL.createObjectURL(file) });
      }
    }
    
    if (newFiles.length > files.length) {
      setFiles(newFiles);
    }
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleUpload = async (caption: string) => {
    if (isPublishingRestricted) {
      alert(t('notes.restrictedNotice'));
      return;
    }
    if (files.length === 0 || uploading || compressing) return;
    setUploading(true);
    setProgress(5);
    setCompressionStatus("");

    try {
      const mediaUrls: { url: string; type: 'video' | 'image' }[] = [];
      let primaryVideoUrl = "";
      
      let i = 0;
      for (const f of files) {
        let fileToUpload = f.file;

        // Smart client-side video compression
        if (f.type === 'video') {
          if (f.file.size > 3.5 * 1024 * 1024) {
            setCompressing(true);
            setCompressionProgress(0);
            setCompressionStatus(t('publish.compressingVideo') || 'جاري ضغط الفيديو لتوفير المساحة وباقة الإنترنت...');
            try {
              const compResult = await compressVideoFile(f.file, {
                maxWidth: 720,
                maxHeight: 1280,
                targetBitrate: 1_250_000,
                onProgress: (p) => setCompressionProgress(p)
              });
              if (compResult.wasCompressed) {
                fileToUpload = compResult.file;
                setCompressionStatus(
                  `تم ضغط الفيديو بنجاح: تم توفير ${compResult.savedPercent}% من الحجم (${formatBytes(compResult.originalSize)} ➔ ${formatBytes(compResult.compressedSize)})`
                );
              }
            } catch (err) {
              console.warn("Client video compression skipped:", err);
            } finally {
              setCompressing(false);
            }
          }
        } else if (f.type === 'image') {
          // Client-side image compression
          if (f.file.size > 400 * 1024) {
            try {
              fileToUpload = await compressImageFile(f.file, 1080, 0.85);
            } catch (err) {
              console.warn("Image compression error:", err);
            }
          }
        }

        const formData = new FormData();
        formData.append('file', fileToUpload);
        formData.append('upload_preset', UPLOAD_PRESET);
        
        const endpoint = f.type === 'video' ? 'video/upload' : 'image/upload';
        const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/${endpoint}`, {
          method: 'POST',
          body: formData
        });
        const data = await res.json();
        
        // Optimize the uploaded URL with Cloudinary adaptive CDN parameters
        const optimizedMediaUrl = optimizeMediaUrl(data.secure_url, f.type);
        mediaUrls.push({ url: optimizedMediaUrl, type: f.type });
        if (f.type === 'video' && !primaryVideoUrl) primaryVideoUrl = optimizedMediaUrl;
        
        i++;
        setProgress(5 + Math.floor((i / files.length) * 80));
      }

      // Extract clean hashtags (e.g. #fortnite, #العاب) instead of splitting random conversational words
      const hashtags = extractHashtags(caption || "");

      await addDoc(collection(db, 'reels'), {
        userId: user.Id_user,
        userName: user.UserData,
        userPhoto: user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.Id_user}`,
        accountType: user.accountType || 'user',
        videoUrl: primaryVideoUrl || mediaUrls[0].url,
        mediaUrls: mediaUrls,
        musicTrack: null,
        caption: encryptText(caption || ""),
        keywords: hashtags,
        hashtags: hashtags,
        likes: [],
        commentsCount: 0,
        sharesCount: 0,
        timestamp: serverTimestamp(),
        category: 'general'
      });
      
      setProgress(100);
      onClose();
    } catch (e) {
      alert(t('publish.uploadFailed'));
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[250] flex items-center justify-center p-6 glass backdrop-blur-2xl">
      <div dir={dir} className="w-full max-w-md bg-slate-900 rounded-[3rem] p-8 border border-white/10 shadow-3xl rtl:text-right ltr:text-left relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* If publishing restricted, show restriction overlay */}
        {isPublishingRestricted && view !== 'appeal' && (
          <div className="absolute inset-0 bg-[#1a0505]/98 z-[60] flex flex-col items-center justify-center p-8 text-center animate-in fade-in">
             <div className="w-20 h-20 bg-red-600/20 rounded-3xl flex items-center justify-center text-red-500 mb-5 border border-red-500/30 shadow-xl shadow-red-900/30">
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
             </div>
             <h4 className="text-white font-black text-xl mb-2 tracking-tight">{t('publish.restrictedTitle')}</h4>
             <p className="text-red-300 text-xs font-bold leading-relaxed mb-6 bg-red-950/40 p-4 rounded-2xl border border-red-500/20">
               {getRestrictionDetail()}
             </p>
             
             <div className="w-full space-y-3">
               {!user.hasAppealed ? (
                 <button 
                   onClick={() => setView('appeal')} 
                   className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-xs transition-all shadow-lg shadow-blue-600/30"
                 >
                   {t('publish.appealBtn')}
                 </button>
               ) : (
                 <div className="w-full py-3 bg-white/5 border border-white/10 rounded-2xl text-slate-400 font-bold text-xs">
                   {t('publish.appealPending')}
                 </div>
               )}
               <button 
                 onClick={onClose} 
                 className="w-full py-3.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-slate-400 font-black text-xs transition-all"
               >
                 {t('publish.closeWindow')}
               </button>
             </div>
          </div>
        )}

        {/* Appeal View */}
        {view === 'appeal' ? (
          <div className="flex flex-col flex-1 overflow-y-auto custom-scrollbar p-2 animate-in fade-in">
            <div className="flex items-center justify-between mb-4">
              <button onClick={() => setView('main')} className="p-2 text-slate-400 hover:text-white">
                <svg className="w-5 h-5 flip-in-ltr" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7"/></svg>
              </button>
              <h3 className="text-base font-black text-white">{t('publish.appealBtn')}</h3>
              <div className="w-5"></div>
            </div>

            {appealSent ? (
              <div className="my-auto py-12 text-center">
                <div className="w-16 h-16 bg-green-500/20 text-green-400 rounded-full flex items-center justify-center mx-auto mb-4 border border-green-500/30">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>
                </div>
                <h4 className="text-white font-black text-base mb-2">{t('publish.appealReceivedTitle')}</h4>
                <p className="text-slate-400 text-xs font-bold">{t('publish.appealReceivedDesc')}</p>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-xs text-slate-400 leading-relaxed text-center">
                  {t('publish.explanationPlaceholder')}
                </p>

                <div className="space-y-2">
                  <button 
                    onClick={() => setAppealReason('innocent')}
                    className={`w-full p-3.5 rounded-2xl border text-xs font-black transition-all flex items-center justify-between ${appealReason === 'innocent' ? 'bg-blue-600 border-blue-500 text-white' : 'bg-black/30 border-white/10 text-slate-300'}`}
                  >
                    <span>{t('publish.appealReasonInnocent')}</span>
                    {appealReason === 'innocent' && <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>}
                  </button>

                  <button 
                    onClick={() => setAppealReason('apology')}
                    className={`w-full p-3.5 rounded-2xl border text-xs font-black transition-all flex items-center justify-between ${appealReason === 'apology' ? 'bg-blue-600 border-blue-500 text-white' : 'bg-black/30 border-white/10 text-slate-300'}`}
                  >
                    <span>{t('publish.appealReasonApology')}</span>
                    {appealReason === 'apology' && <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>}
                  </button>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 font-bold mb-2">{t('publish.extraExplanation')}</label>
                  <textarea 
                    value={appealExplanation}
                    onChange={e => setAppealExplanation(e.target.value)}
                    rows={3}
                    placeholder={t('publish.explanationPlaceholder')}
                    className="w-full bg-black/40 border border-white/10 rounded-2xl p-3 text-white text-xs outline-none focus:border-blue-500 resize-none"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button 
                    onClick={handleSendAppeal}
                    disabled={isSubmittingAppeal}
                    className="flex-1 py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-xs transition-all disabled:opacity-50 shadow-lg shadow-blue-600/30"
                  >
                    {isSubmittingAppeal ? '...' : t('publish.submitAppealBtn')}
                  </button>
                  <button 
                    onClick={() => setView('main')}
                    className="px-6 py-3.5 bg-white/5 border border-white/10 rounded-2xl text-slate-400 font-black text-xs hover:bg-white/10 transition-all"
                  >
                    {t('publish.back')}
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : view === 'main' ? (
          <div className="flex flex-col flex-1 overflow-y-auto custom-scrollbar">
            <h3 className="text-xl font-black mb-6 text-center text-white shrink-0">{t('publish.createNewPost')}</h3>
            
            <input type="file" accept="video/*,image/*" multiple className="hidden" ref={fileRef} onChange={handleFileChange} />
            
            <div className="flex space-x-2 space-x-reverse overflow-x-auto pb-4 mb-4 shrink-0 snap-x">
              {files.map((f, i) => (
                <div key={i} className="relative w-24 h-32 shrink-0 snap-center rounded-2xl overflow-hidden bg-black border border-white/10 group">
                  {f.type === 'video' ? (
                    <video src={f.previewUrl} className="w-full h-full object-cover" />
                  ) : (
                    <img src={f.previewUrl} className="w-full h-full object-cover" />
                  )}
                  <button onClick={() => setFiles(files.filter((_, idx) => idx !== i))} className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2}/></svg>
                  </button>
                  <div className="absolute bottom-1 left-1 right-1 flex items-center justify-between text-white text-[8px] px-1.5 py-0.5 rounded bg-black/70 font-bold backdrop-blur-sm pointer-events-none">
                    <span>{f.type === 'video' ? t('publish.video') : 'صورة'}</span>
                    <span className="text-emerald-400 font-mono">{formatBytes(f.file.size)}</span>
                  </div>
                </div>
              ))}
              {files.length < 8 && (
                <div onClick={() => fileRef.current?.click()} className="w-24 h-32 shrink-0 snap-center border-2 border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-blue-500/50 transition-colors">
                  <svg className="w-6 h-6 text-slate-500 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={2}/></svg>
                  <span className="text-[9px] text-slate-500 font-bold uppercase">{t('publish.add')}</span>
                </div>
              )}
            </div>

            {files.some(f => f.type === 'video' && f.file.size > 3.5 * 1024 * 1024) && (
              <div className="mb-3 p-2.5 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-[10px] text-blue-300 font-bold flex items-center space-x-2 space-x-reverse shrink-0">
                <span className="text-sm">⚡</span>
                <span>تقنية الضغط الذكي مفعلة: سيتم تقليص حجم الفيديو بنسبة ~85% لتسريع التحميل وحفظ مساحة التخزين.</span>
              </div>
            )}

            {(uploading || compressing) && (
              <div className="mb-4 space-y-1.5 shrink-0 bg-black/40 p-3 rounded-2xl border border-white/5">
                <div className="flex items-center justify-between text-[10px] font-black text-slate-300">
                  <span>{compressing ? `جاري ضغط الفيديو لتوفير المساحة... ${compressionProgress}%` : `جاري الرفع السحابي... ${progress}%`}</span>
                  <span className="text-blue-400 font-mono">{compressing ? `${compressionProgress}%` : `${progress}%`}</span>
                </div>
                <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-300 ${compressing ? 'bg-amber-400' : 'bg-blue-500'}`} 
                    style={{ width: `${compressing ? compressionProgress : progress}%` }}
                  />
                </div>
                {compressionStatus && (
                  <p className="text-[9px] text-emerald-400 font-bold text-center">{compressionStatus}</p>
                )}
              </div>
            )}
            
            <textarea 
              id="cap" 
              value={captionText}
              onChange={e => setCaptionText(e.target.value)}
              placeholder="اكتب وصفاً للفيديو مع هاشتاغات لتصنيف دقيق (مثال: #fortnite #العاب #ترند)..."
              className="w-full bg-black/40 rounded-2xl p-4 text-xs h-24 mb-2 outline-none resize-none text-white border border-white/5 focus:border-blue-500/50 transition-colors shrink-0" 
            />

            {/* Quick Hashtag Suggestions */}
            <div className="mb-4 shrink-0">
              <div className="flex items-center justify-between mb-1.5 px-1">
                <span className="text-[10px] text-slate-400 font-bold">هاشتاغات مقترحة لتحسين التوصيات:</span>
                <span className="text-[9px] text-blue-400 font-mono">#هاشتاغ</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {POPULAR_HASHTAGS.map(tag => {
                  const isSelected = captionText.toLowerCase().includes(tag.toLowerCase());
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => {
                        setCaptionText(prev => {
                          if (prev.toLowerCase().includes(tag.toLowerCase())) {
                            return prev;
                          }
                          return prev ? `${prev.trim()} ${tag}` : tag;
                        });
                      }}
                      className={`text-[10px] px-2.5 py-1 rounded-xl font-bold transition-all ${
                        isSelected 
                          ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30 border border-blue-400/40' 
                          : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            </div>
            
            <div className="flex gap-4 mt-auto shrink-0">
              <button disabled={uploading || files.length === 0 || isPublishingRestricted} onClick={() => handleUpload(captionText)} className="flex-1 bg-blue-600 py-4 rounded-2xl font-black text-white disabled:opacity-30 transition-all shadow-lg shadow-blue-600/20">{t('publish.publishBtn')}</button>
              <button onClick={onClose} className="px-6 py-4 glass rounded-2xl text-[10px] font-black uppercase text-slate-500 hover:text-white transition-colors">{t('publish.cancelBtn')}</button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
export default PublishModal;
