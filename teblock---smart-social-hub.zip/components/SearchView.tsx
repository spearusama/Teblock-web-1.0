
import React, { useState, useEffect } from 'react';
import { User, Reel } from '../types';
import { db } from '../firebase';
import { 
  collection, query, where, getDocs, limit, addDoc, 
  serverTimestamp, orderBy 
} from 'firebase/firestore';
import { useLanguage } from '../utils/i18n';
import { optimizeVideoUrl } from '../utils/mediaOptimizer';
import { decryptText } from '../utils/crypto';
import { getReelHashtags } from '../utils/hashtagUtils';

interface SearchViewProps {
  user: User;
  onNavigateProfile?: (userId: string) => void;
  onNavigateChat?: (chat: any) => void;
}

const SearchView: React.FC<SearchViewProps> = ({ user, onNavigateProfile }) => {
  const { t, dir } = useLanguage();
  const [searchTerm, setSearchTerm] = useState(() => {
    const path = window.location.pathname;
    if (path.startsWith('/search/')) {
      return decodeURIComponent(path.split('/')[2] || '');
    }
    return "";
  });
  
  useEffect(() => {
    const newPath = searchTerm.trim() ? `/search/${encodeURIComponent(searchTerm.trim())}` : '/search';
    if (window.location.pathname !== newPath && window.location.pathname.startsWith('/search')) {
      window.history.pushState(null, '', newPath);
    }
  }, [searchTerm]);

  const [activeTab, setActiveTab] = useState<'explore' | 'people' | 'pages' | 'reels'>('explore');
  
  const [exploreResults, setExploreResults] = useState<any[]>([]);
  const [peopleResults, setPeopleResults] = useState<User[]>([]);
  const [pagesResults, setPagesResults] = useState<User[]>([]);
  const [reelsResults, setReelsResults] = useState<Reel[]>([]);
  
  const [loading, setLoading] = useState(false);

  // Initial load for random reels if no search
  useEffect(() => {
    const fetchInitialData = async () => {
      setLoading(true);
      try {
        const rQ = query(collection(db, 'reels'), limit(10));
        const rSnap = await getDocs(rQ);
        setReelsResults(rSnap.docs.map(d => ({ id: d.id, ...d.data() } as Reel)));
        
        // For "Explore", maybe show some trending posts or random users
        const uQ = query(collection(db, 'users'), limit(10));
        const uSnap = await getDocs(uQ);
        setExploreResults(uSnap.docs.map(d => d.data() as User));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchInitialData();
  }, []);

  const handleSearch = async () => {
    if (!searchTerm.trim()) return;
    setLoading(true);
    try {
      const searchLower = searchTerm.toLowerCase();
      if (activeTab === 'explore') {
        // Search for anything interesting
        const uQ = query(collection(db, 'users'), limit(50));
        const uSnap = await getDocs(uQ);
        const results = uSnap.docs
          .map(d => d.data() as User)
          .filter(u => 
            u.UserData.toLowerCase().includes(searchLower) || 
            (u['id-2'] && u['id-2'].includes(searchLower)) ||
            u.Id_user.toLowerCase().includes(searchLower)
          );
        setExploreResults(results);
      } else if (activeTab === 'people') {
        const uQ = query(collection(db, 'users'), limit(100));
        const uSnap = await getDocs(uQ);
        const results = uSnap.docs
          .map(d => d.data() as User)
          .filter(u => 
            u.Id_user !== user.Id_user && 
            (u.accountType === 'user' || !u.accountType) &&
            (u.UserData.toLowerCase().includes(searchLower) || 
             (u['id-2'] && u['id-2'].includes(searchLower)) ||
             u.Id_user.toLowerCase().includes(searchLower))
          );
        setPeopleResults(results);
      } else if (activeTab === 'pages') {
        const uQ = query(collection(db, 'users'), where('accountType', '==', 'page'), limit(100));
        const uSnap = await getDocs(uQ);
        const results = uSnap.docs
          .map(d => d.data() as User)
          .filter(u => 
            u.UserData.toLowerCase().includes(searchLower) ||
            (u['id-2'] && u['id-2'].includes(searchLower)) ||
            u.Id_user.toLowerCase().includes(searchLower)
          );
        setPagesResults(results);
      } else if (activeTab === 'reels') {
        const rQ = query(collection(db, 'reels'), limit(50));
        const rSnap = await getDocs(rQ);
        const searchHashtag = searchLower.startsWith('#') ? searchLower : `#${searchLower}`;
        const searchClean = searchLower.replace(/^#/, '');

        const results = rSnap.docs
          .map(d => {
            const data = d.data();
            const decryptedCaption = decryptText(data.caption || "") || data.caption || "";
            return { id: d.id, ...data, caption: decryptedCaption } as Reel;
          })
          .filter(r => {
            const captionLower = (r.caption || '').toLowerCase();
            const tags = getReelHashtags(r).map(t => t.toLowerCase());
            return (
              captionLower.includes(searchLower) ||
              captionLower.includes(searchClean) ||
              tags.some(t => t.includes(searchLower) || t.includes(searchClean) || t === searchHashtag)
            );
          });
        setReelsResults(results);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchTerm) {
      handleSearch();
    }
  }, [activeTab, searchTerm]);

  return (
    <div dir={dir} className="flex-1 flex flex-col bg-black h-full overflow-hidden animate-in fade-in duration-300">
      {/* HEADER WITH TABS AT TOP */}
      <div className="glass border-b border-white/5 pt-3 sm:pt-4">
        <div className="px-4 mb-2.5">
          <div className="relative">
            <input 
              type="text" 
              placeholder={
                activeTab === 'explore' ? t('search.placeholderExplore') :
                activeTab === 'people' ? t('search.placeholderPeople') :
                activeTab === 'pages' ? t('search.placeholderPages') : t('search.placeholderReels')
              }
              value={searchTerm || ""}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl rtl:pr-10 rtl:pl-10 ltr:pl-10 ltr:pr-10 py-2.5 sm:py-3 text-xs font-bold text-white outline-none focus:ring-2 focus:ring-blue-600 transition-all rtl:text-right ltr:text-left"
            />
            <div className="absolute rtl:left-3.5 ltr:left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" strokeWidth={3}/></svg>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-around px-4 pb-1.5">
          {[
            {id: 'explore', label: t('search.tabExplore')},
            {id: 'people', label: t('search.tabPeople')},
            {id: 'pages', label: t('search.tabPages')},
            {id: 'reels', label: t('search.tabReels')}
          ].map(tab => (
            <button 
              key={tab.id} 
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-1.5 px-2 text-[10px] font-black uppercase tracking-wider transition-all relative ${activeTab === tab.id ? 'text-blue-500' : 'text-slate-500 opacity-40'}`}
            >
              {tab.label}
              {activeTab === tab.id && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500 rounded-full" />}
            </button>
          ))}
        </div>
      </div>

      {/* CONTENT */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2 custom-scrollbar pb-24">
        {loading ? (
          <div className="h-full flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            {activeTab === 'explore' && exploreResults.map(p => (
              <div key={p.Id_user} onClick={() => onNavigateProfile?.(p['id-2'] || p.Id_user)} className="flex items-center p-3 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                <img src={p.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${p.Id_user}`} className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl rtl:ml-3 ltr:mr-3 shrink-0" alt={p.UserData} />
                <div className="rtl:text-right ltr:text-left min-w-0 flex-1">
                  <h4 className="text-xs sm:text-sm font-black text-white truncate">{p.UserData}</h4>
                  <div className="flex items-center space-x-2 space-x-reverse text-[10px]">
                    <span className="text-slate-500 font-mono truncate">@{p.Id_user}</span>
                    {p['id-2'] && <span className="text-blue-400 font-mono font-bold bg-blue-500/10 px-1.5 py-0.5 rounded text-[9px]">ID-2: {p['id-2']}</span>}
                  </div>
                </div>
              </div>
            ))}

            {activeTab === 'people' && peopleResults.map(p => (
              <div key={p.Id_user} onClick={() => onNavigateProfile?.(p['id-2'] || p.Id_user)} className="flex items-center p-3 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                <img src={p.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${p.Id_user}`} className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl rtl:ml-3 ltr:mr-3 shrink-0" alt={p.UserData} />
                <div className="rtl:text-right ltr:text-left min-w-0 flex-1">
                  <h4 className="text-xs sm:text-sm font-black text-white truncate">{p.UserData}</h4>
                  <div className="flex items-center space-x-2 space-x-reverse text-[10px]">
                    <span className="text-slate-500 font-mono truncate">@{p.Id_user}</span>
                    {p['id-2'] && <span className="text-blue-400 font-mono font-bold bg-blue-500/10 px-1.5 py-0.5 rounded text-[9px]">ID-2: {p['id-2']}</span>}
                  </div>
                </div>
              </div>
            ))}

            {activeTab === 'pages' && pagesResults.map(p => (
              <div key={p.Id_user} onClick={() => onNavigateProfile?.(p['id-2'] || p.Id_user)} className="flex items-center p-3 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                <img src={p.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${p.Id_user}`} className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl rtl:ml-3 ltr:mr-3 shrink-0" alt={p.UserData} />
                <div className="rtl:text-right ltr:text-left min-w-0">
                  <h4 className="text-xs sm:text-sm font-black text-white truncate">{p.UserData}</h4>
                  <div className="flex items-center space-x-1 space-x-reverse">
                    <span className="text-[8px] text-blue-500 font-bold uppercase tracking-widest">{t('search.officialPage')}</span>
                    <svg className="w-3 h-3 text-blue-500" fill="currentColor" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                  </div>
                </div>
              </div>
            ))}

            {activeTab === 'reels' && reelsResults.map(reel => (
              <div key={reel.id} onClick={() => (window as any).navigateToReel?.(reel.id)} className="flex items-center p-3 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl rtl:ml-3 ltr:mr-3 bg-slate-800 flex items-center justify-center overflow-hidden relative shrink-0">
                   <video src={optimizeVideoUrl(reel.videoUrl || "", "saver") || undefined} className="w-full h-full object-cover opacity-50" muted preload="metadata" />
                   <svg className="w-5 h-5 text-white absolute" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                </div>
                <div className="rtl:text-right ltr:text-left flex-1 min-w-0">
                  <h4 className="text-xs sm:text-sm font-black text-white truncate max-w-[200px]">{reel.caption || t('search.noCaption')}</h4>
                  <p className="text-[10px] text-slate-500 truncate">{t('search.by')} {reel.userName}</p>
                </div>
              </div>
            ))}

            {searchTerm && !loading && exploreResults.length === 0 && peopleResults.length === 0 && pagesResults.length === 0 && reelsResults.length === 0 && (
              <div className="text-center py-20 opacity-20">
                <p className="text-xs font-black uppercase tracking-widest">{t('search.noResults')}</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default SearchView;
