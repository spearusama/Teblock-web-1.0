
import React, { useState } from 'react';
import { User } from '../types';
import { useLanguage } from '../utils/i18n';
import LanguageModal from './LanguageModal';

interface AccountPickerProps {
  accounts: User[];
  onSelect: (user: User) => void;
  onRemove: (userId: string) => void;
  onAddNew: () => void;
}

const AccountPicker: React.FC<AccountPickerProps> = ({ accounts, onSelect, onRemove, onAddNew }) => {
  const { t, langInfo, dir } = useLanguage();
  const [showLanguageModal, setShowLanguageModal] = useState(false);

  return (
    <div dir={dir} className="w-full max-w-md glass rounded-[3rem] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-500 relative">
      <div className="bg-gradient-to-br from-blue-600/30 to-transparent p-10 text-center relative">
        {/* Language button in AccountPicker */}
        <button 
          type="button" 
          onClick={() => setShowLanguageModal(true)} 
          className="absolute top-4 rtl:left-4 ltr:right-4 p-2 bg-white/5 hover:bg-white/10 rounded-xl text-slate-300 flex items-center space-x-1.5 space-x-reverse font-bold text-xs border border-white/5 transition-all shadow-md active:scale-95"
          title={t('lang.title')}
        >
          <span>{langInfo.flag}</span>
          <span className="text-[10px] font-black">{langInfo.nativeName}</span>
        </button>

        <h2 className="text-2xl sm:text-3xl font-black text-white mb-2 tracking-tighter uppercase">
          {t('auth.login')}
        </h2>
        <p className="text-blue-400/70 text-[10px] font-bold uppercase tracking-[0.3em]">
          {t('auth.userId')}
        </p>
      </div>
      
      <div className="p-6 sm:p-8 pt-0 space-y-3 max-h-[400px] overflow-y-auto custom-scrollbar">
        {accounts.map(user => (
          <div 
            key={user.Id_user}
            className="group flex items-center p-4 bg-black/40 rounded-[1.5rem] border border-white/5 hover:border-blue-500/50 transition-all cursor-pointer active:scale-95 relative"
          >
            <div onClick={() => onSelect(user)} className="flex items-center flex-1 overflow-hidden">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border border-white/10 overflow-hidden flex-shrink-0 bg-slate-800">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.UserData} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center font-black text-blue-500">{user.UserData.charAt(0)}</div>
                )}
              </div>
              <div className="rtl:mr-4 ltr:ml-4 flex-1 overflow-hidden rtl:text-right ltr:text-left">
                <h3 className="font-black text-white text-base truncate">{user.UserData}</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{user.Id_user}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 space-x-reverse">
              <button 
                onClick={(e) => { e.stopPropagation(); onRemove(user.Id_user); }}
                className="p-2 text-slate-600 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                title={t('auth.removeAccount')}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth={2}/></svg>
              </button>
              <div onClick={() => onSelect(user)} className="opacity-0 group-hover:opacity-100 transition-opacity">
                 <svg className="w-5 h-5 text-blue-500 flip-in-ltr" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7"/></svg>
              </div>
            </div>
          </div>
        ))}
        
        <button 
          onClick={onAddNew}
          className="w-full flex items-center justify-center p-5 bg-blue-600/5 border-2 border-dashed border-blue-500/20 rounded-[1.5rem] hover:bg-blue-600/10 hover:border-blue-500/50 transition-all group mt-4"
        >
          <div className="w-8 h-8 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-500 group-hover:bg-blue-600 group-hover:text-white transition-all rtl:ml-3 ltr:mr-3">
             <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4"/></svg>
          </div>
          <span className="font-black text-blue-400 text-[11px] uppercase tracking-widest">{t('auth.signup')}</span>
        </button>
      </div>
      
      <div className="p-5 bg-black/20 text-center">
         <p className="text-[9px] text-slate-600 font-black uppercase tracking-[0.2em]">P2P & Encrypted Active</p>
      </div>

      {showLanguageModal && <LanguageModal onClose={() => setShowLanguageModal(false)} />}
    </div>
  );
};

export default AccountPicker;
