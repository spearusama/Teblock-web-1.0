import React, { useState, useEffect } from 'react';
import { User, UserNote } from '../types';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { encryptText, decryptText } from "../utils/crypto";
import { EmojiImg } from "../utils/emoji";
import { collection, addDoc, query, onSnapshot, serverTimestamp, where, doc, deleteDoc, Timestamp, updateDoc, arrayUnion } from 'firebase/firestore';
import { useLanguage } from '../utils/i18n';

interface NotesSystemProps {
  user: User;
  friends?: User[];
  onlineUsers?: Record<string, any>;
  onNavigateChat?: (userId: string, userName: string, userPhoto: string) => void;
}

const NotesSystem: React.FC<NotesSystemProps> = ({ user, friends = [], onlineUsers = {}, onNavigateChat }) => {
  const { t } = useLanguage();

  const [notes, setNotes] = useState<UserNote[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [view, setView] = useState<'main' | 'player' | 'gif'>('main');
  const [noteInput, setNoteInput] = useState("");
  const [replyInput, setReplyInput] = useState("");
  const [selectedGif, setSelectedGif] = useState<string | null>(null);
  const [activeNotePlayer, setActiveNotePlayer] = useState<UserNote | null>(null);
  
  const [gifSearch, setGifSearch] = useState("");
  const [gifResults, setGifResults] = useState<any[]>([]);
  const [searchingGif, setSearchingGif] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  useEffect(() => {
    if (view === 'gif') {
      const tid = setTimeout(() => searchGifs(gifSearch), 600);
      return () => clearTimeout(tid);
    }
  }, [gifSearch, view]);

  useEffect(() => {
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const q = query(collection(db, 'notes'), where('timestamp', '>', Timestamp.fromDate(twentyFourHoursAgo)));
    const unsubscribe = onSnapshot(q, (snap) => {
      setNotes(snap.docs.map(d => {
        const data = d.data();
        let uName = data.userName;
        let uPhoto = data.userPhoto;
        if (data.userId === user.Id_user) {
          uName = user.UserData;
          uPhoto = user.photoURL || "";
        } else {
          const f = friends.find(f => f.Id_user === data.userId);
          if (f) {
            uName = f.UserData;
            uPhoto = f.photoURL || "";
          }
        }
        return { id: d.id, ...data, userName: uName, userPhoto: uPhoto, text: decryptText(data.text || "") } as UserNote;
      }));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'notes');
    });
    return unsubscribe;
  }, [user.Id_user, friends, user.photoURL, user.UserData]);

  const searchGifs = async (q: string = "") => {
    setSearchingGif(true);
    try {
      const apiKey = "LIVDSRZULELA"; // Public Tenor API Key
      const limit = 20;
      const url = q.trim() 
        ? `https://g.tenor.com/v1/search?q=${encodeURIComponent(q)}&key=${apiKey}&limit=${limit}`
        : `https://g.tenor.com/v1/trending?key=${apiKey}&limit=${limit}`;
        
      const response = await fetch(url);
      const data = await response.json();
      setGifResults(data.results ? data.results.map((item: any) => item.media[0].gif.url) : []);
    } catch (error) { 
      console.error(error); 
    } finally { 
      setSearchingGif(false); 
    }
  };

  const handleSendReply = async () => {
    if (!replyInput.trim() || !activeNotePlayer) return;
    try {
      const messageText = `Re: "${activeNotePlayer.text || t('notes.noteTitle')}":\n${replyInput}`;
      await addDoc(collection(db, 'messages'), {
        senderId: user.Id_user,
        receiverId: activeNotePlayer.userId,
        text: messageText,
        timestamp: serverTimestamp(),
        read: false
      });
      setReplyInput("");
      setShowModal(false);
      if (onNavigateChat) {
         onNavigateChat(activeNotePlayer.userId, activeNotePlayer.userName, activeNotePlayer.userPhoto || "");
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSendReaction = async (emoji: string) => {
     if (!activeNotePlayer) return;
     try {
       await updateDoc(doc(db, 'notes', activeNotePlayer.id), {
         reactions: arrayUnion({
           userId: user.Id_user,
           emoji: emoji,
           userName: user.UserData,
           userPhoto: user.photoURL || ""
         })
       });
       setShowModal(false);
     } catch (e) {
       console.error(e);
     }
  };

  const myNote = notes.find(n => n.userId === user?.Id_user);

  // Combine friends and notes, limit to 20
  const combinedUsers = [...friends];
  
  // Sort: Online first, then has note, then others
  combinedUsers.sort((a, b) => {
    const aOnline = onlineUsers[a.Id_user]?.status === 'online';
    const bOnline = onlineUsers[b.Id_user]?.status === 'online';
    const aHasNote = notes.some(n => n.userId === a.Id_user);
    const bHasNote = notes.some(n => n.userId === b.Id_user);
    
    if (aOnline && !bOnline) return -1;
    if (!aOnline && bOnline) return 1;
    if (aHasNote && !bHasNote) return -1;
    if (!aHasNote && bHasNote) return 1;
    return 0;
  });

  const displayUsers = combinedUsers.slice(0, 20);

  const openMyNote = () => {
    if (myNote) { 
      setActiveNotePlayer(myNote); 
      setShowModal(true); 
      setView('player'); 
    } else { 
      setShowModal(true); 
      setView('main'); 
      setNoteInput(""); 
      setSelectedGif(null); 
    }
  };

  return (
    <div className="flex space-x-2.5 sm:space-x-3 space-x-reverse overflow-x-auto py-2 px-3 border-b border-white/5 bg-white/[0.01] custom-scrollbar h-28 sm:h-29 flex-shrink-0 relative z-40 items-center">
      {/* My Note Entry */}
      <div className="flex flex-col items-center flex-shrink-0 relative min-w-[68px] sm:min-w-[74px] pt-7">
        <div 
          onClick={openMyNote}
          className="absolute top-0 bg-blue-600/20 backdrop-blur-xl px-2 py-1 rounded-2xl text-[8px] font-black text-white border border-blue-500/30 shadow-md cursor-pointer hover:scale-105 transition-all max-w-[74px] min-h-[30px] flex items-center justify-center text-center z-10 overflow-hidden"
        >
          {myNote ? (
            myNote.gifUrl ? <img src={myNote.gifUrl} className="w-7 h-7 object-cover rounded-md" /> :
            <span className="block truncate max-w-[66px]">{myNote.text}</span>
          ) : <svg className="w-3.5 h-3.5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={3.5}/></svg>}
        </div>
        <div 
          onClick={openMyNote}
          className="w-10 h-10 sm:w-11 sm:h-11 rounded-full border-2 border-blue-600 p-0.5 mt-1 overflow-hidden cursor-pointer hover:scale-105 transition-all shadow-md"
        >
          <img src={user.photoURL || undefined} className="w-full h-full rounded-full object-cover" />
        </div>
        <span 
          onClick={openMyNote}
          className="text-[7.5px] font-black text-slate-500 mt-1 uppercase cursor-pointer hover:text-blue-500 transition-colors"
        >
          {t('notes.you')}
        </span>
      </div>

      {/* Others Notes & Friends */}
      {displayUsers.map(friend => {
        const note = notes.find(n => n.userId === friend.Id_user);
        const isOnline = onlineUsers[friend.Id_user]?.status === 'online';
        
        const handleFriendClick = () => {
          if (note) {
            setActiveNotePlayer(note);
            setShowModal(true);
            setView('player');
          } else {
            onNavigateChat?.(friend.Id_user, friend.UserData, friend.photoURL || "");
          }
        };

        return (
          <div key={friend.Id_user} className="flex flex-col items-center flex-shrink-0 relative min-w-[68px] sm:min-w-[74px] pt-7 group">
            {note && (
              <div 
                onClick={handleFriendClick} 
                className="absolute top-0 bg-white text-slate-900 px-2 py-1 rounded-2xl text-[8px] font-black shadow-lg min-w-[56px] max-w-[78px] min-h-[30px] flex items-center justify-center text-center animate-in zoom-in cursor-pointer hover:scale-105 transition-all z-10 border border-white/20 whitespace-normal break-words overflow-hidden"
              >
                {note.gifUrl ? (
                  <img src={note.gifUrl} className="w-7 h-7 object-cover rounded-md" />
                ) : (
                  <span className="block w-full line-clamp-2 text-[7.5px] leading-tight">{note.text}</span>
                )}
              </div>
            )}
            <div className="relative">
              <div 
                className={`w-10 h-10 sm:w-11 sm:h-11 rounded-full border-2 p-0.5 mt-1 transition-all overflow-hidden cursor-pointer ${isOnline ? 'border-green-500' : 'border-slate-800 group-hover:border-blue-500'}`} 
                onClick={handleFriendClick}
              >
                <img src={friend.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${friend.Id_user}`} className="w-full h-full rounded-full object-cover" />
              </div>
              {isOnline && <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-black rounded-full"></div>}
            </div>
            <span 
              onClick={handleFriendClick}
              className="text-[7.5px] font-black text-slate-300 mt-1 truncate max-w-[60px] cursor-pointer hover:text-white transition-colors"
            >
              {friend.UserData}
            </span>
          </div>
        );
      })}

      {/* Modal System */}
      {showModal && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4 bg-black/90 backdrop-blur-3xl animate-in fade-in">
           <div className="w-full max-w-sm bg-slate-950 rounded-[3.5rem] border border-white/10 shadow-3xl overflow-hidden relative flex flex-col min-h-[460px] max-h-[85vh]">
              
              {/* Note Detail / Reply View */}
              {view === 'player' && activeNotePlayer && (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center animate-in slide-in-from-bottom">
                   <button onClick={() => setShowModal(false)} className="absolute top-8 left-8 text-slate-500 hover:text-white"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={3}/></svg></button>
                   <div className="relative mb-6">
                      <div className="w-24 h-24 rounded-full border-4 border-blue-600 p-1 bg-slate-900 shadow-2xl overflow-hidden">
                        <img src={activeNotePlayer.userPhoto || undefined} className="w-full h-full rounded-full object-cover" />
                      </div>
                   </div>
                   {activeNotePlayer.text && (
                     <div className="bg-white/5 border border-white/10 rounded-[2.5rem] p-6 mb-6 w-full">
                        <p className="text-lg font-black text-white leading-relaxed">"{activeNotePlayer.text}"</p>
                        <p className="text-[10px] text-blue-500 font-black uppercase mt-3 tracking-widest">{activeNotePlayer.userName}</p>
                     </div>
                   )}
                   {activeNotePlayer.gifUrl && (
                     <div className="w-full mb-6 rounded-3xl overflow-hidden shadow-2xl">
                       <img src={activeNotePlayer.gifUrl || undefined} className="w-full h-40 object-cover" />
                     </div>
                   )}

                   {activeNotePlayer.userId === user.Id_user ? (
                     <div className="w-full mt-4 space-y-4">
                       <button onClick={async () => {
                          try {
                            await deleteDoc(doc(db, 'notes', activeNotePlayer.id));
                            setShowModal(false);
                          } catch (e) {
                            handleFirestoreError(e, OperationType.DELETE, `notes/${activeNotePlayer.id}`);
                          }
                       }} className="w-full py-4 bg-red-600/10 border border-red-500/20 rounded-2xl text-red-500 font-black text-[10px] uppercase tracking-widest transition-all hover:bg-red-600/20">{t('notes.deleteNote')}</button>
                       {activeNotePlayer.reactions && activeNotePlayer.reactions.length > 0 && (
                         <div className="flex flex-wrap justify-center gap-2 mt-4">
                           {activeNotePlayer.reactions.map((reaction, idx) => (
                             <div key={idx} className="flex items-center space-x-2 space-x-reverse bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
                                <EmojiImg emoji={reaction.emoji} size={18} />
                               <img src={reaction.userPhoto || undefined} className="w-5 h-5 rounded-full" />
                               <span className="text-[10px] font-bold text-white">{reaction.userName}</span>
                             </div>
                           ))}
                         </div>
                       )}
                     </div>
                   ) : (
                     <div className="w-full mt-4 flex overflow-x-auto snap-x snap-mandatory scrollbar-hide no-scrollbar flex-shrink-0" style={{ scrollBehavior: 'smooth' }}>
                        {/* Input Area */}
                        <div className="w-full flex-shrink-0 snap-center flex items-center justify-center p-2 relative group">
                           <input 
                             type="text" 
                             value={replyInput}
                             onChange={(e) => setReplyInput(e.target.value)}
                             placeholder={t('notes.replyPlaceholder')}
                             className="w-full bg-white/5 border border-white/10 rounded-full px-6 py-4 text-xs text-white outline-none focus:border-blue-500 shadow-2xl transition-all"
                           />
                           {replyInput.trim() && (
                             <button onClick={handleSendReply} className="absolute left-4 w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white shadow-xl hover:scale-110 transition-transform">
                               <svg className="w-4 h-4 -mr-1" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
                             </button>
                           )}
                           {!replyInput.trim() && (
                             <div className="absolute left-4 w-8 h-8 rounded-full flex items-center justify-center pointer-events-none opacity-50 group-hover:opacity-20 transition-opacity animate-pulse">
                               <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7"/></svg>
                             </div>
                           )}
                        </div>
                        {/* Emojis Area */}
                        <div className="w-full flex-shrink-0 snap-center flex items-center justify-center space-x-4 space-x-reverse p-2">
                           {['❤️','🔥','😂','😮','😢','🙌'].map(emoji => (
                             <button key={emoji} onClick={() => handleSendReaction(emoji)} className="p-1 hover:scale-125 transition-transform flex items-center justify-center">
                               <EmojiImg emoji={emoji} size={28} />
                             </button>
                           ))}
                        </div>
                     </div>
                   )}
                </div>
              )}

              {/* Main Note Creation View */}
              {view === 'main' && (
                <div className="flex flex-col flex-1 animate-in slide-in-from-top">
                   <div className="p-7 flex items-center justify-between border-b border-white/5">
                      <button onClick={() => setShowModal(false)} className="text-slate-500 font-black text-[10px] uppercase hover:text-white transition-colors">{t('notes.cancel')}</button>
                      <h3 className="text-[11px] font-black text-white uppercase tracking-[0.3em]">{t('notes.noteTitle')}</h3>
                      <button 
                        onClick={async () => {
                           const isPublishRestricted = Boolean(
                             user.publishingRestrictedForever ||
                             (user.publishingRestrictionUntil && user.publishingRestrictionUntil > Date.now()) ||
                             user.Freepublishing === '0' ||
                             user.Freepublishing === 'مقفل' ||
                             user.Freepublishing === 'مقفول'
                           );
                           if (isPublishRestricted) {
                             alert(t('notes.restrictedNotice'));
                             return;
                           }
                           if ((!noteInput.trim() && !selectedGif) || isPublishing) return;
                           setIsPublishing(true);
                           try {
                             if (myNote) {
                               try {
                                 await deleteDoc(doc(db, 'notes', myNote.id));
                               } catch (e) {
                                 handleFirestoreError(e, OperationType.DELETE, `notes/${myNote.id}`);
                               }
                             }
                             const textToSave = selectedGif ? "" : noteInput;
                             await addDoc(collection(db, 'notes'), { 
                               userId: user.Id_user, 
                               text: encryptText(textToSave), 
                               timestamp: serverTimestamp(), 
                               userName: user.UserData, 
                               userPhoto: user.photoURL, 
                               musicTrack: null, 
                               gifUrl: selectedGif 
                             });
                             setShowModal(false);
                           } catch (e) {
                             handleFirestoreError(e, OperationType.CREATE, 'notes');
                           } finally {
                             setIsPublishing(false);
                           }
                        }}
                        disabled={(!noteInput.trim() && !selectedGif) || isPublishing}
                        className="text-blue-500 font-black text-[10px] uppercase disabled:opacity-20 flex items-center hover:text-blue-400 transition-colors"
                      >
                        {isPublishing ? <div className="w-3 h-3 border-2 border-blue-500 border-t-transparent rounded-full animate-spin ml-1"></div> : null}
                        {t('notes.publish')}
                      </button>
                   </div>
                   <div className="p-8 flex-1 flex flex-col items-center overflow-y-auto custom-scrollbar">
                      <div className="w-16 h-16 rounded-full mx-auto border-2 border-blue-500 p-0.5 mb-6 shadow-xl">
                        <img src={user.photoURL || undefined} className="w-full h-full rounded-full object-cover" />
                      </div>
                      
                      {!selectedGif && (
                        <textarea 
                          autoFocus 
                          value={noteInput || ""} 
                          onChange={(e) => setNoteInput(e.target.value.substring(0, 100))} 
                          placeholder={t('notes.whatsOnMind')} 
                          className="w-full bg-white/[0.03] border border-white/10 rounded-[2.5rem] p-6 text-sm text-white text-center outline-none resize-none h-32 shadow-2xl focus:border-blue-500 transition-all font-bold placeholder:text-slate-700" 
                        />
                      )}
                      
                      {selectedGif && (
                        <div className="w-full mt-4 relative rounded-3xl overflow-hidden group">
                          <img src={selectedGif || undefined} className="w-full h-36 object-cover" />
                          <button onClick={() => setSelectedGif(null)} className="absolute top-2 right-2 bg-black/60 text-white p-1.5 rounded-full hover:bg-black/80 transition-all">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={3}/></svg>
                          </button>
                        </div>
                      )}

                      <div className="w-full mt-6 space-y-4">
                         <div className="flex">
                           {!selectedGif && (
                             <button onClick={() => { setView('gif'); searchGifs(); }} className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center space-x-2 space-x-reverse hover:bg-white/10 transition-all shadow-xl">
                                <span className="text-sm font-black text-purple-400">GIF</span>
                                <span className="text-[10px] font-black text-white uppercase tracking-widest">{t('notes.gif')}</span>
                             </button>
                           )}
                         </div>

                         {myNote && (
                           <button onClick={async () => { 
                             try {
                               await deleteDoc(doc(db, 'notes', myNote.id)); 
                               setShowModal(false); 
                             } catch (e) {
                               handleFirestoreError(e, OperationType.DELETE, `notes/${myNote.id}`);
                             }
                           }} className="w-full py-4 bg-red-600/10 border border-red-500/20 rounded-2xl text-red-500 font-black text-[10px] uppercase tracking-widest transition-all hover:bg-red-600/20">
                             {t('notes.deleteNote')}
                           </button>
                         )}
                      </div>
                   </div>
                </div>
              )}

              {/* GIF Search View */}
              {view === 'gif' && (
                <div className="flex flex-col flex-1 animate-in slide-in-from-right duration-300 h-full overflow-hidden">
                   <div className="p-7 border-b border-white/5 flex items-center bg-black/40">
                      <button onClick={() => setView('main')} className="p-2 text-slate-500 ml-3 hover:text-white transition-colors">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7" strokeWidth={3}/></svg>
                      </button>
                      <h3 className="text-[11px] font-black text-white uppercase tracking-[0.2em]">{t('notes.searchGif')}</h3>
                   </div>
                   <div className="p-6">
                      <input 
                        type="text" 
                        placeholder={t('notes.searchGifPlaceholder')} 
                        value={gifSearch || ""} 
                        onChange={(e) => setGifSearch(e.target.value)} 
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-xs text-white outline-none focus:border-purple-500 shadow-2xl transition-all" 
                      />
                   </div>
                   <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                      {searchingGif ? (
                        <div className="flex justify-center py-10"><div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"></div></div>
                      ) : (
                        <div className="grid grid-cols-2 gap-2">
                          {gifResults.map((gif, idx) => (
                            <img 
                              key={idx} 
                              src={gif} 
                              onClick={() => { setSelectedGif(gif); setView('main'); }}
                              className="w-full h-24 object-cover rounded-xl cursor-pointer hover:opacity-80 transition-all" 
                            />
                          ))}
                        </div>
                      )}
                   </div>
                </div>
              )}
           </div>
        </div>
      )}
    </div>
  );
};

export default NotesSystem;
