import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { P2PCallSession, p2pCallManager, playRingtone, playRingbackTone } from '../utils/p2pCallService';
import { useLanguage } from '../utils/i18n';
import { db } from '../firebase';
import { collection, query, where, getDocs, addDoc, serverTimestamp, doc, updateDoc, arrayUnion } from 'firebase/firestore';

interface P2PCallModalProps {
  user: User;
  incomingCall: P2PCallSession | null;
  activeSession: P2PCallSession | null;
  onAcceptIncoming: (callId: string) => void;
  onRejectIncoming: (callId: string) => void;
  onEndActiveCall: () => void;
  onClose?: () => void;
}

export const P2PCallModal: React.FC<P2PCallModalProps> = ({
  user,
  incomingCall,
  activeSession,
  onAcceptIncoming,
  onRejectIncoming,
  onEndActiveCall,
  onClose
}) => {
  const { t, dir } = useLanguage();
  const [isMuted, setIsMuted] = useState(false);
  const [isDeafened, setIsDeafened] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [isLocalSpeaking, setIsLocalSpeaking] = useState(false);
  const [isRemoteSpeaking, setIsRemoteSpeaking] = useState(false);
  const [endNotification, setEndNotification] = useState<string | null>(null);
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [friendsListData, setFriendsListData] = useState<User[]>([]);
  const [invitedIds, setInvitedIds] = useState<string[]>([]);
  const [loadingFriends, setLoadingFriends] = useState(false);
  const timerRef = useRef<any>(null);
  const noAnswerTimerRef = useRef<any>(null);

  // نغمة الرنين عند استقبال مكالمة واردة
  useEffect(() => {
    if (incomingCall && !activeSession) {
      const stopRingtone = playRingtone();
      return () => {
        stopRingtone();
      };
    }
  }, [incomingCall, activeSession]);

  // نغمة الانتظار + مؤقت 30 ثانية لعدم الرد للمتصل
  useEffect(() => {
    if (activeSession && activeSession.status === 'ringing' && activeSession.callerId === user.Id_user) {
      const stopRingback = playRingbackTone();

      noAnswerTimerRef.current = setTimeout(() => {
        setEndNotification('مكالمة لم يتم الرد عليها');
        onEndActiveCall();
        setTimeout(() => {
          setEndNotification(null);
        }, 4500);
      }, 30000);

      return () => {
        stopRingback();
        if (noAnswerTimerRef.current) {
          clearTimeout(noAnswerTimerRef.current);
          noAnswerTimerRef.current = null;
        }
      };
    }
  }, [activeSession?.callId, activeSession?.status, activeSession?.callerId, user.Id_user]);

  // إعداد مستمعات التحدث وحالة الجلسة
  useEffect(() => {
    p2pCallManager.setCallbacks({
      onSpeaking: (speaking) => {
        setIsLocalSpeaking(speaking);
      },
      onRemoteSpeaking: (speaking) => {
        setIsRemoteSpeaking(speaking);
      },
      onCallEnded: () => {
        setIsMuted(false);
        setIsDeafened(false);
        setShowAddMemberModal(false);
        setInvitedIds([]);
      }
    });
  }, []);

  // عداد مدة المكالمة عند الاتصال الفعلي
  useEffect(() => {
    if (activeSession && activeSession.status === 'connected') {
      timerRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [activeSession?.status]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    p2pCallManager.toggleMute(nextMuted);
  };

  const handleToggleDeafen = () => {
    const nextDeafened = !isDeafened;
    setIsDeafened(nextDeafened);
    p2pCallManager.toggleDeafen(nextDeafened);
  };

  const handleOpenAddMembers = async () => {
    setShowAddMemberModal(true);
    const friendIds = user.friendsList || [];
    if (friendIds.length === 0) {
      setFriendsListData([]);
      return;
    }
    setLoadingFriends(true);
    try {
      const otherId = activeSession
        ? (activeSession.callerId === user.Id_user ? activeSession.receiverId : activeSession.callerId)
        : '';
      const filteredIds = friendIds.filter(id => id !== otherId && id !== user.Id_user).slice(0, 10);
      if (filteredIds.length === 0) {
        setFriendsListData([]);
        return;
      }
      const q = query(collection(db, 'users'), where('Id_user', 'in', filteredIds));
      const snap = await getDocs(q);
      setFriendsListData(snap.docs.map(d => d.data() as User));
    } catch (e) {
      console.error('Failed to load friends for call invite:', e);
    } finally {
      setLoadingFriends(false);
    }
  };

  const handleInviteFriendToCall = async (friend: User) => {
    if (!activeSession || invitedIds.includes(friend.Id_user)) return;
    try {
      setInvitedIds(prev => [...prev, friend.Id_user]);
      // إضافة العضو لقائمة المشاركين في المكالمة وإرسال إشعار دعوة فوري
      await updateDoc(doc(db, 'calls', activeSession.callId), {
        invitedMembers: arrayUnion({
          id: friend.Id_user,
          name: friend.UserData,
          photo: friend.photoURL || ''
        })
      }).catch(() => {});

      await addDoc(collection(db, 'notifications'), {
        toId: friend.Id_user,
        fromId: user.Id_user,
        fromName: user.UserData,
        fromPhoto: user.photoURL || '',
        type: 'call_invite',
        callId: activeSession.callId,
        text: `يدعوك ${user.UserData} للانضمام إلى مكالمة صوتية`,
        read: false,
        timestamp: serverTimestamp()
      });
    } catch (e) {
      console.error('Failed to invite friend:', e);
    }
  };

  // إشعار مكالمة لم يتم الرد عليها
  const renderEndNotification = endNotification && (
    <div dir={dir} className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[600] bg-slate-900/95 border border-amber-500/40 text-white px-6 py-3.5 rounded-2xl shadow-2xl backdrop-blur-xl flex items-center space-x-3 space-x-reverse animate-in fade-in slide-in-from-bottom duration-300">
      <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
      </div>
      <div>
        <p className="text-xs font-black text-amber-400">{endNotification}</p>
        <p className="text-[10px] text-slate-400 font-bold">لم يتمكن الطرف الآخر من الرد خلال 30 ثانية</p>
      </div>
    </div>
  );

  // 1. واجهة المكالمة الواردة
  if (incomingCall && !activeSession) {
    return (
      <>
        {renderEndNotification}
        <div dir={dir} className="fixed inset-0 z-[550] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="w-full max-w-sm glass rounded-[2.5rem] p-6 border border-blue-500/30 shadow-2xl flex flex-col items-center text-center relative overflow-hidden">
            <div className="absolute -top-12 -right-12 w-36 h-36 bg-blue-600/20 rounded-full blur-2xl pointer-events-none"></div>
            <div className="absolute -bottom-12 -left-12 w-36 h-36 bg-emerald-600/20 rounded-full blur-2xl pointer-events-none"></div>

            <div className="inline-flex items-center space-x-2 space-x-reverse bg-blue-500/10 border border-blue-500/20 px-3 py-1 rounded-full mb-5">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-ping"></span>
              <span className="text-[10px] font-bold text-blue-400">مكالمة صوتية واردة</span>
            </div>

            <div className="relative mb-4">
              <div className="w-24 h-24 rounded-[2rem] p-1 bg-gradient-to-tr from-blue-600 to-emerald-500 animate-pulse">
                <img 
                  src={incomingCall.callerPhoto || `https://api.dicebear.com/7.x/bottts/svg?seed=${incomingCall.callerId}`} 
                  alt={incomingCall.callerName}
                  className="w-full h-full rounded-[1.8rem] object-cover bg-slate-900"
                />
              </div>
            </div>

            <h3 className="text-lg font-black text-white mb-1">{incomingCall.callerName}</h3>
            <p className="text-xs text-slate-400 mb-6 font-bold">يتصل بك الآن...</p>

            <div className="flex items-center justify-center space-x-6 space-x-reverse w-full">
              <button
                onClick={() => onAcceptIncoming(incomingCall.callId)}
                className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-black py-3.5 px-4 rounded-2xl flex items-center justify-center space-x-2 space-x-reverse shadow-lg shadow-emerald-600/30 transition-all hover:scale-105"
              >
                <svg className="w-5 h-5 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                <span className="text-xs">{t("call.acceptCall")}</span>
              </button>

              <button
                onClick={() => onRejectIncoming(incomingCall.callId)}
                className="flex-1 bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white border border-red-500/30 font-black py-3.5 px-4 rounded-2xl flex items-center justify-center space-x-2 space-x-reverse transition-all hover:scale-105"
              >
                <svg className="w-5 h-5 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12"/></svg>
                <span className="text-xs">{t("call.rejectCall")}</span>
              </button>
            </div>
          </div>
        </div>
      </>
    );
  }

  // 2. واجهة المكالمة النشطة
  if (!activeSession) {
    return renderEndNotification ? <>{renderEndNotification}</> : null;
  }

  const isMeCaller = activeSession.callerId === user.Id_user;
  const otherName = isMeCaller ? activeSession.receiverName : activeSession.callerName;
  const otherPhoto = isMeCaller ? activeSession.receiverPhoto : activeSession.callerPhoto;

  return (
    <>
      {renderEndNotification}
      <div dir={dir} className="fixed inset-0 z-[500] bg-slate-950 flex flex-col animate-in fade-in duration-300">
        {/* شريط الرأس */}
        <div className="px-4 pb-4 pt-[max(1rem,env(safe-area-inset-top))] sm:p-6 flex items-center justify-between border-b border-white/5 bg-slate-900/60 backdrop-blur-xl">
          <div className="flex items-center space-x-3 space-x-reverse">
            {onClose && (
              <button 
                onClick={onClose} 
                className="p-2 text-slate-400 hover:text-white transition-colors"
                title={t("call.minimize")}
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7"/></svg>
              </button>
            )}
            <div className="text-right">
              <h2 className="text-sm font-black text-white tracking-wide">{otherName}</h2>
              <div className="flex items-center space-x-2 space-x-reverse mt-0.5">
                <span className={`w-2 h-2 rounded-full ${activeSession.status === 'connected' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400 animate-ping'}`}></span>
                <span className="text-[10px] font-bold text-slate-300">
                  {activeSession.status === 'connected' ? `متصل • ${formatDuration(callDuration)}` : 'جارٍ الاتصال...'}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={handleOpenAddMembers}
            className="flex items-center space-x-1.5 space-x-reverse px-3 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 text-[10px] font-black transition-all active:scale-95"
            title="إضافة أعضاء للمكالمة"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
            <span>إضافة أعضاء</span>
          </button>
        </div>

        {/* جسم الشاشة: المشاركون */}
        <div className="flex-1 p-6 flex flex-col items-center justify-center overflow-y-auto custom-scrollbar">
          <div className="w-full max-w-lg flex flex-col items-center space-y-8">
            <div className="grid grid-cols-2 gap-6 sm:gap-10 w-full">
              {/* الطرف الآخر */}
              <div className="flex flex-col items-center space-y-3">
                <div className={`relative w-28 h-28 sm:w-36 sm:h-36 rounded-[2.5rem] p-1 transition-all duration-300 ${isRemoteSpeaking && !isDeafened ? 'bg-emerald-500 scale-105 shadow-2xl shadow-emerald-500/40' : 'bg-white/10'}`}>
                  <img 
                    src={otherPhoto || `https://api.dicebear.com/7.x/bottts/svg?seed=${isMeCaller ? activeSession.receiverId : activeSession.callerId}`} 
                    alt={otherName} 
                    className="w-full h-full rounded-[2.2rem] object-cover bg-slate-900 border-2 border-slate-950" 
                  />
                  {isRemoteSpeaking && !isDeafened && (
                    <div className="absolute -bottom-2 -right-2 bg-emerald-600 rounded-full p-2 shadow-xl animate-bounce">
                      <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2-3v-2.07z"/></svg>
                    </div>
                  )}
                </div>
                <div className="text-center">
                  <span className="text-xs font-black text-white block">{otherName}</span>
                  <span className="text-[10px] text-slate-400 block font-bold mt-0.5">
                    {activeSession.status === 'connected' ? (isDeafened ? 'صوت السماعة مكتوم' : 'متصل') : 'يرن...'}
                  </span>
                </div>
              </div>

              {/* جهازك الحالي */}
              <div className="flex flex-col items-center space-y-3">
                <div className={`relative w-28 h-28 sm:w-36 sm:h-36 rounded-[2.5rem] p-1 transition-all duration-300 ${isLocalSpeaking && !isMuted ? 'bg-blue-500 scale-105 shadow-2xl shadow-blue-500/40' : 'bg-white/10'}`}>
                  <img 
                    src={user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.Id_user}`} 
                    alt={user.UserData} 
                    className="w-full h-full rounded-[2.2rem] object-cover bg-slate-900 border-2 border-slate-950" 
                  />
                  {isMuted ? (
                    <div className="absolute -bottom-2 -right-2 bg-red-600 rounded-full p-2 shadow-xl">
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728L5.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" /></svg>
                    </div>
                  ) : isLocalSpeaking ? (
                    <div className="absolute -bottom-2 -right-2 bg-blue-600 rounded-full p-2 shadow-xl animate-bounce">
                      <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2-3v-2.07z"/></svg>
                    </div>
                  ) : null}
                </div>
                <div className="text-center">
                  <span className="text-xs font-black text-white block">{t("call.youSelf")} ({user.UserData})</span>
                  <span className="text-[10px] text-slate-400 block font-bold mt-0.5">
                    {isMuted ? 'الميكروفون مكتوم' : 'الميكروفون نشط'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* شريط التحكم السفلي */}
        <div className="p-6 sm:p-8 border-t border-white/5 bg-slate-900/60 backdrop-blur-xl flex flex-col items-center space-y-4">
          <div className="flex items-center space-x-4 sm:space-x-6 space-x-reverse">
            {/* زر كتم الميكروفون */}
            <button
              onClick={handleToggleMute}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-xl ${isMuted ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-white/10 text-slate-300 hover:bg-white/20'}`}
              title={isMuted ? t('call.unmuteMic') : t('call.muteMic')}
            >
              {isMuted ? (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728L5.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" /></svg>
              ) : (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/></svg>
              )}
            </button>

            {/* زر كتم السماعة (عدم سماع الآخرين) */}
            <button
              onClick={handleToggleDeafen}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-xl ${isDeafened ? 'bg-amber-600 text-white hover:bg-amber-700' : 'bg-white/10 text-slate-300 hover:bg-white/20'}`}
              title={isDeafened ? 'تشغيل صوت السماعة' : 'كتم الصوت (عدم سماع الآخرين)'}
            >
              {isDeafened ? (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2"/></svg>
              ) : (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/></svg>
              )}
            </button>

            {/* زر إنهاء المكالمة */}
            <button
              onClick={onEndActiveCall}
              className="px-7 h-14 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center space-x-2 space-x-reverse shadow-2xl shadow-red-600/40 hover:scale-105 transition-all font-black text-xs"
              title="إنهاء المكالمة"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M16 8l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M5 3a2 2 0 00-2 2v1c0 8.284 6.716 15 15 15h1a2 2 0 002-2v-3.28a1 1 0 00-.684-.948l-4.493-1.498a1 1 0 00-1.21.502l-1.13 2.257a11.042 11.042 0 01-5.516-5.516l2.257-1.13a1 1 0 00.502-1.21L9.228 3.683A1 1 0 008.279 3H5z"/></svg>
              <span>إنهاء المكالمة</span>
            </button>
          </div>
        </div>

        {/* نافذة إضافة أعضاء للمكالمة */}
        {showAddMemberModal && (
          <div className="fixed inset-0 z-[560] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
            <div className="w-full max-w-sm glass bg-slate-900 border border-white/10 rounded-[2.5rem] p-6 max-h-[75vh] flex flex-col">
              <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
                <h3 className="text-sm font-black text-white">إضافة أصدقاء للمكالمة</h3>
                <button onClick={() => setShowAddMemberModal(false)} className="p-1.5 text-slate-400 hover:text-white">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
              </div>
              <div className="flex-1 overflow-y-auto space-y-2.5 custom-scrollbar">
                {loadingFriends ? (
                  <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div></div>
                ) : friendsListData.length === 0 ? (
                  <p className="text-center text-xs text-slate-400 py-8 font-bold">لا يوجد أصدقاء آخرون لإضافتهم حالياً</p>
                ) : (
                  friendsListData.map(friend => {
                    const isInvited = invitedIds.includes(friend.Id_user);
                    return (
                      <div key={friend.Id_user} className="flex items-center justify-between p-3 bg-white/5 rounded-2xl border border-white/5">
                        <div className="flex items-center space-x-3 space-x-reverse min-w-0">
                          <img src={friend.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${friend.Id_user}`} className="w-10 h-10 rounded-xl object-cover shrink-0" alt={friend.UserData} />
                          <span className="text-xs font-black text-white truncate">{friend.UserData}</span>
                        </div>
                        <button
                          onClick={() => handleInviteFriendToCall(friend)}
                          disabled={isInvited}
                          className={`px-3.5 py-2 rounded-xl text-[10px] font-black transition-all shrink-0 ${isInvited ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30' : 'bg-blue-600 hover:bg-blue-500 text-white'}`}
                        >
                          {isInvited ? 'تمت الدعوة ✓' : 'إضافة'}
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default P2PCallModal;
