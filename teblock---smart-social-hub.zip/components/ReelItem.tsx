import React, { useRef, useEffect, useState } from 'react';
import { Reel } from '../types';
import { optimizeVideoUrl, optimizeImageUrl } from '../utils/mediaOptimizer';

interface ReelItemProps {
  reel: Reel;
  isActive: boolean;
  isMuted: boolean;
  onDoubleTap: (reel: Reel) => void;
}

export const ReelItem: React.FC<ReelItemProps> = ({ reel, isActive, isMuted, onDoubleTap }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const clickTimeout = useRef<any>(null);

  const mediaList = reel.mediaUrls && reel.mediaUrls.length > 0 
    ? reel.mediaUrls 
    : reel.videoUrl ? [{ url: reel.videoUrl, type: 'video' }] : [];

  const playVideoPromiseRef = useRef<Promise<void> | null>(null);

  useEffect(() => {
    if (isActive) {
      if (videoRef.current) {
        const p = videoRef.current.play();
        if (p !== undefined) {
          playVideoPromiseRef.current = p;
          p.catch(e => { if (e.name !== 'AbortError') console.log('Video play error', e); });
        }
      }
      setIsPlaying(true);
    } else {
      if (videoRef.current) {
        if (playVideoPromiseRef.current) {
          playVideoPromiseRef.current.then(() => {
            videoRef.current?.pause();
            if (videoRef.current) videoRef.current.currentTime = 0;
          }).catch(() => {
            videoRef.current?.pause();
            if (videoRef.current) videoRef.current.currentTime = 0;
          });
        } else {
          videoRef.current.pause();
          videoRef.current.currentTime = 0;
        }
      }
      setIsPlaying(false);
    }
  }, [isActive]);

  const handleInteraction = (e: React.MouseEvent) => {
    if (clickTimeout.current) {
      clearTimeout(clickTimeout.current);
      clickTimeout.current = null;
      onDoubleTap(reel);
    } else {
      clickTimeout.current = setTimeout(() => {
        setIsPlaying(prev => {
          const nextState = !prev;
          if (nextState) {
            if (videoRef.current) videoRef.current.play();
          } else {
            if (videoRef.current) videoRef.current.pause();
          }
          return nextState;
        });
        clickTimeout.current = null;
      }, 250);
    }
  };

  const longPressTimer = useRef<any>(null);

  const startLongPress = () => {
    longPressTimer.current = setTimeout(() => {
      if (videoRef.current) videoRef.current.playbackRate = 2.0;
    }, 500);
  };

  const endLongPress = () => {
    clearTimeout(longPressTimer.current);
    if (videoRef.current) videoRef.current.playbackRate = 1.0;
  };

  return (
    <div 
      className="h-full w-full relative flex items-center justify-center bg-black overflow-hidden reel-item-container" 
      data-reel-id={reel.id}
      onMouseDown={startLongPress}
      onMouseUp={endLongPress}
      onMouseLeave={endLongPress}
      onTouchStart={startLongPress}
      onTouchEnd={endLongPress}
    >
      <div 
        className="w-full h-full flex overflow-x-auto snap-x snap-mandatory scrollbar-hide no-scrollbar"
        onClick={handleInteraction}
      >
        {mediaList.map((media, idx) => (
          <div key={idx} className="w-full h-full shrink-0 snap-center flex items-center justify-center bg-black relative">
            {media.type === 'video' ? (
              <video 
                ref={videoRef}
                src={optimizeVideoUrl(media.url)} 
                className="h-full w-full object-contain" 
                loop 
                muted={isMuted}
                playsInline
                preload={isActive ? 'auto' : 'metadata'}
              />
            ) : (
              <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
                <img src={optimizeImageUrl(media.url, 1080)} alt="" className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-30 scale-110 pointer-events-none select-none" />
                <img src={optimizeImageUrl(media.url, 1080)} alt="Media content" className="relative z-10 max-h-full max-w-full w-auto h-auto object-contain select-none" />
              </div>
            )}
          </div>
        ))}
      </div>
      
      {mediaList.length > 1 && (
        <div className="absolute top-4 left-0 right-0 flex justify-center space-x-1 z-10 pointer-events-none">
          {mediaList.map((_, i) => (
            <div key={i} className="w-1.5 h-1.5 rounded-full bg-white/50 shadow-md"></div>
          ))}
        </div>
      )}
      
      {!isPlaying && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none bg-black/20 z-10">
          <div className="w-16 h-16 rounded-full bg-black/40 flex items-center justify-center text-white backdrop-blur-sm">
            <svg className="w-8 h-8 ml-1" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"/></svg>
          </div>
        </div>
      )}
    </div>
  );
};
