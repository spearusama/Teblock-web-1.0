import React, { useState, useEffect } from 'react';
import { User, Reel } from '../types';
import { db } from '../firebase';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  doc, 
  updateDoc, 
  arrayUnion, 
  arrayRemove, 
  addDoc, 
  serverTimestamp,
  getDocs,
  limit 
} from 'firebase/firestore';
import { useLanguage } from '../utils/i18n';
import { optimizeVideoUrl } from '../utils/mediaOptimizer';
import { generatePermanentId2, calculateAge, getUserProfileUrl } from '../utils/userUtils';
import ImageCropperModal from './ImageCropperModal';

interface ProfileViewProps {
  currentUser: User;
  targetUserId: string;
  onBack?: () => void;
  onNavigateToReels?: (reelId: string) => void;
  onNavigateToChat?: (chat: any) => void;
  onNavigateSettings?: () => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ 
  currentUser, 
  targetUserId, 
  onBack, 
  onNavigateToReels, 
  onNavigateToChat,
  onNavigateSettings 
}) => {
  const { t, dir } = useLanguage();
  const [targetUser, setTargetUser] = useState<User | null>(null);
  const [userReels, setUserReels] = useState<Reel[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [showPhotoMenu, setShowPhotoMenu] = useState(false);
  const [showFriendsModal, setShowFriendsModal] = useState(false);
  const [showAccountInfoModal, setShowAccountInfoModal] = useState(false);
  const [showBioModal, setShowBioModal] = useState(false);
  const [bioInput, setBioInput] = useState('');
  const [isSavingBio, setIsSavingBio] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedId2, setCopiedId2] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const CLOUD_NAME = "dei75gqcl";
  const UPLOAD_PRESET = "TEBLOCK";

  const isOwnProfile = targetUser 
    ? (currentUser.Id_user === targetUser.Id_user || (!!currentUser['id-2'] && currentUser['id-2'] === targetUser['id-2']))
    : (currentUser.Id_user === targetUserId || currentUser['id-2'] === targetUserId);

  const [pendingCropFile, setPendingCropFile] = useState<File | null>(null);

  const uploadCroppedProfilePhoto = async (croppedFile: File) => {
    if (!targetUser) return;
    const realDocId = targetUser.Id_user;
    setPendingCropFile(null);
    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', croppedFile);
      formData.append('upload_preset', UPLOAD_PRESET);
      const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (data.secure_url) {
        await updateDoc(doc(db, 'users', realDocId), { photoURL: data.secure_url });
      }
    } catch (err) {
      console.error("Upload failed", err);
    } finally {
      setIsUploading(false);
      setShowPhotoMenu(false);
    }
  };

  const handlePhotoAction = async (action: 'change' | 'delete') => {
    if (!targetUser) return;
    const realDocId = targetUser.Id_user;

    if (action === 'delete') {
      const defaultPhoto = `https://api.dicebear.com/7.x/bottts/svg?seed=${realDocId}`;
      await updateDoc(doc(db, 'users', realDocId), { photoURL: defaultPhoto });
      setShowPhotoMenu(false);
      return;
    }

    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      setShowPhotoMenu(false);
      setPendingCropFile(file);
    };
    input.click();
  };

  const handleSaveBio = async () => {
    if (!targetUser) return;
    setIsSavingBio(true);
    try {
      const trimmed = bioInput.trim();
      await updateDoc(doc(db, 'users', targetUser.Id_user), {
        bio: trimmed
      });
      setTargetUser(prev => prev ? { ...prev, bio: trimmed } : null);
      setShowBioModal(false);
    } catch (err) {
      console.error("Failed to save bio", err);
    } finally {
      setIsSavingBio(false);
    }
  };

  const handleCopyProfileUrl = () => {
    if (!targetUser) return;
    const url = getUserProfileUrl(targetUser['id-2'], targetUser.Id_user);
    navigator.clipboard.writeText(url).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }).catch(console.error);
  };

  const handleCopyId2 = () => {
    if (!targetUser || !targetUser['id-2']) return;
    navigator.clipboard.writeText(targetUser['id-2']).then(() => {
      setCopiedId2(true);
      setTimeout(() => setCopiedId2(false), 2500);
    }).catch(console.error);
  };

  useEffect(() => {
    setLoading(true);
    let isSubscribed = true;
    let unsubUserDoc: (() => void) | null = null;
    let unsubReels: (() => void) | null = null;

    const setupUser = (userData: User, userDocId: string) => {
      // Ensure permanent 10-digit id-2 exists
      if (!userData['id-2']) {
        const newId2 = generatePermanentId2();
        updateDoc(doc(db, 'users', userDocId), { 'id-2': newId2 }).catch(console.error);
        userData['id-2'] = newId2;
      }

      setTargetUser(userData);
      setBioInput(userData.bio || '');
      setLoading(false);

      // Subscribe to user reels
      const reelsQ = query(
        collection(db, 'reels'), 
        where('userId', '==', userData.Id_user || userDocId)
      );
      
      unsubReels = onSnapshot(reelsQ, (snap) => {
        if (!isSubscribed) return;
        const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Reel));
        data.sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
        setUserReels(data);
      });
    };

    // First try resolving targetUserId as a direct doc id
    const docRef = doc(db, 'users', targetUserId);
    unsubUserDoc = onSnapshot(docRef, async (snap) => {
      if (snap.exists()) {
        setupUser(snap.data() as User, snap.id);
      } else {
        // Query by 'id-2' if not direct doc ID
        try {
          const q = query(collection(db, 'users'), where('id-2', '==', targetUserId), limit(1));
          const querySnap = await getDocs(q);
          if (!isSubscribed) return;
          if (!querySnap.empty) {
            const foundDoc = querySnap.docs[0];
            setupUser(foundDoc.data() as User, foundDoc.id);

            // Re-subscribe to the resolved document for real-time updates
            if (unsubUserDoc) unsubUserDoc();
            unsubUserDoc = onSnapshot(foundDoc.ref, (updatedSnap) => {
              if (updatedSnap.exists() && isSubscribed) {
                const updatedData = updatedSnap.data() as User;
                setTargetUser(updatedData);
                setBioInput(updatedData.bio || '');
              }
            });
          } else {
            setTargetUser(null);
            setLoading(false);
          }
        } catch (err) {
          console.error("Error looking up user by id-2:", err);
          if (isSubscribed) {
            setTargetUser(null);
            setLoading(false);
          }
        }
      }
    });

    return () => {
      isSubscribed = false;
      if (unsubUserDoc) unsubUserDoc();
      if (unsubReels) unsubReels();
    };
  }, [targetUserId]);

  if (loading) return (
    <div className="flex-1 flex items-center justify-center bg-black">
      <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  if (!targetUser) return (
    <div dir={dir} className="flex-1 flex flex-col items-center justify-center bg-black text-slate-500 p-6 text-center">
      <div className="w-16 h-16 rounded-3xl bg-white/5 flex items-center justify-center mb-4 text-slate-600">
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" strokeWidth={2}/></svg>
      </div>
      <p className="text-sm font-black uppercase tracking-widest text-slate-400">الحساب غير موجود</p>
      <p className="text-xs text-slate-600 mt-1 max-w-xs">تعذر العثور على الحساب المطلوب أو تم تغيير المعرف.</p>
      {onBack && (
        <button onClick={onBack} className="mt-5 px-5 py-2.5 bg-blue-600/20 text-blue-400 border border-blue-500/30 rounded-xl font-bold text-xs hover:bg-blue-600 hover:text-white transition-all">
          {t('profile.back')}
        </button>
      )}
    </div>
  );

  const isBlockedByTarget = Boolean(!isOwnProfile && targetUser.blockedUsers?.includes(currentUser.Id_user));
  const isBlockedByMe = Boolean(!isOwnProfile && currentUser.blockedUsers?.includes(targetUser.Id_user));

  if (isBlockedByTarget) return (
    <div dir={dir} className="flex-1 flex flex-col items-center justify-center bg-black text-slate-500 p-6 text-center">
      <div className="w-16 h-16 rounded-3xl bg-white/5 flex items-center justify-center mb-4 text-slate-600">
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
      </div>
      <p className="text-base font-black text-white">هذا المستخدم غير متوفر</p>
      <p className="text-xs text-slate-500 mt-1 max-w-xs">لا يمكنك عرض هذه الصفحة أو التواصل مع هذا الحساب.</p>
      {onBack && (
        <button onClick={onBack} className="mt-5 px-5 py-2.5 bg-blue-600/20 text-blue-400 border border-blue-500/30 rounded-xl font-bold text-xs hover:bg-blue-600 hover:text-white transition-all">
          {t('profile.back')}
        </button>
      )}
    </div>
  );

  const calculatedAge = calculateAge(targetUser.birthDate);
  const profileUrl = getUserProfileUrl(targetUser['id-2'], targetUser.Id_user);

  return (
    <div dir={dir} className="flex-1 flex flex-col bg-[var(--teblock-bg)] h-full overflow-y-auto custom-scrollbar animate-in fade-in slide-in-from-left duration-300 pb-24">
      {/* Profile Header */}
      <div className="relative pt-12 pb-6 px-6 text-center border-b border-white/5 bg-gradient-to-b from-blue-600/10 via-transparent to-transparent">
        {onBack && (
          <button 
            onClick={onBack} 
            className="absolute top-6 rtl:right-6 ltr:left-6 p-2.5 glass rounded-xl text-slate-400 z-10 hover:text-white transition-colors border border-white/10"
            title={t('profile.back')}
          >
            <svg className="w-5 h-5 flip-in-ltr" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14 5l7 7m0 0l-7 7m7-7H3" strokeWidth={3}/></svg>
          </button>
        )}

        {/* Share Profile Link Button */}
        <button
          onClick={handleCopyProfileUrl}
          className="absolute top-6 rtl:left-6 ltr:right-6 p-2.5 glass rounded-xl text-slate-400 z-10 hover:text-white transition-colors border border-white/10 flex items-center space-x-1.5 space-x-reverse"
          title="مشاركة رابط الحساب"
        >
          {copiedLink ? (
            <>
              <svg className="w-4 h-4 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7" strokeWidth={3}/></svg>
              <span className="text-[10px] font-bold text-green-400">تم النسخ</span>
            </>
          ) : (
            <>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" strokeWidth={2}/></svg>
              <span className="text-[10px] font-bold hidden sm:inline">مشاركة</span>
            </>
          )}
        </button>
        
        {/* Profile Avatar */}
        <div className="relative inline-block mb-3">
          <div 
            onClick={() => setShowPhotoModal(true)}
            className="w-24 h-24 rounded-[2.2rem] border-4 border-blue-600 p-1 bg-slate-900 shadow-2xl overflow-hidden mx-auto cursor-pointer group"
          >
            <img 
              src={targetUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${targetUser.Id_user}`} 
              className="w-full h-full object-cover rounded-[1.8rem] group-hover:scale-105 transition-transform duration-300" 
              alt={targetUser.UserData}
            />
          </div>
          {targetUser.accountType === 'page' && (
            <div className="absolute -bottom-1 -left-1 bg-blue-600 text-white p-1 rounded-lg border-2 border-slate-900 shadow-lg" title="صفحة عامة">
              <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/></svg>
            </div>
          )}
          {isOwnProfile && (
            <div className="absolute -top-1 -left-1">
              <button 
                onClick={(e) => { e.stopPropagation(); setShowPhotoMenu(!showPhotoMenu); }}
                className="p-2 bg-slate-800/90 backdrop-blur rounded-xl text-white border border-white/10 shadow-lg hover:bg-slate-700 transition-all"
                title={t('profile.changePhoto')}
              >
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 5v.01M12 12v.01M12 19v.01" strokeWidth={3}/></svg>
              </button>
              
              {showPhotoMenu && (
                <div className="absolute top-10 rtl:left-0 ltr:left-0 bg-slate-900 border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-50 w-44 animate-in fade-in slide-in-from-top-2">
                  <button 
                    onClick={() => handlePhotoAction('change')}
                    disabled={isUploading}
                    className="w-full px-4 py-3 rtl:text-right ltr:text-left text-[10px] font-black text-white hover:bg-white/5 flex items-center justify-between space-x-2 space-x-reverse"
                  >
                    <span>{t('profile.changePhoto')}</span>
                    <svg className="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth={2}/></svg>
                  </button>
                  {targetUser.photoURL && !targetUser.photoURL.includes('dicebear.com') && (
                    <button 
                      onClick={() => handlePhotoAction('delete')}
                      className="w-full px-4 py-3 rtl:text-right ltr:text-left text-[10px] font-black text-red-500 hover:bg-red-500/10 flex items-center justify-between space-x-2 space-x-reverse border-t border-white/5"
                    >
                      <span>{t('profile.deletePhoto')}</span>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth={2}/></svg>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Username */}
        <h2 className="text-xl font-black text-white leading-tight">{targetUser.UserData}</h2>
        
        {/* IDs and Permanent 10-digit id-2 */}
        <div className="flex items-center justify-center flex-wrap gap-2 mt-2">
          {targetUser['id-2'] && (
            <button
              onClick={handleCopyId2}
              className="inline-flex items-center space-x-1.5 space-x-reverse px-2.5 py-1 rounded-lg bg-blue-600/15 border border-blue-500/30 text-blue-400 hover:bg-blue-600/25 transition-all active:scale-95 text-[11px] font-mono font-bold"
              title="انقر لنسخ المعرف الدائم id-2"
            >
              <span className="text-[9px] font-sans font-black bg-blue-500 text-black px-1 rounded uppercase tracking-wider">ID-2</span>
              <span>{targetUser['id-2']}</span>
              <svg className="w-3 h-3 opacity-60" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" strokeWidth={2}/></svg>
            </button>
          )}

          <span className="text-[10px] text-slate-500 font-mono font-semibold px-2 py-0.5 rounded bg-white/[0.03]">
            @{targetUser.Id_user}
          </span>
        </div>

        {/* Bio Section - منطقة البايو */}
        <div className="mt-4 max-w-md mx-auto px-2">
          {targetUser.bio ? (
            <div className="relative glass p-3.5 rounded-2xl border border-white/5 text-slate-200 text-xs leading-relaxed rtl:text-right ltr:text-left group">
              <p className="whitespace-pre-line font-medium break-words">{targetUser.bio}</p>
              {isOwnProfile && (
                <button
                  onClick={() => setShowBioModal(true)}
                  className="absolute top-2 rtl:left-2 ltr:right-2 p-1.5 rounded-lg bg-white/5 hover:bg-blue-600/20 text-slate-400 hover:text-blue-400 transition-colors opacity-80 group-hover:opacity-100"
                  title="تعديل البايو"
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth={2}/></svg>
                </button>
              )}
            </div>
          ) : isOwnProfile ? (
            <button
              onClick={() => setShowBioModal(true)}
              className="w-full py-2.5 px-4 rounded-xl border border-dashed border-white/15 bg-white/[0.02] hover:bg-white/[0.06] text-slate-400 hover:text-white transition-all text-xs font-semibold flex items-center justify-center space-x-2 space-x-reverse"
            >
              <svg className="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" strokeWidth={2}/></svg>
              <span>أضف نبذة تعريفية عنك (Bio)... ✍️</span>
            </button>
          ) : null}
        </div>

        {/* Stats Row */}
        <div className="flex justify-center items-center space-x-6 space-x-reverse mt-5">
          <div className="text-center">
            <p className="text-base font-black text-white">{userReels.length}</p>
            <p className="text-[8px] text-slate-500 font-bold uppercase tracking-tighter">{t('profile.posts')}</p>
          </div>
          <div className="w-px h-6 bg-white/10"></div>
          <div className="text-center cursor-pointer hover:opacity-80 transition-opacity" onClick={() => setShowFriendsModal(true)}>
            <p className="text-base font-black text-white">
              {targetUser.accountType === 'page' ? (targetUser.followersList?.length || 0) : (targetUser.friendsList?.length || 0)}
            </p>
            <p className="text-[8px] text-slate-500 font-bold uppercase tracking-tighter">
              {targetUser.accountType === 'page' ? t('profile.follower') : t('profile.friend')}
            </p>
          </div>
        </div>

        {/* Action Buttons for non-owners */}
        {!isOwnProfile && (
          <div className="flex justify-center items-center space-x-3 space-x-reverse mt-6 px-2 max-w-md mx-auto">
            <button 
              onClick={() => onNavigateToChat?.({ id: targetUser.Id_user, name: targetUser.UserData, photo: targetUser.photoURL, isGroup: false })}
              className="flex-1 py-3.5 bg-blue-600 text-white rounded-2xl font-black text-xs shadow-xl shadow-blue-600/20 active:scale-95 transition-all flex items-center justify-center space-x-2 space-x-reverse hover:bg-blue-500"
            >
              <span>{t('profile.message')}</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" strokeWidth={2.5}/></svg>
            </button>
            
            {targetUser.accountType === 'page' ? (
              <button 
                onClick={async () => {
                  const isFollowing = targetUser.followersList?.includes(currentUser.Id_user);
                  if (isFollowing) {
                    await updateDoc(doc(db, 'users', targetUser.Id_user), { followersList: arrayRemove(currentUser.Id_user) });
                  } else {
                    await updateDoc(doc(db, 'users', targetUser.Id_user), { followersList: arrayUnion(currentUser.Id_user) });
                  }
                }}
                className={`flex-1 py-3.5 rounded-2xl font-black text-xs border transition-all flex items-center justify-center space-x-2 space-x-reverse ${targetUser.followersList?.includes(currentUser.Id_user) ? 'bg-white/5 border-white/10 text-slate-400' : 'bg-white text-black border-white shadow-xl'}`}
              >
                <span>{targetUser.followersList?.includes(currentUser.Id_user) ? t('profile.following') : t('profile.follow')}</span>
                {!targetUser.followersList?.includes(currentUser.Id_user) && <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={3}/></svg>}
              </button>
            ) : (
              <button 
                onClick={async () => {
                  const isFriend = currentUser.friendsList?.includes(targetUser.Id_user);
                  const isSent = currentUser.sentRequests?.includes(targetUser.Id_user);
                  const isPending = currentUser.pendingRequests?.includes(targetUser.Id_user);

                  if (isFriend) {
                    await updateDoc(doc(db, 'users', currentUser.Id_user), { friendsList: arrayRemove(targetUser.Id_user) });
                    await updateDoc(doc(db, 'users', targetUser.Id_user), { friendsList: arrayRemove(currentUser.Id_user) });
                  } else if (isSent) {
                    await updateDoc(doc(db, 'users', currentUser.Id_user), { sentRequests: arrayRemove(targetUser.Id_user) });
                    await updateDoc(doc(db, 'users', targetUser.Id_user), { pendingRequests: arrayRemove(currentUser.Id_user) });
                  } else if (isPending) {
                    await updateDoc(doc(db, 'users', currentUser.Id_user), { 
                      pendingRequests: arrayRemove(targetUser.Id_user),
                      friendsList: arrayUnion(targetUser.Id_user)
                    });
                    await updateDoc(doc(db, 'users', targetUser.Id_user), { 
                      sentRequests: arrayRemove(currentUser.Id_user),
                      friendsList: arrayUnion(currentUser.Id_user)
                    });
                    
                    await addDoc(collection(db, 'notifications'), {
                      toId: targetUser.Id_user,
                      fromId: currentUser.Id_user,
                      fromName: currentUser.UserData,
                      fromPhoto: currentUser.photoURL,
                      type: 'accept_friend',
                      read: false,
                      timestamp: serverTimestamp()
                    });
                  } else {
                    await updateDoc(doc(db, 'users', currentUser.Id_user), { sentRequests: arrayUnion(targetUser.Id_user) });
                    await updateDoc(doc(db, 'users', targetUser.Id_user), { pendingRequests: arrayUnion(currentUser.Id_user) });
                    
                    await addDoc(collection(db, 'notifications'), {
                      toId: targetUser.Id_user,
                      fromId: currentUser.Id_user,
                      fromName: currentUser.UserData,
                      fromPhoto: currentUser.photoURL,
                      type: 'friend_request',
                      read: false,
                      timestamp: serverTimestamp()
                    });
                  }
                }}
                className={`flex-1 py-3.5 rounded-2xl font-black text-xs border transition-all flex items-center justify-center space-x-2 space-x-reverse ${
                  currentUser.friendsList?.includes(targetUser.Id_user) ? 'bg-white/5 border-white/10 text-slate-400' : 
                  currentUser.sentRequests?.includes(targetUser.Id_user) ? 'bg-blue-600/20 border-blue-500/30 text-blue-400' :
                  currentUser.pendingRequests?.includes(targetUser.Id_user) ? 'bg-green-600/20 border-green-500/30 text-green-400' :
                  'bg-white text-black border-white shadow-xl'
                }`}
              >
                <span>
                  {currentUser.friendsList?.includes(targetUser.Id_user) ? t('profile.friend') : 
                   currentUser.sentRequests?.includes(targetUser.Id_user) ? t('profile.requestSent') :
                   currentUser.pendingRequests?.includes(targetUser.Id_user) ? t('profile.acceptRequest') :
                   t('profile.addFriend')}
                </span>
                {!currentUser.friendsList?.includes(targetUser.Id_user) && !currentUser.sentRequests?.includes(targetUser.Id_user) && !currentUser.pendingRequests?.includes(targetUser.Id_user) && <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" strokeWidth={2.5}/></svg>}
              </button>
            )}
          </div>
        )}
      </div>

      {/* Account Info Button - معلومات الحساب كزر */}
      <div className="px-6 py-4 max-w-lg mx-auto w-full">
        <button
          onClick={() => setShowAccountInfoModal(true)}
          className="w-full py-4 px-5 glass bg-gradient-to-r from-blue-600/10 via-white/[0.04] to-blue-600/10 hover:from-blue-600/20 hover:to-blue-600/20 border border-blue-500/30 hover:border-blue-500/50 rounded-2xl flex items-center justify-between text-white transition-all shadow-lg shadow-blue-900/10 active:scale-[0.98] group"
        >
          <div className="flex items-center space-x-3.5 space-x-reverse">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30 group-hover:scale-105 transition-transform shadow-inner">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" strokeWidth={2}/></svg>
            </div>
            <div className="rtl:text-right ltr:text-left">
              <span className="text-xs sm:text-sm font-black block text-white tracking-wide">معلومات الحساب</span>
              <span className="text-[10px] text-slate-400 font-medium">البلد، العمر، تاريخ الإزدياد والمعرف</span>
            </div>
          </div>
          <div className="flex items-center space-x-2 space-x-reverse text-blue-400 group-hover:text-blue-300">
            <span className="text-[11px] font-bold">عرض</span>
            <svg className="w-4 h-4 rtl:rotate-180 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" strokeWidth={2.5}/></svg>
          </div>
        </button>
      </div>

      {/* Reels Gallery */}
      <div className="px-6 pb-20 max-w-4xl mx-auto w-full">
        <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4 rtl:text-right ltr:text-left">{t('profile.gallery')}</h4>
        {userReels.length === 0 ? (
          <div className="py-20 text-center glass rounded-3xl opacity-30">
             <p className="text-xs font-black">{t('profile.noPostsYet')}</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            {userReels.map(reel => (
              <div 
                key={reel.id} 
                onClick={() => onNavigateToReels?.(reel.id)}
                className="aspect-[9/16] bg-slate-900 rounded-xl overflow-hidden relative border border-white/5 group cursor-pointer hover:border-blue-500/40 transition-colors"
              >
                 <video src={optimizeVideoUrl(reel.videoUrl || '', 'saver') || undefined} className="w-full h-full object-cover" muted preload="metadata" />
                 <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="flex items-center text-white space-x-1 space-x-reverse">
                       <svg className="w-3.5 h-3.5 text-red-500" fill="currentColor" viewBox="0 0 20 20"><path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z"/></svg>
                       <span className="text-[11px] font-black">{reel.likes?.length || 0}</span>
                    </div>
                 </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Account Info Modal - نافذة معلومات الحساب (البلد، العمر، تاريخ الإزدياد) */}
      {showAccountInfoModal && (
        <div className="fixed inset-0 z-[220] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="w-full max-w-sm glass bg-slate-900/95 border border-white/10 rounded-[2.5rem] p-6 shadow-2xl relative animate-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
              <div className="flex items-center space-x-2 space-x-reverse">
                <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" strokeWidth={2}/></svg>
                </div>
                <h3 className="text-sm font-black text-white">معلومات الحساب</h3>
              </div>
              <button 
                onClick={() => setShowAccountInfoModal(false)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>

            {/* Content List */}
            <div className="space-y-3.5">
              {/* Permanent 10-digit ID */}
              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 flex items-center justify-between">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14" strokeWidth={2}/></svg>
                  </div>
                  <div className="rtl:text-right ltr:text-left">
                    <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">المعرف الدائم (ID-2)</span>
                    <span className="text-sm font-mono font-black text-blue-400">{targetUser['id-2'] || 'جارٍ التوليد...'}</span>
                  </div>
                </div>
                {targetUser['id-2'] && (
                  <button
                    onClick={handleCopyId2}
                    className="p-2 rounded-xl bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white transition-all text-[10px] font-bold"
                    title="نسخ المعرف"
                  >
                    {copiedId2 ? 'تم النسخ!' : 'نسخ'}
                  </button>
                )}
              </div>

              {/* Country - البلد */}
              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 flex items-center space-x-3 space-x-reverse">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth={2}/></svg>
                </div>
                <div className="rtl:text-right ltr:text-left flex-1">
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">البلد</span>
                  <span className="text-xs font-black text-white">{targetUser.country || 'غير محدد'}</span>
                </div>
              </div>

              {/* Age - العمر */}
              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 flex items-center space-x-3 space-x-reverse">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth={2}/></svg>
                </div>
                <div className="rtl:text-right ltr:text-left flex-1">
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">العمر</span>
                  <span className="text-xs font-black text-white">
                    {calculatedAge !== null ? `${calculatedAge} سنة` : 'غير محدد'}
                  </span>
                </div>
              </div>

              {/* Birthday - تاريخ الإزدياد */}
              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 flex items-center space-x-3 space-x-reverse">
                <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth={2}/></svg>
                </div>
                <div className="rtl:text-right ltr:text-left flex-1">
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">تاريخ الإزدياد</span>
                  <span className="text-xs font-black text-white">{targetUser.birthDate || 'غير محدد'}</span>
                </div>
              </div>

              {/* Account Link /user/:id2 */}
              <div className="p-3.5 rounded-2xl bg-blue-600/10 border border-blue-500/20">
                <span className="text-[9px] text-blue-400 font-bold uppercase tracking-wider block mb-1">رابط الحساب المباشر</span>
                <div className="flex items-center justify-between space-x-2 space-x-reverse">
                  <span className="text-[11px] font-mono text-slate-300 truncate max-w-[200px]">
                    /user/{targetUser['id-2'] || targetUser.Id_user}
                  </span>
                  <button
                    onClick={handleCopyProfileUrl}
                    className="px-3 py-1.5 rounded-xl bg-blue-600 text-white font-bold text-[10px] hover:bg-blue-500 transition-all flex items-center space-x-1 space-x-reverse shrink-0"
                  >
                    {copiedLink ? (
                      <>
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7" strokeWidth={3}/></svg>
                        <span>تم النسخ</span>
                      </>
                    ) : (
                      <>
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" strokeWidth={2}/></svg>
                        <span>نسخ الرابط</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            {isOwnProfile && onNavigateSettings && (
              <div className="mt-5 pt-4 border-t border-white/5">
                <button
                  onClick={() => {
                    setShowAccountInfoModal(false);
                    onNavigateSettings();
                  }}
                  className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-all text-xs font-bold flex items-center justify-center space-x-2 space-x-reverse"
                >
                  <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" strokeWidth={2}/></svg>
                  <span>تعديل بيانات الحساب في الإعدادات</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Bio Edit Modal - تعديل البايو */}
      {showBioModal && isOwnProfile && (
        <div className="fixed inset-0 z-[220] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="w-full max-w-sm glass bg-slate-900 border border-white/10 rounded-[2.5rem] p-6 shadow-2xl relative animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
              <div className="flex items-center space-x-2 space-x-reverse">
                <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" strokeWidth={2}/></svg>
                </div>
                <h3 className="text-sm font-black text-white">تعديل النبذة التعريفية (Bio)</h3>
              </div>
              <button 
                onClick={() => setShowBioModal(false)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-3 rtl:text-right ltr:text-left">
              اكتب سطوراً مميزة تعبر عنك أو عن اهتماماتك ليراها الآخرون في ملفك الشخصي:
            </p>

            <textarea
              value={bioInput}
              onChange={(e) => setBioInput(e.target.value.slice(0, 180))}
              placeholder="اكتب نبذتك هنا..."
              rows={4}
              className="w-full p-3.5 bg-black/40 border border-white/10 rounded-2xl text-white text-xs placeholder-slate-600 focus:outline-none focus:border-blue-500 resize-none font-medium custom-scrollbar rtl:text-right ltr:text-left"
            />
            
            <div className="flex items-center justify-between mt-2 text-[10px] text-slate-500 font-mono">
              <span>{180 - bioInput.length} حرف متبقي</span>
              <span>الحد الأقصى: 180</span>
            </div>

            <div className="flex items-center space-x-3 space-x-reverse mt-5">
              <button
                onClick={handleSaveBio}
                disabled={isSavingBio}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-black text-xs shadow-lg shadow-blue-600/30 transition-all disabled:opacity-50"
              >
                {isSavingBio ? 'جارٍ الحفظ...' : 'حفظ التغييرات'}
              </button>
              <button
                onClick={() => setShowBioModal(false)}
                className="px-5 py-3 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl font-bold text-xs transition-all"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Photo Modal */}
      {showPhotoModal && (
        <div className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center p-6 animate-in zoom-in duration-300">
          <div className="relative w-full max-w-sm">
            <button onClick={() => setShowPhotoModal(false)} className="absolute -top-12 rtl:right-0 ltr:right-0 p-2 text-white">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
            </button>
            
            <div className="relative group">
              <img 
                src={targetUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${targetUser.Id_user}`} 
                className="w-full aspect-square object-cover rounded-[3rem] shadow-2xl border-4 border-white/10" 
                alt={targetUser.UserData}
              />
              
              {isOwnProfile && (
                <button 
                  onClick={() => setShowPhotoMenu(!showPhotoMenu)}
                  className="absolute top-6 rtl:left-6 ltr:right-6 p-3 bg-black/60 rounded-2xl text-white hover:bg-black/80 transition-all"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 5v.01M12 12v.01M12 19v.01" strokeWidth={3}/></svg>
                </button>
              )}

              {showPhotoMenu && isOwnProfile && (
                <div className="absolute top-20 rtl:left-6 ltr:right-6 bg-slate-900 border border-white/10 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in slide-in-from-top-2 w-48">
                  <button 
                    onClick={() => handlePhotoAction('change')}
                    disabled={isUploading}
                    className="w-full px-6 py-4 rtl:text-right ltr:text-left text-xs font-bold text-white hover:bg-white/5 flex items-center justify-between space-x-4 space-x-reverse"
                  >
                    <span>{t('profile.changePhoto')}</span>
                    <svg className="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth={2}/></svg>
                  </button>
                  {targetUser.photoURL && !targetUser.photoURL.includes('dicebear.com') && (
                    <button 
                      onClick={() => handlePhotoAction('delete')}
                      className="w-full px-6 py-4 rtl:text-right ltr:text-left text-xs font-bold text-red-500 hover:bg-red-500/10 flex items-center justify-between space-x-4 space-x-reverse border-t border-white/5"
                    >
                      <span>{t('profile.deletePhoto')}</span>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth={2}/></svg>
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Friends Modal */}
      {showFriendsModal && (
        <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="w-full max-w-sm glass bg-slate-900 border border-white/10 rounded-[2.5rem] flex flex-col max-h-[70vh] overflow-hidden">
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <h3 className="text-sm font-black uppercase tracking-widest text-blue-500">
                {targetUser.accountType === 'page' ? t('profile.followersTitle') : t('profile.friendsTitle')}
              </h3>
              <button onClick={() => setShowFriendsModal(false)} className="p-2 text-slate-500 hover:text-white">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
              {(targetUser.accountType === 'page' ? targetUser.followersList : targetUser.friendsList)?.length === 0 ? (
                <p className="text-center py-10 text-[10px] font-bold text-slate-600 uppercase">{t('profile.nobodyHere')}</p>
              ) : (
                (targetUser.accountType === 'page' ? targetUser.followersList : targetUser.friendsList)?.map((uid: string) => (
                  <div key={uid} className="flex items-center p-3 bg-white/5 rounded-2xl border border-white/5">
                    <img src={`https://api.dicebear.com/7.x/bottts/svg?seed=${uid}`} className="w-10 h-10 rounded-xl border border-white/10" alt={uid} />
                    <div className="rtl:mr-3 ltr:ml-3 flex-1 rtl:text-right ltr:text-left">
                      <p className="text-xs font-black text-white">{uid}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
      <ImageCropperModal
        file={pendingCropFile}
        title="تحديد جزء صورة البروفايل (1:1)"
        onCancel={() => setPendingCropFile(null)}
        onConfirm={uploadCroppedProfilePhoto}
      />
    </div>
  );
};

export default ProfileView;
