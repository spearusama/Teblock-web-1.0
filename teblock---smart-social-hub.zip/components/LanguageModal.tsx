import React, { useState } from 'react';
import { SUPPORTED_LANGUAGES, LanguageCode, useLanguage, LanguageInfo } from '../utils/i18n';

interface LanguageModalProps {
  onClose: () => void;
}

export const LanguageModal: React.FC<LanguageModalProps> = ({ onClose }) => {
  const { currentLang, setLanguage, t, isRtl, dir } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [showToast, setShowToast] = useState(false);

  const filteredLanguages = SUPPORTED_LANGUAGES.filter(lang => {
    const term = searchTerm.toLowerCase().trim();
    if (!term) return true;
    return (
      lang.name.toLowerCase().includes(term) ||
      lang.nativeName.toLowerCase().includes(term) ||
      lang.region.toLowerCase().includes(term) ||
      lang.code.toLowerCase().includes(term)
    );
  });

  const handleSelectLanguage = (langCode: LanguageCode) => {
    setLanguage(langCode);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
      onClose();
    }, 450);
  };

  return (
    <div dir={dir} className="fixed inset-0 z-[600] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-300">
      <div 
        className="w-full max-w-xl glass rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-white/5 bg-slate-900/50 backdrop-blur-xl flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center text-xl shadow-lg border border-blue-500/20">
              🌐
            </div>
            <div className="rtl:text-right ltr:text-left">
              <h2 className="text-base font-black text-white">{t('lang.title')}</h2>
              <p className="text-[11px] text-slate-400 font-bold">{t('lang.subtitle')}</p>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-white/5 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>

        {/* Search Input */}
        <div className="p-4 border-b border-white/5 bg-black/20">
          <div className="relative">
            <input 
              type="text" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t('lang.searchPlaceholder')}
              className="w-full bg-slate-900/80 border border-white/10 rounded-2xl py-3 rtl:pr-10 rtl:pl-10 ltr:pl-10 ltr:pr-10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all font-bold rtl:text-right ltr:text-left"
            />
            <svg className="w-4 h-4 text-slate-500 absolute top-3.5 rtl:right-3.5 ltr:left-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')} 
                className="absolute top-3.5 rtl:left-3.5 ltr:right-3.5 text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Languages Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar space-y-2.5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filteredLanguages.map((lang: LanguageInfo) => {
              const isSelected = currentLang === lang.code;
              return (
                <button
                  key={lang.code}
                  onClick={() => handleSelectLanguage(lang.code)}
                  className={`w-full p-4 rounded-2xl border transition-all rtl:text-right ltr:text-left flex items-center justify-between group relative overflow-hidden ${
                    isSelected 
                      ? 'bg-blue-600/20 border-blue-500 shadow-xl shadow-blue-500/20 text-white' 
                      : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/10 text-slate-300'
                  }`}
                >
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <span className="text-2xl transform group-hover:scale-125 transition-transform">
                      {lang.flag}
                    </span>
                    <div className="rtl:text-right ltr:text-left">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span className="font-black text-sm text-white">{lang.nativeName}</span>
                        {lang.name !== lang.nativeName && (
                          <span className="text-[10px] text-slate-400">({lang.name})</span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-500 font-bold block mt-0.5">
                        {lang.region}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 space-x-reverse">
                    <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      lang.dir === 'rtl' 
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' 
                        : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                    }`}>
                      {lang.dir === 'rtl' ? 'RTL' : 'LTR'}
                    </span>
                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs shadow-md">
                        ✓
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {filteredLanguages.length === 0 && (
            <div className="text-center py-12 text-slate-500 text-xs font-bold">
              {t('common.cancel')}
            </div>
          )}
        </div>

        {/* Footer Hint */}
        <div className="p-4 border-t border-white/5 bg-slate-900/60 backdrop-blur-xl flex items-center justify-between text-[11px] text-slate-400 font-bold">
          <div className="flex items-center space-x-2 space-x-reverse">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-[10px]">{t('lang.subtitle')}</span>
          </div>
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-white font-black text-xs transition-colors"
          >
            {t('common.close')}
          </button>
        </div>
      </div>

      {showToast && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[700] bg-emerald-600 text-white px-6 py-3 rounded-2xl shadow-2xl font-black text-xs flex items-center space-x-2 space-x-reverse animate-in fade-in slide-in-from-bottom duration-200">
          <span>✓</span>
          <span>{t('lang.switchSuccess')}</span>
        </div>
      )}
    </div>
  );
};

export default LanguageModal;
