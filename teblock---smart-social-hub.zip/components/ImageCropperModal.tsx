import React, { useState, useRef, useEffect } from 'react';

interface ImageCropperModalProps {
  file: File | null;
  title?: string;
  onCancel: () => void;
  onConfirm: (croppedFile: File) => void;
}

const CROP_BOX_SIZE = 280;
const OUTPUT_SIZE = 640;

export const ImageCropperModal: React.FC<ImageCropperModalProps> = ({
  file,
  title = 'قص الصورة (1:1)',
  onCancel,
  onConfirm,
}) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [naturalSize, setNaturalSize] = useState<{ w: number; h: number }>({ w: 0, h: 0 });
  const [zoom, setZoom] = useState<number>(1);
  const [offset, setOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ x: number; y: number; ox: number; oy: number }>({ x: 0, y: 0, ox: 0, oy: 0 });
  const imgRef = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    if (!file) {
      setImageUrl(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setImageUrl(url);
    setZoom(1);
    setOffset({ x: 0, y: 0 });
    return () => URL.revokeObjectURL(url);
  }, [file]);

  if (!file || !imageUrl) return null;

  // Base scale so the shorter side fills CROP_BOX_SIZE completely
  const baseScale =
    naturalSize.w > 0 && naturalSize.h > 0
      ? Math.max(CROP_BOX_SIZE / naturalSize.w, CROP_BOX_SIZE / naturalSize.h)
      : 1;

  const displayW = naturalSize.w * baseScale * zoom;
  const displayH = naturalSize.h * baseScale * zoom;

  const clampOffset = (nx: number, ny: number, z: number) => {
    const w = naturalSize.w * baseScale * z;
    const h = naturalSize.h * baseScale * z;
    const maxX = Math.max(0, (w - CROP_BOX_SIZE) / 2);
    const maxY = Math.max(0, (h - CROP_BOX_SIZE) / 2);
    return {
      x: Math.max(-maxX, Math.min(maxX, nx)),
      y: Math.max(-maxY, Math.min(maxY, ny)),
    };
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setIsDragging(true);
    dragStartRef.current = { x: e.clientX, y: e.clientY, ox: offset.x, oy: offset.y };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    setOffset(clampOffset(dragStartRef.current.ox + dx, dragStartRef.current.oy + dy, zoom));
  };

  const handlePointerUp = () => {
    setIsDragging(false);
  };

  const handleZoomChange = (newZoom: number) => {
    setZoom(newZoom);
    setOffset(prev => clampOffset(prev.x, prev.y, newZoom));
  };

  const handleConfirmCrop = () => {
    const img = imgRef.current;
    if (!img || naturalSize.w === 0 || naturalSize.h === 0) return;

    const canvas = document.createElement('canvas');
    canvas.width = OUTPUT_SIZE;
    canvas.height = OUTPUT_SIZE;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Top-left of the image relative to the crop box top-left
    const imgLeft = (CROP_BOX_SIZE - displayW) / 2 + offset.x;
    const imgTop = (CROP_BOX_SIZE - displayH) / 2 + offset.y;

    const totalScale = baseScale * zoom;
    const sx = -imgLeft / totalScale;
    const sy = -imgTop / totalScale;
    const sSize = CROP_BOX_SIZE / totalScale;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, OUTPUT_SIZE, OUTPUT_SIZE);
    ctx.drawImage(img, sx, sy, sSize, sSize, 0, 0, OUTPUT_SIZE, OUTPUT_SIZE);

    canvas.toBlob(
      (blob) => {
        if (!blob) return;
        const cropped = new File([blob], file.name.replace(/\.[^.]+$/, '') + '_square.jpg', {
          type: 'image/jpeg',
          lastModified: Date.now(),
        });
        onConfirm(cropped);
      },
      'image/jpeg',
      0.92
    );
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-[1200] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onCancel}
    >
      <div
        className="w-full max-w-sm bg-slate-900 border border-white/15 rounded-3xl p-5 shadow-2xl flex flex-col items-center gap-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-full flex items-center justify-between">
          <div>
            <h3 className="text-sm font-black text-white">{title}</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">اسحب الصورة لتحديد الجزء المناسب داخل الإطار المربع</p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* 1:1 Square Crop Area */}
        <div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          style={{ width: CROP_BOX_SIZE, height: CROP_BOX_SIZE, touchAction: 'none' }}
          className="relative overflow-hidden rounded-2xl border-2 border-blue-500 bg-black select-none cursor-grab active:cursor-grabbing shadow-inner"
        >
          <img
            ref={imgRef}
            src={imageUrl}
            alt="Crop preview"
            draggable={false}
            onLoad={(e) => {
              const el = e.currentTarget;
              setNaturalSize({ w: el.naturalWidth, h: el.naturalHeight });
            }}
            style={{
              width: displayW || '100%',
              height: displayH || '100%',
              left: '50%',
              top: '50%',
              transform: `translate(calc(-50% + ${offset.x}px), calc(-50% + ${offset.y}px))`,
            }}
            className="absolute max-w-none pointer-events-none select-none"
          />

          {/* 3x3 Grid Overlay */}
          <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3">
            <div className="border-b border-l border-white/20" />
            <div className="border-b border-l border-white/20" />
            <div className="border-b border-white/20" />
            <div className="border-b border-l border-white/20" />
            <div className="border-b border-l border-white/20" />
            <div className="border-b border-white/20" />
            <div className="border-l border-white/20" />
            <div className="border-l border-white/20" />
            <div />
          </div>

          <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded-md text-[10px] font-black text-blue-300 pointer-events-none">
            1:1
          </div>
        </div>

        {/* Zoom Control */}
        <div className="w-full flex items-center gap-3 px-1">
          <span className="text-[11px] font-bold text-slate-400 shrink-0">تكبير</span>
          <input
            type="range"
            min={1}
            max={3}
            step={0.05}
            value={zoom}
            onChange={(e) => handleZoomChange(parseFloat(e.target.value))}
            className="flex-1 accent-blue-500 cursor-pointer"
          />
          <span className="text-[11px] font-mono font-bold text-blue-400 w-10 text-left">
            {zoom.toFixed(1)}x
          </span>
        </div>

        {/* Actions */}
        <div className="w-full flex gap-2.5 pt-1">
          <button
            type="button"
            onClick={handleConfirmCrop}
            className="flex-1 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-black text-xs shadow-lg shadow-blue-600/30 transition-all active:scale-95"
          >
            تأكيد وحفظ الصورة
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs transition-all"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImageCropperModal;
