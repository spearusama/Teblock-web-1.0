import { AdminReportsView } from './AdminReportsView';
import { MenuView } from './MenuView';

import React, { useState, useEffect, useRef } from 'react';
import { User, Notification } from '../types';
import AIChatView from './AIChatView';
import ReelsView from './ReelsView';
import PublishModal from './PublishModal';
import NotificationsView from './NotificationsView';
import SearchView from './SearchView';
import ProfileView from './ProfileView';
import AccountSettingsView from './AccountSettingsView';
import DebugView from './DebugView';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, where, onSnapshot, limit } from 'firebase/firestore';
import { reelsManager } from '../utils/reelsManager';

import SettingsPopover from './SettingsPopover';
import { EmojiStyleModal } from './EmojiStyleModal';
import P2PCallModal from './P2PCallModal';
import { p2pCallManager, P2PCallSession } from '../utils/p2pCallService';
import LanguageModal from './LanguageModal';
import { useLanguage } from '../utils/i18n';
import { requestDeviceNotificationPermission, showDeviceNotification } from '../utils/deviceNotifications';

interface VoiceParticipant {
  name: string;
  photo: string;
  isSpeaking: boolean;
}

interface ChatContainerProps {
  user: User;
  onLogout: () => void;
  onSwitchAccount: (userId: string) => void;
}

const ChatContainer: React.FC<ChatContainerProps> = ({ user, onLogout, onSwitchAccount }) => {
  const [currentView, setCurrentView] = useState<'chats' | 'reels' | 'notifications' | 'search' | 'profile' | 'settings' | 'menu' | 'admin_reports'>(() => {
    const path = window.location.pathname;
    if (path.startsWith('/notifications')) return 'notifications';
    if (path.startsWith('/search')) return 'search';
    if (path.startsWith('/reel')) return 'reels';
    if (path.startsWith('/profile') || path.startsWith('/user/')) return 'profile';
    if (path.startsWith('/settings')) return 'settings';
    return 'chats';
  });
  const { t, isRtl, dir, langInfo } = useLanguage();
  const [showPublish, setShowPublish] = useState(false);
  const [showSettingsPopover, setShowSettingsPopover] = useState(false);
  const [showEmojiStyleModal, setShowEmojiStyleModal] = useState(false);
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  const [theme, setTheme] = useState(localStorage.getItem('teblock_theme') || 'deepblue');
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [jumpToChat, setJumpToChat] = useState<any>(() => {
    const path = window.location.pathname;
    if (path.startsWith('/chats/') && path.length > 7) {
      const id = path.split('/')[2];
      if (id) return { id, isGroup: false };
    }
    return null;
  });
  const [jumpToReelId, setJumpToReelId] = useState<string | null>(() => {
    const path = window.location.pathname;
    if (path.startsWith('/reel/') && path.length > 6) {
      return path.split('/')[2];
    }
    return null;
  });
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(() => {
    const path = window.location.pathname;
    if (path.startsWith('/user/') && path.length > 6) {
      return path.split('/')[2] || null;
    }
    if (path.startsWith('/profile/') && path.length > 9) {
      return path.split('/')[2] || null;
    }
    if (path.startsWith('/profile') || path.startsWith('/user/')) {
      return user['id-2'] || user.Id_user;
    }
    return null;
  });

  // Sync URL when currentView changes
  useEffect(() => {
    let newPath = '/chats';
    if (currentView === 'notifications') newPath = '/notifications';
    else if (currentView === 'search') {
      const currentPath = window.location.pathname;
      newPath = currentPath.startsWith('/search') ? currentPath : '/search';
    }
    else if (currentView === 'reels') {
      newPath = jumpToReelId ? `/reel/${jumpToReelId}` : '/reel';
    }
    else if (currentView === 'chats') {
      newPath = jumpToChat?.id ? `/chats/${jumpToChat.id}` : '/chats';
    }
    else if (currentView === 'profile') {
      const pId = selectedProfileId || user['id-2'] || user.Id_user;
      newPath = `/user/${pId}`;
    }
    else if (currentView === 'settings') {
      newPath = '/settings';
    }
    else if (currentView === 'menu') {
      newPath = '/menu';
    }
    
    if (window.location.pathname !== newPath) {
      window.history.pushState(null, '', newPath);
    }
  }, [currentView, jumpToChat, jumpToReelId, selectedProfileId, user]);

  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      if (path.startsWith('/notifications')) setCurrentView('notifications');
      else if (path.startsWith('/search')) setCurrentView('search');
      else if (path.startsWith('/settings')) setCurrentView('settings');
      else if (path.startsWith('/menu')) setCurrentView('menu');
      else if (path.startsWith('/profile') || path.startsWith('/user/')) {
        setCurrentView('profile');
        const id = path.split('/')[2];
        setSelectedProfileId(id || user['id-2'] || user.Id_user);
      }
      else if (path.startsWith('/reel')) {
        setCurrentView('reels');
        const id = path.split('/')[2];
        if (id) setJumpToReelId(id);
      }
      else if (path.startsWith('/chats')) {
        setCurrentView('chats');
        const id = path.split('/')[2];
        if (id) {
           setJumpToChat({ id, isGroup: false });
        } else {
           setJumpToChat(null);
        }
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [user]);

  useEffect(() => {
    // Eagerly preload reels and top video into browser memory/cache
    // so entering Reels view is instantaneous with zero waiting
    const timer = setTimeout(() => {
      reelsManager.preloadBeforeEntering(user.Id_user);
    }, 600);
    return () => clearTimeout(timer);
  }, [user.Id_user]);

  const [showDebug, setShowDebug] = useState(false);
  const [isNavHidden, setIsNavHidden] = useState(false);
  const [activeCalls, setActiveCalls] = useState<Record<string, Record<string, VoiceParticipant>>>({});
  const [onlineUsers, setOnlineUsers] = useState<Record<string, { lastSeen: string, status: string }>>({});
  const [typingStates, setTypingStates] = useState<Record<string, { targetId: string, type: 'typing' | 'recording' | null }>>({});
  const [incomingCall, setIncomingCall] = useState<P2PCallSession | null>(null);
  const [activeCallSession, setActiveCallSession] = useState<P2PCallSession | null>(null);
  const socketRef = useRef<WebSocket | null>(null);

  // طلب إذن إشعارات الجهاز عند الدخول
  useEffect(() => {
    requestDeviceNotificationPermission();
  }, []);

  // إشعارات الجهاز للرسائل الجديدة الواردة
  const notifiedMsgIdsRef = useRef<Set<string>>(new Set());
  const initialMsgLoadRef = useRef<boolean>(true);
  useEffect(() => {
    const q = query(
      collection(db, 'messages'),
      where('receiverId', '==', user.Id_user),
      where('read', '==', false),
      limit(20)
    );
    const unsub = onSnapshot(q, (snap) => {
      if (initialMsgLoadRef.current) {
        snap.docs.forEach(d => notifiedMsgIdsRef.current.add(d.id));
        initialMsgLoadRef.current = false;
        return;
      }
      snap.docChanges().forEach((change) => {
        if (change.type === 'added' && !notifiedMsgIdsRef.current.has(change.doc.id)) {
          notifiedMsgIdsRef.current.add(change.doc.id);
          const data = change.doc.data() as any;
          if (data.senderId && data.senderId !== user.Id_user && !user.blockedUsers?.includes(data.senderId)) {
            showDeviceNotification(
              `رسالة جديدة من ${data.senderName || 'مستخدم'}`,
              data.isVoice ? '🎤 رسالة صوتية' : (data.imageUrl ? '📷 صورة جديدة' : 'وصلك رسالة جديدة في Teblock'),
              {
                icon: data.senderPhoto || undefined,
                tag: `msg_${data.senderId}`,
                onClick: () => {
                  setJumpToChat({ id: data.senderId, name: data.senderName, photo: data.senderPhoto, isGroup: false });
                  setCurrentView('chats');
                }
              }
            );
          }
        }
      });
    });
    return unsub;
  }, [user.Id_user, user.blockedUsers]);

  // استماع للمكالمات الصوتية الواردة عبر قاعدة البيانات (Firestore)
  useEffect(() => {
    const q = query(
      collection(db, 'calls'),
      where('receiverId', '==', user.Id_user),
      where('status', '==', 'ringing')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const docData = snapshot.docs[0].data() as P2PCallSession;
        setIncomingCall(docData);
        showDeviceNotification(
          `مكالمة صوتية واردة`,
          `${docData.callerName} يتصل بك الآن...`,
          {
            icon: docData.callerPhoto || undefined,
            tag: `call_${docData.callId}`
          }
        );
      } else {
        setIncomingCall(null);
      }
    });

    p2pCallManager.setCallbacks({
      onSessionUpdate: (session) => {
        setActiveCallSession(session);
      },
      onCallEnded: () => {
        setActiveCallSession(null);
        setIncomingCall(null);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [user.Id_user]);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socket = new WebSocket(`${protocol}//${window.location.host}`);
    socketRef.current = socket;

    socket.onopen = () => {
      socket.send(JSON.stringify({ 
        type: 'auth', 
        userId: user.Id_user,
        userName: user.UserData,
        userPhoto: user.photoURL
      }));
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'sync') {
        setOnlineUsers(data.onlineUsers);
        setTypingStates(data.typingStates);
        setActiveCalls(data.activeCalls);
      }
    };

    return () => {
      socket.close();
    };
  }, [user.Id_user]);

  const isUserInAnyCall = !!activeCallSession || Object.values(activeCalls).some(participants => !!participants[user.Id_user]);

  const [reelOpenedFromChat, setReelOpenedFromChat] = useState(false);

  useEffect(() => {
    (window as any).navigateToReel = (rid: string, fromChat?: boolean) => {
      setJumpToReelId(rid);
      setReelOpenedFromChat(!!fromChat);
      setCurrentView('reels');
    };
    return () => { delete (window as any).navigateToReel; };
  }, []);

  useEffect(() => {
    document.body.className = `${dir} theme-${theme}`;
    localStorage.setItem('teblock_theme', theme);
  }, [theme, dir]);

  useEffect(() => {
    const myIds = Array.from(new Set([user['id-2'], user.Id_user].filter(Boolean) as string[]));
    const q = query(collection(db, 'notifications'), where('toId', 'in', myIds), where('read', '==', false), limit(50));
    return onSnapshot(q, (snap) => {
      setUnreadNotifications(snap.size);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'notifications');
    });
  }, [user.Id_user, user['id-2']]);

  const handleNavigateToProfile = (userId: string) => {
    setSelectedProfileId(userId);
    setCurrentView('profile');
  };

  const renderView = () => {
    if (currentView === 'profile') {
      const targetId = selectedProfileId || user['id-2'] || user.Id_user;
      return (
        <ProfileView 
          currentUser={user} 
          targetUserId={targetId} 
          onBack={() => { setCurrentView('chats'); setSelectedProfileId(null); }} 
          onNavigateToReels={(rid) => {
            setJumpToReelId(rid);
            setCurrentView('reels');
          }}
          onNavigateToChat={(chat) => {
            setJumpToChat(chat);
            setCurrentView('chats');
          }}
          onNavigateSettings={() => {
            setCurrentView('settings');
          }}
        />
      );
    }
    if (currentView === 'settings') {
      return (
        <AccountSettingsView 
          user={user}
          onBack={() => setCurrentView('chats')}
          onLogout={onLogout}
        />
      );
    }
    if (currentView === 'admin_reports') {
      return (
        <AdminReportsView 
          onBack={() => setCurrentView('chats')}
        />
      );
    }
    if (currentView === 'menu') {
      return (
        <MenuView 
          user={user}
          onNavigate={(view) => {
            if (view === 'developer_zone') {
              setShowDebug(true);
            } else if (view === 'language') {
              setShowLanguageModal(true);
            } else {
              setCurrentView(view as any);
            }
          }}
          onBack={() => setCurrentView('chats')}
        />
      );
    }
    switch(currentView) {
      case 'reels': return (
        <ReelsView
          user={user}
          jumpToReelId={jumpToReelId}
          showBackButton={reelOpenedFromChat}
          onNavigateProfile={handleNavigateToProfile}
          onBack={() => {
            setReelOpenedFromChat(false);
            setJumpToReelId(null);
            setCurrentView('chats');
          }}
        />
      );
      case 'chats': return (
        <AIChatView 
          user={user} 
          initialChat={jumpToChat} 
          onClearJump={() => setJumpToChat(null)} 
          onModeChange={(mode) => {
            if (mode === ('search' as any)) {
              setCurrentView('search');
            } else {
              setIsNavHidden(mode === 'activeChat' || mode === 'voiceCall');
            }
          }} 
          onNavigateProfile={handleNavigateToProfile}
          externalSocket={socketRef.current}
          externalActiveCalls={activeCalls}
          externalOnlineUsers={onlineUsers}
          externalTypingStates={typingStates}
        />
      );
      case 'notifications': return (
        <NotificationsView 
          user={user} 
          onNavigateToChat={(f) => { setJumpToChat({...f, isAI: false, isGroup: false}); setCurrentView('chats'); }} 
          onNavigateProfile={handleNavigateToProfile}
          onNavigateToReel={(rid) => {
            setJumpToReelId(rid);
            setCurrentView('reels');
          }}
        />
      );
      case 'search': return (
        <SearchView 
          user={user} 
          onNavigateProfile={handleNavigateToProfile}
          onNavigateChat={(chat) => {
            setJumpToChat(chat);
            setCurrentView('chats');
          }}
        />
      );
      default: return <AIChatView user={user} onModeChange={(mode) => setIsNavHidden(mode === 'activeChat')} onNavigateProfile={handleNavigateToProfile} />;
    }
  };

  return (
    <div dir={dir} className="fixed inset-0 flex flex-col w-full bg-[var(--teblock-bg)] text-[var(--teblock-text)] overflow-hidden select-none">
      
      {/* Header with Desktop Navigation and Mobile Controls - Compact and uncluttered */}
      <header className="h-13 sm:h-14 flex items-center justify-between px-3 sm:px-5 glass border-b border-[var(--teblock-border)] z-[100] shrink-0 transition-all duration-300">
         <div className="flex items-center space-x-2.5 space-x-reverse">
            <h1 
              className={`text-lg sm:text-xl font-black tracking-tighter uppercase cursor-pointer transition-all duration-300 hover:scale-105 active:scale-95 flex items-center ${isUserInAnyCall ? 'text-green-500' : 'text-blue-500'}`} 
              onClick={() => setCurrentView('chats')}
            >
              <span className="bg-gradient-to-r from-blue-500 via-indigo-400 to-blue-600 bg-clip-text text-transparent">TEBLOCK</span>
            </h1>
            
            <div className="hidden sm:flex items-center space-x-1 space-x-reverse">
              <span className={`w-1.5 h-1.5 rounded-full ${isUserInAnyCall ? 'bg-green-500 animate-ping' : 'bg-blue-500/80 animate-pulse'}`}></span>
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                {isUserInAnyCall ? t('call.voiceCall') : t('common.smartPlatform')}
              </span>
            </div>
         </div>

         {/* Desktop Navigation Bar (Screens >= md) - Compact */}
         <nav className="hidden md:flex items-center space-x-1 space-x-reverse bg-black/40 border border-white/10 rounded-xl p-0.5 shadow-inner">
           <button
             onClick={() => { setCurrentView('chats'); setJumpToReelId(null); }}
             className={`flex items-center space-x-1.5 space-x-reverse px-3 py-1.5 rounded-lg text-[11px] font-black transition-all ${
               currentView === 'chats' 
                 ? 'bg-blue-600 text-white shadow-sm' 
                 : 'text-slate-400 hover:text-white hover:bg-white/5'
             }`}
           >
             <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" strokeWidth={2.5}/></svg>
             <span>{t('nav.chats')}</span>
           </button>

           <button
             onClick={() => { setCurrentView('search'); setJumpToReelId(null); }}
             className={`flex items-center space-x-1.5 space-x-reverse px-3 py-1.5 rounded-lg text-[11px] font-black transition-all ${
               currentView === 'search' 
                 ? 'bg-blue-600 text-white shadow-sm' 
                 : 'text-slate-400 hover:text-white hover:bg-white/5'
             }`}
           >
             <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" strokeWidth={2.5}/></svg>
             <span>{t('nav.search')}</span>
           </button>

           <button
             onClick={() => { setCurrentView('reels'); setJumpToReelId(null); }}
             className={`flex items-center space-x-1.5 space-x-reverse px-3 py-1.5 rounded-lg text-[11px] font-black transition-all ${
               currentView === 'reels' 
                 ? 'bg-blue-600 text-white shadow-sm' 
                 : 'text-slate-400 hover:text-white hover:bg-white/5'
             }`}
           >
             <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2-2v8a2 2 0 002 2z" strokeWidth={2.5}/></svg>
             <span>{t('nav.reels')}</span>
           </button>

           <button
             onClick={() => setShowPublish(true)}
             className="flex items-center px-2.5 py-1.5 rounded-lg text-[11px] font-black bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white border border-blue-500/30 transition-all active:scale-95"
           >
             <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={3}/></svg>
           </button>

           <button
             onClick={() => { setCurrentView('menu'); setJumpToReelId(null); }}
             className={`flex items-center space-x-1.5 space-x-reverse px-3 py-1.5 rounded-lg text-[11px] font-black transition-all ${
               currentView === 'menu' 
                 ? 'bg-blue-600 text-white shadow-sm' 
                 : 'text-slate-400 hover:text-white hover:bg-white/5'
             }`}
           >
             <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" strokeWidth={2.5}/></svg>
             <span>{t('nav.menu')}</span>
           </button>
         </nav>

         {/* User & Popover Area - Compact */}
         <div className="flex items-center space-x-1.5 sm:space-x-2 space-x-reverse relative">
            <button
              onClick={() => setShowLanguageModal(true)}
              className="p-1.5 sm:px-2.5 py-1 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-all flex items-center space-x-1 space-x-reverse border border-white/5 text-[10px]"
              title={t('lang.title')}
            >
              <span className="text-sm sm:text-base">{langInfo.flag}</span>
              <span className="hidden sm:inline font-bold">{langInfo.nativeName}</span>
            </button>

            <button 
              onClick={() => setCurrentView('notifications')} 
              className="relative p-1.5 sm:p-2 text-slate-400 hover:text-blue-500 hover:bg-white/5 rounded-xl transition-all"
              title={t('nav.notifications')}
            >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" strokeWidth={2}/></svg>
                {unreadNotifications > 0 && (
                  <span className="absolute top-1 right-1 w-3.5 h-3.5 bg-red-600 rounded-full text-[7px] flex items-center justify-center text-white border-2 border-[var(--teblock-bg)] font-black animate-pulse">
                    {unreadNotifications}
                  </span>
                )}
            </button>
            
            <button 
              onClick={() => setShowSettingsPopover(!showSettingsPopover)} 
              className={`w-8 h-8 sm:w-8.5 sm:h-8.5 rounded-xl border-2 overflow-hidden bg-slate-800 shadow-md transition-all active:scale-90 ${showSettingsPopover ? 'border-blue-500 scale-105' : 'border-blue-500/30 hover:border-blue-500/60'}`}
              title={`${t('nav.profile')} & ${t('nav.settings')}`}
            >
                <img src={user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.Id_user}`} alt="Avatar" className="w-full h-full object-cover" />
            </button>

            {showSettingsPopover && (
              <SettingsPopover 
                user={user}
                theme={theme}
                onThemeChange={setTheme}
                onLogout={onLogout}
                onNavigateProfile={handleNavigateToProfile}
                onClose={() => setShowSettingsPopover(false)}
                onSwitchAccount={onSwitchAccount}
                onNavigateSettings={() => {
                  setCurrentView('settings');
                  setShowSettingsPopover(false);
                }}
                onNavigateSavedReels={() => {
                  setCurrentView('reels');
                  setJumpToReelId('SAVED_REELS'); 
                }}
                onShowDebug={() => setShowDebug(true)}
                onOpenEmojiStyle={() => setShowEmojiStyleModal(true)}
                onOpenLanguageModal={() => setShowLanguageModal(true)}
              />
            )}
         </div>
      </header>

      {/* Main View Area with Ambient Lighting & Smooth Transition */}
      <main className="flex-1 min-h-0 relative overflow-hidden flex flex-col bg-black/90">
         {/* Subtle ambient lighting for high-end modern feel */}
         <div className="absolute -top-32 -left-32 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none ambient-orb" />
         <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none ambient-orb" />

         <div key={currentView} className="page-transition w-full h-full flex flex-col flex-1 min-h-0 relative overflow-hidden">
           {renderView()}
         </div>
      </main>

      {/* Mobile Bottom Navigation Bar (Hidden on desktop md:) - Compact and modern */}
      {!isNavHidden && (
        <nav className="h-13 sm:h-14 glass border-t border-white/5 flex md:hidden items-center justify-around px-2 sm:px-4 z-[120] animate-in fade-in slide-in-from-bottom duration-300 shrink-0">
           <button 
             onClick={() => { setCurrentView('chats'); setJumpToReelId(null); }} 
             className={`p-2 transition-all ${currentView === 'chats' ? 'text-blue-500 scale-105' : 'text-slate-500 opacity-60 hover:opacity-100'}`}
             title={t('nav.chats')}
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" strokeWidth={2.2}/></svg>
           </button>
           
           <button 
             onClick={() => { setCurrentView('search'); setJumpToReelId(null); }} 
             className={`p-2 transition-all ${currentView === 'search' ? 'text-blue-500 scale-105' : 'text-slate-500 opacity-60 hover:opacity-100'}`}
             title={t('nav.search')}
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" strokeWidth={2.2}/></svg>
           </button>

           <button 
              onClick={() => setShowPublish(true)} 
              className="w-10 h-10 sm:w-11 sm:h-11 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-600/30 -mt-5 border-2 border-[var(--teblock-bg)] hover:scale-105 active:scale-95 transition-all z-[130]"
              title="+"
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={3}/></svg>
           </button>

           <button 
             onClick={() => { setCurrentView('reels'); setJumpToReelId(null); }} 
             className={`p-2 transition-all ${currentView === 'reels' ? 'text-blue-500 scale-105' : 'text-slate-500 opacity-60 hover:opacity-100'}`}
             title={t('nav.reels')}
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2-2v8a2 2 0 002 2z" strokeWidth={2.2}/></svg>
           </button>

           <button 
             onClick={() => { setCurrentView('menu'); setJumpToReelId(null); }} 
             className={`p-2 transition-all ${currentView === 'menu' ? 'text-blue-500 scale-105' : 'text-slate-500 opacity-60 hover:opacity-100'}`}
             title={t('nav.menu')}
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" strokeWidth={2.2}/></svg>
           </button>
        </nav>
      )}

      {showPublish && <PublishModal user={user} onClose={() => setShowPublish(false)} />}
      {showDebug && <DebugView onClose={() => setShowDebug(false)} />}
      {showEmojiStyleModal && <EmojiStyleModal onClose={() => setShowEmojiStyleModal(false)} />}
      {showLanguageModal && <LanguageModal onClose={() => setShowLanguageModal(false)} />}

      {/* مشغل المكالمات الصوتية المباشرة P2P مع حفظ وإسقاط الآيبي المؤقت */}
      <P2PCallModal
        user={user}
        incomingCall={incomingCall}
        activeSession={activeCallSession}
        onAcceptIncoming={async (callId) => {
          try {
            await p2pCallManager.answerCall(callId, user);
          } catch (err: any) {
            alert(err.message || t('call.callEnded'));
          }
        }}
        onRejectIncoming={async () => {
          await p2pCallManager.endCall();
          setIncomingCall(null);
        }}
        onEndActiveCall={async () => {
          await p2pCallManager.endCall();
          setActiveCallSession(null);
        }}
      />
      
    </div>
  );
};

export default ChatContainer;
