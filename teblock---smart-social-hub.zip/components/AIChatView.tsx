
import React, { useState, useRef, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { User, Message, Group } from '../types';
import { db } from '../firebase';
import { useLanguage } from '../utils/i18n';
import { getSmartResponse } from '../geminiService';
import NotesSystem from './NotesSystem';
import { encryptText, decryptText } from "../utils/crypto";
import { soundManager } from "../utils/audio";
import { EMOJI_CATEGORIES } from '../constants/emojis';
import { EmojiImg, renderEmojiText, useEmojiStyle, setStoredEmojiStyle, EMOJI_STYLES } from '../utils/emoji';
import { EmojiStyleModal } from './EmojiStyleModal';
import { p2pCallManager, P2PCallSession } from '../utils/p2pCallService';
import P2PCallModal from './P2PCallModal';
import ImageCropperModal from './ImageCropperModal';
import { 
  collection, addDoc, query, onSnapshot, serverTimestamp, 
  where, doc, or, updateDoc, deleteDoc, orderBy, limit, arrayUnion, arrayRemove, setDoc, getDocs, getDoc, deleteField
} from 'firebase/firestore';

interface AIChatViewProps {
  user: User;
  initialChat?: any;
  onClearJump?: () => void;
  onModeChange?: (mode: ChatMode) => void;
  onNavigateProfile?: (userId: string) => void;
  externalSocket?: WebSocket | null;
  externalActiveCalls?: Record<string, Record<string, VoiceParticipant>>;
  externalOnlineUsers?: Record<string, { lastSeen: string, status: string }>;
  externalTypingStates?: Record<string, { targetId: string, type: 'typing' | 'recording' | null }>;
}

type ChatMode = 'inbox' | 'friends' | 'activeChat' | 'createGroup' | 'chatSettings' | 'themePicker' | 'quickEmojiPicker' | 'nicknamePicker' | 'groupMembers' | 'voiceCall' | 'inboxSearch' | 'addMember' | 'pinnedMessages';

interface VoiceParticipant {
  photo: string;
  name: string;
  isSpeaking: boolean;
}

interface ChatPreview {
  id: string;
  name: string;
  photo: string;
  lastMessage: string;
  timestamp: any;
  unreadCount: number;
  isGroup: boolean;
  isAI?: boolean;
  manualUnread?: boolean;
  isTagged?: boolean;
  admins?: string[];
  members?: string[];
}

const CLOUD_NAME = "dei75gqcl";
const UPLOAD_PRESET = "TEBLOCK";
const QUICK_REACTIONS = ["❤️", "😂", "😡", "😥", "😯", "🙂"];

// تعريف السمات بصور خلفية
const CHAT_THEMES = [
  { id: 'none', emoji: '🚫', bg: '', accent: 'slate', nameKey: 'chat.noTheme', name: 'No Theme' },
  { id: 'home', emoji: '🏘️', bg: 'https://i.ibb.co/8nN8T0VQ/image.png', accent: 'blue', nameKey: 'chat.themeHome', name: 'Home' },
  { id: 'dog', emoji: '🐶', bg: 'https://i.ibb.co/cKywpDsC/image.png', accent: 'orange', nameKey: 'chat.themeDog', name: 'Dog' },
  { id: 'cat', emoji: '😺', bg: 'https://i.ibb.co/TB8BWg6p/image.png', accent: 'purple', nameKey: 'chat.themeCat', name: 'Cat' },
  { id: 'love', emoji: '❤️', bg: 'https://i.ibb.co/Fbxxc6n1/image.png', accent: 'red', nameKey: 'chat.themeLove', name: 'Love' },
  { id: 'avocado', emoji: '🥑', bg: 'https://i.ibb.co/k6s2m3wN/image.png', accent: 'green', nameKey: 'chat.themeAvocado', name: 'Avocado' }
];

const isOnlyEmojis = (str: string) => {
  if (!str) return false;
  const emojiRegex = /(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])/g;
  const matches = str.match(emojiRegex);
  return matches && matches.join('') === str.replace(/\s/g, '');
};

const getEmojiCount = (str: string) => {
  const emojiRegex = /(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])/g;
  const matches = str.match(emojiRegex);
  return matches ? matches.length : 0;
};

const MessageStatus = ({ status, isMe, readByPhotos }: { status: 'sending' | 'sent' | 'delivered' | 'read', isMe: boolean, readByPhotos?: string[] }) => {
  if (!isMe && status !== 'read') return null;

  const BucketIcon = ({ children, color = "text-slate-500" }: { children?: React.ReactNode, color?: string }) => (
    <div className={`relative w-3.5 h-3.5 ${color}`}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="w-full h-full">
        <path d="M4 9h16l-1.5 11h-13L4 9z" />
        <path d="M8 9V7a4 4 0 018 0v2" />
      </svg>
      {children}
    </div>
  );

  if (status === 'sending') {
    return (
      <div className="flex items-center ml-1">
        <BucketIcon color="text-slate-400">
          <div className="absolute -top-1 -left-1 bg-slate-900 rounded-full p-0.5">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" className="w-1.5 h-1.5 text-blue-400">
              <path d="M12 19V5M5 12l7-7 7 7" />
            </svg>
          </div>
        </BucketIcon>
      </div>
    );
  }

  if (status === 'sent') {
    return (
      <div className="flex items-center ml-1">
        <BucketIcon color="text-slate-500">
          <div className="absolute top-[60%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-1 bg-slate-500 rounded-full"></div>
        </BucketIcon>
      </div>
    );
  }

  if (status === 'delivered') {
    return (
      <div className="flex items-center ml-1">
        <BucketIcon color="text-blue-500">
          <div className="absolute -top-1 -left-1 bg-slate-900 rounded-full p-0.5">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" className="w-1.5 h-1.5 text-blue-500">
              <path d="M12 5v14M5 12l7 7 7-7" />
            </svg>
          </div>
        </BucketIcon>
      </div>
    );
  }

  if (status === 'read') {
    return (
      <div className="flex -space-x-1 space-x-reverse ml-1">
        {(readByPhotos || []).slice(0, 3).map((photo, i) => (
          <img key={i} src={photo || undefined} className="w-3.5 h-3.5 rounded-full border border-slate-900 object-cover" />
        ))}
        {readByPhotos && readByPhotos.length > 3 && (
          <div className="w-3.5 h-3.5 rounded-full bg-slate-800 border border-slate-900 flex items-center justify-center text-[5px] font-black text-white">
            +{readByPhotos.length - 3}
          </div>
        )}
      </div>
    );
  }

  return null;
};

const SwipeableMessage = ({ children, onReply, isMe }: { children: React.ReactNode, onReply: () => void, isMe: boolean }) => {
  const [translateX, setTranslateX] = React.useState(0);
  const startX = React.useRef(0);

  const handleTouchStart = (e: React.TouchEvent) => {
    startX.current = e.touches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const currentX = e.touches[0].clientX;
    const diff = currentX - startX.current;
    
    if (isMe && diff < 0 && diff > -80) {
      setTranslateX(diff);
    } else if (!isMe && diff > 0 && diff < 80) {
      setTranslateX(diff);
    }
  };

  const handleTouchEnd = () => {
    if (Math.abs(translateX) > 40) {
      onReply();
    }
    setTranslateX(0);
  };

  return (
    <div 
      className="relative flex items-center w-full"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{ justifyContent: isMe ? 'flex-end' : 'flex-start' }}
    >
      <div 
        className={`absolute ${isMe ? 'right-0' : 'left-0'} flex items-center justify-center w-12 h-full z-0 text-slate-300 transition-opacity ${Math.abs(translateX) > 40 ? 'opacity-100' : 'opacity-0'}`}
      >
        <div className={`w-8 h-8 rounded-full bg-white/10 flex items-center justify-center transition-transform ${Math.abs(translateX) > 40 ? 'scale-110' : 'scale-90'}`}>
           <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6"/></svg>
        </div>
      </div>
      <div 
        className="transition-transform z-10 flex w-full" 
        style={{ transform: `translateX(${translateX}px)`, transitionDuration: translateX === 0 ? '0.2s' : '0s', justifyContent: isMe ? 'flex-end' : 'flex-start' }}
      >
        {children}
      </div>
    </div>
  );
};

const AIChatView: React.FC<AIChatViewProps> = ({ 
  user, 
  initialChat, 
  onClearJump, 
  onModeChange, 
  onNavigateProfile,
  externalSocket,
  externalActiveCalls,
  externalOnlineUsers,
  externalTypingStates
}) => {
  const { t, dir } = useLanguage();
  const [mode, setMode] = useState<ChatMode>('inbox');
  const [activeChat, setActiveChat] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [previews, setPreviews] = useState<ChatPreview[]>([]);
  const [avatarMenuTarget, setAvatarMenuTarget] = useState<any>(null);
  const [friends, setFriends] = useState<User[]>([]);
  const [groupName, setGroupName] = useState("");
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [showFabMenu, setShowFabMenu] = useState(false);
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, message: any } | null>(null);
  const [showMoreContextOptions, setShowMoreContextOptions] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [editingMessage, setEditingMessage] = useState<Message | null>(null);
  const [showForwardModal, setShowForwardModal] = useState<Message | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [emojiTarget, setEmojiTarget] = useState<'input' | 'quickEmoji' | string | null>(null); 
  const currentEmojiStyle = useEmojiStyle();
  const [showEmojiStyleModal, setShowEmojiStyleModal] = useState(false);

  useEffect(() => {
    if (initialChat) {
      const aiChatId = `ai_${user.Id_user}`;
      const isAI = initialChat.isAI || initialChat.id === 'ai' || initialChat.id === aiChatId || initialChat.name === 'TeBLOCK AI';
      if (isAI) {
        setActiveChat({
          id: 'ai',
          name: "TeBLOCK AI",
          photo: "https://api.dicebear.com/7.x/bottts/svg?seed=ai",
          isAI: true,
          isGroup: false
        });
        setMode('activeChat');
        onClearJump?.();
      } else if (initialChat.name) {
        setActiveChat(initialChat);
        setMode('activeChat');
        onClearJump?.();
      } else {
        // We only have the ID (from URL), fetch the rest
        const fetchChat = async () => {
          try {
            let foundChat = null;
            // Check if it's a user
            const userRef = await getDocs(query(collection(db, 'users'), where('Id_user', '==', initialChat.id)));
            if (!userRef.empty) {
              const uData = userRef.docs[0].data();
              foundChat = { id: uData.Id_user, name: uData.UserData, photo: uData.photoURL, isGroup: false };
            } else {
              // Might be a group
              const groupSnap = await getDoc(doc(db, 'groups', initialChat.id));
              if (groupSnap.exists()) {
                const gData = groupSnap.data();
                if (gData.members?.includes(user.Id_user)) {
                   foundChat = { id: groupSnap.id, name: gData.name, photo: gData.photo, isGroup: true, ...gData };
                }
              }
            }
            
            if (foundChat) {
              setActiveChat(foundChat);
              setMode('activeChat');
            } else {
              // Find similar group
              const userGroupsSnap = await getDocs(query(collection(db, 'groups'), where('members', 'array-contains', user.Id_user)));
              const similarGroup = userGroupsSnap.docs.find(d => d.id.toLowerCase().includes(initialChat.id.toLowerCase()));
              
              if (similarGroup) {
                 const gData = similarGroup.data();
                 setActiveChat({ id: similarGroup.id, name: gData.name, photo: gData.photo, isGroup: true, ...gData });
                 setMode('activeChat');
              } else {
                 // Try finding similar friend if friends is loaded, otherwise fallback to AI
                 const similarFriend = friends.find(f => f.Id_user.toLowerCase().includes(initialChat.id.toLowerCase()));
                 if (similarFriend) {
                    setActiveChat({ id: similarFriend.Id_user, name: similarFriend.UserData, photo: similarFriend.photoURL, isGroup: false });
                    setMode('activeChat');
                 } else {
                    setActiveChat({ id: 'ai', name: "TeBLOCK AI", photo: "https://api.dicebear.com/7.x/bottts/svg?seed=ai", isAI: true, isGroup: false });
                    setMode('activeChat');
                 }
              }
            }
          } catch(e) {
            console.error(e);
          } finally {
            onClearJump?.();
          }
        };
        fetchChat();
      }
    }
  }, [initialChat, onClearJump]);

  const [recentEmojis, setRecentEmojis] = useState<string[]>(JSON.parse(localStorage.getItem('recent_emojis') || '[]'));
  
  const [isRecording, setIsRecording] = useState(false);
  const [recordingVolume, setRecordingVolume] = useState(0);
  const [isSearchingChat, setIsSearchingChat] = useState(false);
  const [chatSearchTerm, setChatSearchTerm] = useState("");
  const [inboxSearchActiveTab, setInboxSearchActiveTab] = useState<'chats' | 'messages' | 'groups'>('chats');
  const [inboxSearchTerm, setInboxSearchTerm] = useState("");
  const [inboxSearchResults, setInboxSearchResults] = useState<{chats: any[], messages: any[], groups: any[]}>({chats: [], messages: [], groups: []});
  const [inboxSearchLoading, setInboxSearchLoading] = useState(false);
  const [showGifPicker, setShowGifPicker] = useState(false);
  const [showMentionList, setShowMentionList] = useState(false);
  const [mentionSearch, setMentionSearch] = useState("");
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);
  
  // حالات مخصصة لكل محادثة
  const [currentChatTheme, setCurrentChatTheme] = useState(CHAT_THEMES[0]);
  const [quickEmoji, setQuickEmoji] = useState('🙂');
  const [nicknames, setNicknames] = useState<Record<string, string>>({});
  const [editingNicknameId, setEditingNicknameId] = useState<string | null>(null);
  const [nicknameInput, setNicknameInput] = useState("");
  const [joinRequests, setJoinRequests] = useState<any[]>([]);

  useEffect(() => {
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      const colorMap: Record<string, string> = {
        none: '#0b1120',
        home: '#1e3a8a',
        dog: '#7c2d12',
        cat: '#581c87',
        love: '#7f1d1d',
        avocado: '#14532d'
      };
      metaThemeColor.setAttribute('content', colorMap[currentChatTheme.id] || '#0b1120');
    }
  }, [currentChatTheme]);

  // Target user data & appeal states
  const [targetUserData, setTargetUserData] = useState<User | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [showAppealModal, setShowAppealModal] = useState(false);
  const [appealReason, setAppealReason] = useState<'innocent' | 'apology'>('innocent');
  const [appealExplanation, setAppealExplanation] = useState("");
  const [isSubmittingAppeal, setIsSubmittingAppeal] = useState(false);
  const [appealSuccess, setAppealSuccess] = useState(false);

  useEffect(() => {
    if (!activeChat || activeChat.isGroup || activeChat.isAI || !activeChat.id) {
      setTargetUserData(null);
      return;
    }
    const unsub = onSnapshot(doc(db, 'users', activeChat.id), (snap) => {
      if (snap.exists()) {
        setTargetUserData(snap.data() as User);
      } else {
        setTargetUserData(null);
      }
    });
    return unsub;
  }, [activeChat?.id, activeChat?.isGroup, activeChat?.isAI]);

  const isCurrentUserMessagingRestricted = Boolean(
    user.messagingRestrictedForever === true ||
    (user.messagingRestrictionUntil && user.messagingRestrictionUntil > Date.now()) ||
    user.Freechat === '0' ||
    user.Freechat === 'مقفل' ||
    user.Freechat === 'مقفول'
  );

  const isTargetPermanentlyBanned = Boolean(
    targetUserData && (
      targetUserData.messagingRestrictedForever === true ||
      targetUserData.Freeaccount === 'مقفول' ||
      targetUserData.Freeaccount === 'مقفل' ||
      targetUserData.Freeaccount_unlock === '{¥}'
    )
  );

  const isBlockedByMe = Boolean(
    !activeChat?.isGroup && !activeChat?.isAI && activeChat?.id && user.blockedUsers?.includes(activeChat.id)
  );

  const isBlockedByTarget = Boolean(
    !activeChat?.isGroup && !activeChat?.isAI && targetUserData?.blockedUsers?.includes(user.Id_user)
  );

  const isChatBlocked = isBlockedByMe || isBlockedByTarget;

  const handleToggleBlock = async (targetId: string) => {
    if (!targetId) return;
    try {
      const currentlyBlocked = user.blockedUsers?.includes(targetId);
      if (currentlyBlocked) {
        await updateDoc(doc(db, 'users', user.Id_user), {
          blockedUsers: arrayRemove(targetId)
        });
      } else {
        await updateDoc(doc(db, 'users', user.Id_user), {
          blockedUsers: arrayUnion(targetId)
        });
        setMessages([]);
      }
      setMode('activeChat');
    } catch (e) {
      console.error("Block/unblock error:", e);
    }
  };

  // Phone hardware/browser back button support for chat sub-views
  const prevModeRef = useRef<string>(mode);
  useEffect(() => {
    if (mode !== 'inbox' && mode !== prevModeRef.current) {
      window.history.pushState({ chatMode: mode }, '', window.location.pathname);
    }
    prevModeRef.current = mode;
  }, [mode]);

  useEffect(() => {
    const onPopState = () => {
      if (['groupMembers', 'themePicker', 'nicknamePicker', 'quickEmojiPicker'].includes(mode)) {
        setMode('chatSettings');
      } else if (mode === 'chatSettings') {
        setMode('activeChat');
      } else if (mode === 'createGroup' || mode === 'activeChat') {
        setMode('inbox');
      }
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [mode]);

  const getMessagingRestrictionMessage = () => {
    if (user.messagingRestrictedForever) {
      return t("chat.restrictionPermanentMsg");
    }
    if (user.messagingRestrictionUntil && user.messagingRestrictionUntil > Date.now()) {
      return `${t('chat.restrictionTemporaryPrefix')}${new Date(user.messagingRestrictionUntil).toLocaleString()}`;
    }
    if (user.messagingRestrictionReason) {
      return `${t('chat.reasonPrefix')}${user.messagingRestrictionReason}`;
    }
    return t("chat.restrictionGeneralMsg");
  };

  const handleSendMessagingAppeal = async () => {
    if (isSubmittingAppeal) return;
    setIsSubmittingAppeal(true);
    try {
      await addDoc(collection(db, 'appeals'), {
        userId: user.Id_user,
        userName: user.UserData,
        userPhoto: user.photoURL || "",
        restrictionType: 'messaging',
        reason: appealReason,
        userExplanation: appealExplanation.trim(),
        timestamp: serverTimestamp(),
        status: 'pending'
      });

      await updateDoc(doc(db, 'users', user.Id_user), {
        hasAppealed: true
      });

      setAppealSuccess(true);
      setTimeout(() => {
        setShowAppealModal(false);
        setAppealSuccess(false);
      }, 1500);
    } catch (e) {
      console.error(e);
      alert(t("common.error"));
    } finally {
      setIsSubmittingAppeal(false);
    }
  };

  const scrollRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const longPressTimer = useRef<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const isUserTyping = inputMessage.length > 0;

  const handleInputChange = (val: string) => {
    setInputMessage(val);
    
    if (!activeChat?.isGroup) {
      setShowMentionList(false);
      return;
    }

    const cursorPosition = textareaRef.current?.selectionStart || 0;
    const textBeforeCursor = val.substring(0, cursorPosition);
    const lastAtPos = textBeforeCursor.lastIndexOf('@');

    if (lastAtPos !== -1) {
      const textAfterAt = textBeforeCursor.substring(lastAtPos + 1);
      // Only show if @ is at start or after space
      if (lastAtPos === 0 || textBeforeCursor[lastAtPos - 1] === ' ') {
        // Ensure no space between @ and cursor
        if (!textAfterAt.includes(' ')) {
          setMentionSearch(textAfterAt);
          setShowMentionList(true);
          return;
        }
      }
    }
    setShowMentionList(false);
  };

  const insertMention = (name: string) => {
    const cursorPosition = textareaRef.current?.selectionStart || 0;
    const textBeforeCursor = inputMessage.substring(0, cursorPosition);
    const textAfterCursor = inputMessage.substring(cursorPosition);
    const lastAtPos = textBeforeCursor.lastIndexOf('@');
    
    const beforeAt = inputMessage.substring(0, lastAtPos);
    const newMessage = beforeAt + "@" + name + " " + textAfterCursor;
    
    setInputMessage(newMessage);
    setShowMentionList(false);
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const newPos = beforeAt.length + name.length + 2;
        textareaRef.current.setSelectionRange(newPos, newPos);
      }
    }, 0);
  };

  const renderTextareaOverlay = () => {
    if (!inputMessage) return null;
    
    const names = [
      'TeBLOCK AI',
      ...(activeChat?.membersData?.map((m: any) => m.UserData) || []),
      user.UserData
    ];
    names.sort((a, b) => b.length - a.length);

    let result: (string | React.ReactNode)[] = [inputMessage];
    names.forEach(name => {
      const newResult: (string | React.ReactNode)[] = [];
      const mention = `@${name}`;
      result.forEach(part => {
        if (typeof part !== 'string') { newResult.push(part); return; }
        const subParts = part.split(mention);
        subParts.forEach((subPart, idx) => {
          newResult.push(subPart);
          if (idx < subParts.length - 1) {
            newResult.push(<span key={idx} className="text-blue-400 font-black">{mention}</span>);
          }
        });
      });
      result = newResult;
    });
    return result;
  };

  const filteredMembers = [
    { Id_user: 'ai', UserData: 'TeBLOCK AI', photoURL: 'https://api.dicebear.com/7.x/bottts/svg?seed=ai' },
    ...(activeChat?.membersData || []).filter((m: any) => m.Id_user !== user.Id_user)
  ].filter((m: any) => m.UserData.toLowerCase().includes(mentionSearch.toLowerCase()));

  const renderMessageText = (text: string) => {
    if (!text) return null;
    // Split by mention pattern: @ followed by non-space characters until a space or end of string
    // Since our mentions can have spaces (like "TeBLOCK AI"), we need a better way.
    // However, the user's name is what follows @.
    
    // For simplicity, we'll look for @ followed by any of the members' names or "TeBLOCK AI"
    const names = [
      'TeBLOCK AI',
      ...(activeChat?.membersData?.map((m: any) => m.UserData) || []),
      user.UserData
    ];
    
    // Sort names by length descending to match longest names first
    names.sort((a, b) => b.length - a.length);
    
    let result: (string | React.ReactNode)[] = [text];
    
    names.forEach(name => {
      const newResult: (string | React.ReactNode)[] = [];
      const mention = `@${name}`;
      
      result.forEach(part => {
        if (typeof part !== 'string') {
          newResult.push(part);
          return;
        }
        
        const subParts = part.split(mention);
        subParts.forEach((subPart, idx) => {
          newResult.push(subPart);
          if (idx < subParts.length - 1) {
            const member = activeChat?.membersData?.find((m: any) => m.UserData === name);
            newResult.push(
              <button 
                key={`${name}-${idx}`} 
                onClick={(e) => {
                  e.stopPropagation();
                  if (name === 'TeBLOCK AI') {
                    setActiveChat({ id: 'ai', name: 'TeBLOCK AI', photo: 'https://api.dicebear.com/7.x/bottts/svg?seed=ai', isAI: true, isGroup: false });
                    setMode('activeChat');
                  } else if (member) {
                    setAvatarMenuTarget({ id: member.Id_user, name: member.UserData, photo: member.photoURL });
                  }
                }}
                className="inline-flex items-center px-2 py-0.5 bg-blue-500/20 text-blue-400 rounded-lg font-black mx-0.5 border border-blue-500/30 hover:bg-blue-500/40 transition-colors cursor-pointer"
              >
                {mention}
              </button>
            );
          }
        });
      });
      result = newResult;
    });
    
    // Convert emojis in all plain string parts to uniform EmojiImg components
    const finalResult: React.ReactNode[] = [];
    result.forEach((part, pIdx) => {
      if (typeof part === 'string') {
        const emojiNodes = renderEmojiText(part, { size: 20 });
        emojiNodes.forEach((node, nIdx) => {
          finalResult.push(React.isValidElement(node) ? React.cloneElement(node, { key: `em-${pIdx}-${nIdx}` }) : node);
        });
      } else {
        finalResult.push(part);
      }
    });

    return finalResult;
  };

  // Real-time Server State
  const onlineUsers = externalOnlineUsers || {};
  const typingStates = externalTypingStates || {};
  const activeCalls = externalActiveCalls || {};
  const socketRef = { current: externalSocket || null };
  const CONTROL_KEY = 'admin123'; 
  
  // P2P Direct WebRTC Audio Call State (مكالمة صوتية مباشرة بين الجهازين مع حفظ وإسقاط الآيبي المؤقت)
  const [activeP2PSession, setActiveP2PSession] = useState<P2PCallSession | null>(null);
  const [currentChatCall, setCurrentChatCall] = useState<P2PCallSession | null>(null);

  // استماع للمكالمات المباشرة المرتبطة بالمحادثة الحالية عبر Firestore
  useEffect(() => {
    if (!activeChat) {
      setCurrentChatCall(null);
      return;
    }

    const q = query(
      collection(db, 'calls'),
      where('chatId', '==', activeChat.id),
      where('status', 'in', ['ringing', 'connected'])
    );

    const unsub = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        setCurrentChatCall(snapshot.docs[0].data() as P2PCallSession);
      } else {
        setCurrentChatCall(null);
      }
    });

    return () => unsub();
  }, [activeChat?.id]);

  useEffect(() => {
    p2pCallManager.setCallbacks({
      onSessionUpdate: (session) => {
        setActiveP2PSession(session);
        if (session && (session.status === 'ringing' || session.status === 'connected')) {
          setMode('voiceCall');
        }
      },
      onCallEnded: () => {
        setActiveP2PSession(null);
        if (mode === 'voiceCall') {
          setMode('activeChat');
        }
      }
    });
  }, [mode]);

  const joinCall = async (existingCallId?: string) => {
    if (!activeChat) return;

    try {
      if (existingCallId || (currentChatCall && currentChatCall.status === 'ringing')) {
        const targetCallId = existingCallId || currentChatCall?.callId;
        if (targetCallId) {
          await p2pCallManager.answerCall(targetCallId, user);
          setMode('voiceCall');
          return;
        }
      }

      // بدء مكالمة صوتية مباشرة P2P مع حفظ الآيبي المؤقت للمتصل في قاعدة البيانات
      const newCallId = await p2pCallManager.initiateCall(
        user,
        { id: activeChat.id, name: activeChat.name, photo: activeChat.photo },
        activeChat.id,
        activeChat.isGroup
      );

      // إرسال رسالة دعوة في الشات
      const messageData: any = {
        senderId: user.Id_user,
        senderName: user.UserData,
        senderPhoto: user.photoURL || "",
        text: t("chat.p2pCallStartedMsg"),
        timestamp: serverTimestamp(),
        isCallInvite: true,
        callId: newCallId
      };

      if (activeChat.isGroup) {
        messageData.groupId = activeChat.id;
      } else {
        messageData.receiverId = activeChat.id;
      }

      await addDoc(collection(db, 'messages'), messageData);
      setMode('voiceCall');
    } catch (err: any) {
      console.error("P2P Call error:", err);
      alert(err.message || t("chat.callFailedMic"));
    }
  };

  const leaveCall = async () => {
    try {
      // إنهاء المكالمة وإسقاط الآيبي المؤقت للجهازين من قاعدة البيانات
      await p2pCallManager.endCall();
    } catch (e) {
      console.warn("Error leaving call:", e);
    } finally {
      setActiveP2PSession(null);
      setMode('activeChat');
    }
  };

  const updateStatus = (statusType: 'typing' | 'recording' | null) => {
    if (socketRef.current?.readyState === WebSocket.OPEN && activeChat) {
      socketRef.current.send(JSON.stringify({
        type: 'status_update',
        targetId: activeChat.id,
        statusType
      }));
    }
  };

  useEffect(() => {
    updateStatus(isUserTyping ? 'typing' : null);
  }, [isUserTyping]);

  useEffect(() => {
    updateStatus(isRecording ? 'recording' : null);
  }, [isRecording]);

  const { data: serverStatus, refetch: refetchStatus } = useQuery({
    queryKey: ['serverStatus'],
    queryFn: async () => {
      const res = await fetch('/api/server-status', {
        headers: { 'x-control-key': CONTROL_KEY }
      });
      if (!res.ok) throw new Error('Failed to connect');
      return res.json();
    },
    refetchInterval: 30000 // Check every 30s
  });

  const { data: serverLogs } = useQuery({
    queryKey: ['serverLogs'],
    queryFn: async () => {
      const res = await fetch('/api/logs', {
        headers: { 'x-control-key': CONTROL_KEY }
      });
      if (!res.ok) throw new Error('Failed to fetch logs');
      return res.json();
    },
    enabled: mode === 'chatSettings'
  });

  useEffect(() => {
    if (mode === 'activeChat' && messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
      if (window.scrollY !== 0) {
        window.scrollTo(0, 0);
      }
    }
  }, [mode, messages]);

  useEffect(() => {
    onModeChange?.(mode);
    if (mode === 'inbox') setActiveChat(null);
  }, [mode]);

  const unsubConv = useRef<(() => void) | null>(null);
  const prevMsgIds = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (mode === 'activeChat' && activeChat) {
      soundManager.playOpenChatSound();
      setCurrentChatTheme(CHAT_THEMES[0]);
      setQuickEmoji('🙂');
      setNicknames({});
    }

    const aiChatId = `ai_${user.Id_user}`;
    
    // Fetch direct messages (including AI messages sent to/from user, 'ai', or aiChatId)
    const qMsgs = query(
      collection(db, 'messages'),
      or(
        where('senderId', '==', user.Id_user), 
        where('receiverId', '==', user.Id_user),
        where('receiverId', '==', aiChatId),
        where('senderId', '==', aiChatId),
        where('receiverId', '==', 'ai'),
        where('senderId', '==', 'ai')
      ),
      limit(300)
    );

    // Fetch groups
    const qGroups = query(
      collection(db, 'groups'),
      where('members', 'array-contains', user.Id_user),
      limit(100)
    );
    const qGroupsEx = query(
      collection(db, 'groups'),
      where('exMembers', 'array-contains', user.Id_user),
      limit(100)
    );

    // Fetch friends for group management
    const unsubUser = onSnapshot(doc(db, 'users', user.Id_user), (snap) => {
      const userData = snap.data() as User;
      if (userData?.friendsList?.length) {
        const qF = query(collection(db, 'users'), where('Id_user', 'in', userData.friendsList));
        onSnapshot(qF, (fSnap) => {
          setFriends(fSnap.docs.map(d => d.data() as User));
        });
      }
    });

    let userGroupsActive: any[] = [];
    let userGroupsEx: any[] = [];
    let userGroups: any[] = [];

    const updateGroups = () => {
      const map = new Map();
      [...userGroupsActive, ...userGroupsEx].forEach(g => map.set(g.id, g));
      userGroups = Array.from(map.values());
    };

    const unsubGroups = onSnapshot(qGroups, (groupSnap) => {
      userGroupsActive = groupSnap.docs.map(d => { const data = d.data() as any; return { id: d.id, ...data, text: decryptText(data.text || "") }; });
      updateGroups();
    });

    const unsubGroupsEx = onSnapshot(qGroupsEx, (groupSnap) => {
      userGroupsEx = groupSnap.docs.map(d => { const data = d.data() as any; return { id: d.id, ...data, text: decryptText(data.text || "") }; });
      updateGroups();
    });

    const qGroupMsgs = query(
      collection(db, 'messages'),
      where('groupId', '!=', null),
      limit(500)
    );

    const unsubMessages = onSnapshot(qMsgs, (snap) => {
      const directMsgs = snap.docs.map(d => { const data = d.data() as any; return { id: d.id, ...data, text: decryptText(data.text || "") }; });
      
      onSnapshot(qGroupMsgs, (gSnap) => {
        const groupMsgs = gSnap.docs.map(d => { const data = d.data() as any; return { id: d.id, ...data, text: decryptText(data.text || "") }; })
          .filter(m => {
            const g = userGroups.find(grp => grp.id === m.groupId);
            if (!g) return false;
            if (g.exMembers?.includes(user.Id_user)) {
               const leftAt = g[`leftAt_${user.Id_user.replace(/\./g, "_")}`]?.seconds;
               if (leftAt && m.timestamp?.seconds > leftAt) return false;
            }
            return true;
          });
        
        const allMsgsMap = new Map();
        [...directMsgs, ...groupMsgs].forEach(m => allMsgsMap.set(m.id, m));
        const allMsgs = Array.from(allMsgsMap.values()).filter((m: any) => !m.deletedFor?.includes(user.Id_user));
        
        const newIds = new Set(allMsgs.map((m: any) => m.id));
        if (prevMsgIds.current.size > 0) {
          const hasNew = allMsgs.some((m: any) => !prevMsgIds.current.has(m.id) && m.senderId !== user.Id_user && (m.timestamp?.seconds || 0) * 1000 > Date.now() - 5000);
          if (hasNew) soundManager.playReceiveSound();
        }
        prevMsgIds.current = newIds;

        // Inject up-to-date user data
        allMsgs.forEach((m: any) => {
          if (m.replyToText && m.replyToText.startsWith('ENC:')) m.replyToText = decryptText(m.replyToText);
          if (m.senderId === user.Id_user) {
            m.senderName = user.UserData;
            m.senderPhoto = user.photoURL || "";
          } else {
            const friend = friends.find(f => f.Id_user === m.senderId);
            if (friend) {
              m.senderName = friend.UserData;
              m.senderPhoto = friend.photoURL || "";
            }
          }
          if (m.receiverId === user.Id_user) {
            m.receiverName = user.UserData;
            m.receiverPhoto = user.photoURL || "";
          } else if (m.receiverId) {
            const friend = friends.find(f => f.Id_user === m.receiverId);
            if (friend) {
              m.receiverName = friend.UserData;
              m.receiverPhoto = friend.photoURL || "";
            }
          }
        });
        
        // Mark as delivered
        allMsgs.forEach(m => {
          if (m.receiverId === user.Id_user && !m.delivered) {
            updateDoc(doc(db, 'messages', m.id), { delivered: true });
          }
        });

        const chatMap: Record<string, ChatPreview> = {};
        const manualUnreads = JSON.parse(localStorage.getItem(`unreads_${user.Id_user}`) || '[]');

        // Helper to safely extract message timestamp seconds (treats pending serverTimestamp as Date.now)
        const getMsgSeconds = (m: any) => {
          if (m?.timestamp?.seconds) return m.timestamp.seconds;
          if (m?.timestamp?.toDate) return m.timestamp.toDate().getTime() / 1000;
          if (typeof m?.timestamp === 'number') return m.timestamp > 1e11 ? m.timestamp / 1000 : m.timestamp;
          return Date.now() / 1000;
        };

        // Process all messages for previews (descending for latest preview snippet)
        allMsgs.sort((a, b) => getMsgSeconds(b) - getMsgSeconds(a));
        allMsgs.forEach(msg => {
          if (msg.groupId) {
            const group = userGroups.find(g => g.id === msg.groupId);
            if (group && !chatMap[group.id]) {
              chatMap[group.id] = {
                id: group.id,
                name: group.name || group.UserData || t("chat.groupDefaultName"),
                photo: group.photo || `https://api.dicebear.com/7.x/identicon/svg?seed=${group.id}`,
                lastMessage: msg.voiceUrl ? "🎤 " + (t("chat.voiceMessage") || "Voice Note") : (msg.imageUrl ? "📷 " + (t("chat.photo") || "Photo") : `${msg.senderName}: ${msg.text}`),
                timestamp: msg.timestamp,
                unreadCount: 0, // Will calculate below
                isGroup: true,
                manualUnread: manualUnreads.includes(group.id),
                admins: group.admins,
                members: group.members
              };
            }
          } else {
            const myIds = [user['id-2'], user.Id_user].filter(Boolean);
            const isFromMe = myIds.includes(msg.senderId);
            const isAIMsg = msg.receiverId === aiChatId || msg.senderId === aiChatId || msg.receiverId === 'ai' || msg.senderId === 'ai' || msg.senderName === 'TeBLOCK AI' || msg.receiverName === 'TeBLOCK AI';
            const rawOtherId = isAIMsg ? 'ai' : (isFromMe ? msg.receiverId : msg.senderId);
            if (!rawOtherId) return;
            const matchedFriend = !isAIMsg
              ? friends.find(f => f.Id_user === rawOtherId || f['id-2'] === rawOtherId)
              : null;
            const otherId = isAIMsg ? 'ai' : (matchedFriend?.['id-2'] || matchedFriend?.Id_user || rawOtherId);
            if (!chatMap[otherId]) {
              const isAI = isAIMsg || otherId === 'ai';
              const resolvedPhoto = isAI
                ? "https://api.dicebear.com/7.x/bottts/svg?seed=ai"
                : (matchedFriend?.photoURL || (isFromMe ? msg.receiverPhoto : msg.senderPhoto) || `https://api.dicebear.com/7.x/bottts/svg?seed=${otherId}`);
              const resolvedName = isAI
                ? "TeBLOCK AI"
                : (matchedFriend?.UserData || (isFromMe ? msg.receiverName : msg.senderName) || t("admin.user"));
              chatMap[otherId] = {
                id: matchedFriend?.Id_user || otherId,
                name: resolvedName,
                photo: resolvedPhoto,
                lastMessage: msg.voiceUrl ? "🎤 " + (t("chat.voiceMessage") || "Voice Note") : (msg.reelId ? "🎬 ريلز" : (msg.imageUrl ? "📷 " + (t("chat.photo") || "Photo") : (msg.text || ""))),
                timestamp: msg.timestamp,
                unreadCount: 0, // Will calculate below
                isGroup: false,
                isAI,
                manualUnread: manualUnreads.includes(otherId) || manualUnreads.includes(rawOtherId)
              };
            }
          }
        });

        // Add groups without messages
        userGroups.forEach(group => {
          if (!chatMap[group.id]) {
            chatMap[group.id] = {
              id: group.id,
              name: group.name || group.UserData || t("chat.groupDefaultName"),
              photo: group.photo || `https://api.dicebear.com/7.x/identicon/svg?seed=${group.id}`,
              lastMessage: t("chat.noMessagesYet"),
              timestamp: group.timestamp,
              unreadCount: 0,
              isGroup: true,
              manualUnread: manualUnreads.includes(group.id),
              admins: group.admins,
              members: group.members
            };
          }
        });

        // Calculate unreads and tags
        allMsgs.forEach(msg => {
          if (msg.groupId) {
            if (chatMap[msg.groupId] && msg.senderId !== user.Id_user && !msg.readBy?.includes(user.Id_user)) {
              chatMap[msg.groupId].unreadCount += 1;
              if (msg.text && msg.text.includes(`@${user.UserData}`)) {
                chatMap[msg.groupId].isTagged = true;
              }
            }
          } else {
            const isAIMsg = msg.receiverId === aiChatId || msg.senderId === aiChatId || msg.receiverId === 'ai' || msg.senderId === 'ai' || msg.senderName === 'TeBLOCK AI';
            let otherId = isAIMsg ? 'ai' : (msg.senderId === user.Id_user ? msg.receiverId : msg.senderId);
            if (otherId && chatMap[otherId] && msg.receiverId === user.Id_user && !msg.read) {
              chatMap[otherId].unreadCount += 1;
            }
          }
        });

        setPreviews(Object.values(chatMap).sort((a, b) => getMsgSeconds(b) - getMsgSeconds(a)));

        if (mode === 'activeChat' && activeChat) {
          let chatMsgs = [];
          if (activeChat.isGroup) {
            chatMsgs = allMsgs.filter(m => m.groupId === activeChat.id);
            // Chronological ascending sort (oldest at top, newest at bottom)
            chatMsgs.sort((a, b) => getMsgSeconds(a) - getMsgSeconds(b));
            chatMsgs.forEach(m => {
              if (m.senderId !== user.Id_user && !m.readBy?.includes(user.Id_user)) {
                updateDoc(doc(db, 'messages', m.id), { readBy: arrayUnion(user.Id_user) });
              }
            });
            
            const currentGroup = userGroups.find(g => g.id === activeChat.id);
            if (currentGroup) {
              const qM = query(collection(db, 'users'), where('Id_user', 'in', currentGroup.members));
              onSnapshot(qM, (mSnap) => {
                const membersData = mSnap.docs.map(d => d.data());
                setActiveChat((prev: any) => prev?.id === currentGroup.id ? { ...prev, ...currentGroup, membersData } : prev);
              });
            }
          } else {
            const isAIChat = activeChat.isAI || activeChat.id === 'ai' || activeChat.id === aiChatId || activeChat.name === 'TeBLOCK AI';
            if (isAIChat) {
              chatMsgs = allMsgs.filter(m =>
                !m.isPrivateAIReply && (
                  (m.senderId === user.Id_user && (m.receiverId === aiChatId || m.receiverId === 'ai' || m.receiverName === 'TeBLOCK AI')) ||
                  ((m.senderId === aiChatId || m.senderId === 'ai' || m.senderName === 'TeBLOCK AI') && m.receiverId === user.Id_user)
                )
              );
            } else {
              const targetId = activeChat.id;
              const blockedEitherWay = Boolean(
                user.blockedUsers?.includes(targetId) || targetUserData?.blockedUsers?.includes(user.Id_user)
              );
              if (blockedEitherWay) {
                chatMsgs = [];
              } else {
                chatMsgs = allMsgs.filter(m =>
                  (m.senderId === user.Id_user && m.receiverId === targetId) ||
                  (m.senderId === targetId && m.receiverId === user.Id_user) ||
                  (m.isPrivateAIReply && ((m.receiverId === targetId && m.aiContextUserId === user.Id_user) || (m.receiverId === user.Id_user && m.aiContextUserId === targetId)))
                );
              }
            }
            // Chronological ascending sort (oldest at top, newest at bottom)
            chatMsgs.sort((a, b) => getMsgSeconds(a) - getMsgSeconds(b));
            chatMsgs.forEach(m => { if (m.receiverId === user.Id_user && !m.read) updateDoc(doc(db, 'messages', m.id), { read: true }); });
          }
          setMessages(prev => {
            // Keep optimistic messages that haven't arrived in server response yet
            const serverIds = new Set(chatMsgs.map(m => m.id));
            const pendingOptimistic = prev.filter(m => m.id?.startsWith('optimistic_') && !serverIds.has(m.id));
            if (pendingOptimistic.length > 0) {
              const combined = [...chatMsgs, ...pendingOptimistic];
              combined.sort((a, b) => getMsgSeconds(a) - getMsgSeconds(b));
              return combined;
            }
            return chatMsgs;
          });
          
          // Sync settings
          const convId = activeChat.isGroup ? activeChat.id : (activeChat.isAI ? null : [user.Id_user, activeChat.id].sort().join('_'));
          if (convId) {
            if (unsubConv.current) unsubConv.current();
            unsubConv.current = onSnapshot(doc(db, 'conversations', convId), (snap) => {
               if (snap.exists()) {
                  const data = snap.data();
                  if (data.themeId) {
                     const theme = CHAT_THEMES.find(t => t.id === data.themeId);
                     if (theme) setCurrentChatTheme(theme);
                  } else {
                     setCurrentChatTheme(CHAT_THEMES[0]);
                  }
                  if (data.quickEmoji) setQuickEmoji(data.quickEmoji);
                  if (data.nicknames) setNicknames(data.nicknames);
               } else {
                  setCurrentChatTheme(CHAT_THEMES[0]);
                  setQuickEmoji('🙂');
                  setNicknames({});
               }
            });
          } else if (activeChat.isAI) {
            const savedThemeId = localStorage.getItem(`theme_${user.Id_user}_ai`);
            if (savedThemeId) setCurrentChatTheme(CHAT_THEMES.find(t => t.id === savedThemeId) || CHAT_THEMES[0]);
            const savedEmoji = localStorage.getItem(`emoji_${user.Id_user}_ai`);
            if (savedEmoji) setQuickEmoji(savedEmoji);
          }
        }
      });
    });

    return () => {
      unsubMessages();
      unsubGroups();
      unsubGroupsEx();
      unsubUser();
      if (unsubConv.current) unsubConv.current();
    };
  }, [user.Id_user, mode, activeChat?.id]);

  const sendSystemMessage = async (text: string, chatId?: string) => {
     if (!activeChat && !chatId) return;
     const targetId = chatId || (activeChat.isAI ? `ai_${user.Id_user}` : activeChat.id);
     
     const messageData: any = {
        senderId: user.Id_user,
        text,
        timestamp: serverTimestamp(),
        isSystem: true,
        senderName: user.UserData,
        senderPhoto: user.photoURL || "",
        read: true
     };

     if (activeChat?.isGroup || chatId) {
       messageData.groupId = targetId;
       messageData.readBy = [user.Id_user];
     } else {
       messageData.receiverId = targetId;
       messageData.receiverName = nicknames[(activeChat.id || "").replace(/\./g, "_")] || activeChat.name;
       messageData.receiverPhoto = activeChat.photo;
     }

     await addDoc(collection(db, 'messages'), messageData);
  };

  const toggleManualUnread = (chatId: string) => {
     const current = JSON.parse(localStorage.getItem(`unreads_${user.Id_user}`) || '[]');
     if (current.includes(chatId)) {
        localStorage.setItem(`unreads_${user.Id_user}`, JSON.stringify(current.filter((id: string) => id !== chatId)));
     } else {
        localStorage.setItem(`unreads_${user.Id_user}`, JSON.stringify([...current, chatId]));
     }
  };

  const handleEmojiSelect = async (emoji: string) => {
    if (checkMute()) return;
    if (emojiTarget === 'input') {
      setInputMessage(prev => prev + emoji);
    } else if (emojiTarget === 'quickEmoji') {
      setQuickEmoji(emoji);
      const convId = activeChat.isGroup ? activeChat.id : (activeChat.isAI ? null : [user.Id_user, activeChat.id].sort().join('_'));
      if (convId) {
         await setDoc(doc(db, 'conversations', convId), { quickEmoji: emoji }, { merge: true });
      } else if (activeChat.isAI) {
         localStorage.setItem(`emoji_${user.Id_user}_ai`, emoji);
      }
      setShowEmojiPicker(false);
    } else if (emojiTarget) {
      handleReaction(emojiTarget, emoji);
      setShowEmojiPicker(false);
    }
    saveRecentEmoji(emoji);
  };

  const saveRecentEmoji = (emoji: string) => {
    const updated = [emoji, ...recentEmojis.filter(e => e !== emoji)].slice(0, 20);
    setRecentEmojis(updated);
    localStorage.setItem('recent_emojis', JSON.stringify(updated));
  };

  const isMeAdmin = activeChat?.isGroup && activeChat?.admins?.includes(user.Id_user);
  const isKicked = activeChat?.isGroup && !activeChat?.members?.includes(user.Id_user);

  const createGroup = async () => {
    if (!groupName.trim() || selectedMembers.length === 0) return;
    const groupData = {
      name: groupName,
      members: [user.Id_user, ...selectedMembers],
      admins: [user.Id_user],
      createdBy: user.Id_user,
      timestamp: serverTimestamp(),
      photo: `https://api.dicebear.com/7.x/identicon/svg?seed=${Date.now()}`
    };
    const docRef = await addDoc(collection(db, 'groups'), groupData);
    await sendSystemMessage(`${user.UserData} ${t("chat.groupCreatedBy")}`, docRef.id);
    setMode('inbox');
    setGroupName("");
    setSelectedMembers([]);
  };

  useEffect(() => {
    if (mode === 'groupMembers' && activeChat?.isGroup && isMeAdmin) {
      const q = query(
        collection(db, 'notifications'), 
        where('groupId', '==', activeChat.id), 
        where('type', '==', 'group_join_request'),
        where('read', '==', false)
      );
      const unsub = onSnapshot(q, (snap) => {
        setJoinRequests(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      });
      return () => unsub();
    }
  }, [mode, activeChat?.id, isMeAdmin]);

  const handleJoinResponse = async (request: any, accept: boolean) => {
    try {
      if (accept) {
        await updateDoc(doc(db, 'groups', request.groupId), {
          members: arrayUnion(request.fromId),
          exMembers: arrayRemove(request.fromId)
        });
        const gDoc = await getDoc(doc(db, 'groups', request.groupId));
        if (gDoc.exists() && gDoc.data()[`leftAt_${request.fromId.replace(/\./g, "_")}`]) {
           await updateDoc(doc(db, 'groups', request.groupId), {
             [`leftAt_${request.fromId.replace(/\./g, "_")}`]: deleteField()
           });
        }
      }
      // Mark notification as read or delete it
      await updateDoc(doc(db, 'notifications', request.id), { read: true });
      alert(accept ? (t("chat.memberAccepted") || "Accepted") : (t("chat.memberRejected") || "Rejected"));
    } catch (e) {
      console.error(e);
      alert(t("common.error"));
    }
  };

  const kickMember = async (memberId: string, memberName: string) => {
    if (!activeChat || !isMeAdmin) return;
    await updateDoc(doc(db, 'groups', activeChat.id), {
      members: arrayRemove(memberId),
      admins: arrayRemove(memberId),
      exMembers: arrayUnion(memberId),
      [`leftAt_${memberId.replace(/\./g, "_")}`]: serverTimestamp()
    });
    await sendSystemMessage(`${user.UserData} ${t("chat.memberKicked")} ${memberName}`, activeChat.id);
  };

  const makeAdmin = async (memberId: string, memberName: string) => {
    if (!activeChat || !isMeAdmin) return;
    await updateDoc(doc(db, 'groups', activeChat.id), {
      admins: arrayUnion(memberId)
    });
    await sendSystemMessage(`${user.UserData} ${t("chat.memberMadeAdmin")} ${memberName}`, activeChat.id);
  };

  const addMember = async (targetUser: User) => {
    if (!activeChat || !isMeAdmin) return;
    await updateDoc(doc(db, 'groups', activeChat.id), {
      members: arrayUnion(targetUser.Id_user),
      exMembers: arrayRemove(targetUser.Id_user)
    });
    const gDoc = await getDoc(doc(db, 'groups', activeChat.id));
    if (gDoc.exists() && gDoc.data()[`leftAt_${targetUser.Id_user.replace(/\./g, "_")}`]) {
       await updateDoc(doc(db, 'groups', activeChat.id), {
         [`leftAt_${targetUser.Id_user.replace(/\./g, "_")}`]: deleteField()
       });
    }
    await sendSystemMessage(`${user.UserData} ${t("chat.memberAdded")} ${targetUser.UserData}`, activeChat.id);
  };

  const leaveGroup = async () => {
    if (!activeChat || !activeChat.isGroup) return;
    await updateDoc(doc(db, 'groups', activeChat.id), {
      members: arrayRemove(user.Id_user),
      admins: arrayRemove(user.Id_user),
      exMembers: arrayUnion(user.Id_user),
      [`leftAt_${user.Id_user.replace(/\./g, "_")}`]: serverTimestamp()
    });
    await sendSystemMessage(`${user.UserData} ${t("chat.memberLeft")}`, activeChat.id);
    setMode('inbox');
  };

  const changeGroupName = async (newName: string) => {
    if (!activeChat || !isMeAdmin || !newName.trim()) return;
    await updateDoc(doc(db, 'groups', activeChat.id), { name: newName });
    await sendSystemMessage(`${user.UserData} ${t("chat.groupRenamed")} ${newName}`, activeChat.id);
  };

  const [pendingGroupCropFile, setPendingGroupCropFile] = useState<File | null>(null);

  const uploadCroppedGroupPhoto = async (croppedFile: File) => {
    if (!activeChat || !isMeAdmin) return;
    setPendingGroupCropFile(null);
    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', croppedFile);
      formData.append('upload_preset', UPLOAD_PRESET);
      const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (data.secure_url) {
        await updateDoc(doc(db, 'groups', activeChat.id), { photo: data.secure_url });
        await sendSystemMessage(`${user.UserData} ${t("chat.groupIconChanged")}`, activeChat.id);
      }
    } catch (err) {
      console.error("Upload failed", err);
    } finally {
      setIsUploading(false);
    }
  };

  const changeGroupPhoto = async () => {
    if (!activeChat || !isMeAdmin) return;
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      setPendingGroupCropFile(file);
    };
    input.click();
  };

  const handleInboxSearch = async () => {
    if (!inboxSearchTerm.trim()) {
      setInboxSearchResults({chats: [], messages: [], groups: []});
      return;
    }
    setInboxSearchLoading(true);
    try {
      const searchLower = inboxSearchTerm.toLowerCase();
      
      // Search Chats (Previews)
      const chats = previews.filter(p => p.name.toLowerCase().includes(searchLower));
      
      // Search Messages
      const mQ = query(collection(db, 'messages'), limit(200));
      const mSnap = await getDocs(mQ);
      const msgs = mSnap.docs
        .map(d => { const data = d.data() as any; return { id: d.id, ...data, text: decryptText(data.text || "") }; })
        .filter(m => 
          (m.senderId === user.Id_user || m.receiverId === user.Id_user || m.groupId) &&
          m.text?.toLowerCase().includes(searchLower)
        );
        
      // Search Groups
      const gQ = query(collection(db, 'groups'), limit(100));
      const gSnap = await getDocs(gQ);
      const groups = gSnap.docs
        .map(d => { const data = d.data() as any; return { id: d.id, ...data, text: decryptText(data.text || "") }; })
        .filter(g => g.name?.toLowerCase().includes(searchLower));
        
      setInboxSearchResults({chats, messages: msgs, groups});
    } catch (e) {
      console.error(e);
    } finally {
      setInboxSearchLoading(false);
    }
  };

  useEffect(() => {
    if (mode === 'inboxSearch') {
      handleInboxSearch();
    }
  }, [inboxSearchTerm, inboxSearchActiveTab, mode]);


  const checkMute = (): boolean => {
    if (isCurrentUserMessagingRestricted) {
      alert(t("chat.messagingRestrictedAlert"));
      return true;
    }
    if (isTargetPermanentlyBanned) {
      alert(t("chat.cannotSendToRestrictedAlert"));
      return true;
    }
    if (isChatBlocked) {
      return true;
    }
    return false;
  };

  const sendMessage = async () => {
    if (checkMute()) return;
    const textToSend = inputMessage.trim() || quickEmoji;
    if (!textToSend && !isUploading) return;
    
    // Check if user is still a member if it's a group
    if (activeChat.isGroup) {
      const groupSnap = await doc(db, 'groups', activeChat.id);
      // We'll check this in the UI too, but for safety:
    }

    setInputMessage("");
    soundManager.playSendSound();
    try {
      const aiChatId = `ai_${user.Id_user}`;
      const isAIChat = activeChat.isAI || activeChat.id === 'ai' || activeChat.id === aiChatId || activeChat.name === 'TeBLOCK AI';
      const targetId = isAIChat ? aiChatId : activeChat.id;
      
      if (editingMessage) {
        await updateDoc(doc(db, 'messages', editingMessage.id), {
          text: encryptText(textToSend),
          edited: true,
          editedAt: serverTimestamp()
        });
        setEditingMessage(null);
        return;
      }
      
      const messageData: any = {
        senderId: user.Id_user, 
        senderName: user.UserData, 
        senderPhoto: user.photoURL || "",
        text: encryptText(textToSend), 
        timestamp: serverTimestamp(),
      };

      if (replyingTo) {
        messageData.replyToId = replyingTo.id;
        messageData.replyToText = encryptText(replyingTo.text || "");
        messageData.replyToSender = replyingTo.senderName;
        setReplyingTo(null);
      }

      if (activeChat.isGroup) {
        messageData.groupId = activeChat.id;
        messageData.readBy = [user.Id_user];
      } else {
        messageData.receiverId = targetId;
        messageData.receiverName = isAIChat ? "TeBLOCK AI" : activeChat.name;
        messageData.receiverPhoto = isAIChat ? "https://api.dicebear.com/7.x/bottts/svg?seed=ai" : (activeChat.photo || "");
        messageData.read = isAIChat;
      }

      // Optimistically show user message immediately at bottom of chat
      const optimisticMsg: any = {
        id: `optimistic_${Date.now()}`,
        ...messageData,
        text: textToSend,
        timestamp: { seconds: Math.floor(Date.now() / 1000) }
      };
      setMessages(prev => [...prev, optimisticMsg]);

      await addDoc(collection(db, 'messages'), messageData);
      
      // AI Response Logic
      if (isAIChat) {
        setIsTyping(true);
        const history = messages.slice(-10).map(m => ({
          role: (m.senderId === user.Id_user ? 'user' : 'model') as 'user' | 'model',
          text: m.text || ""
        }));
        const aiResponse = await getSmartResponse(textToSend, user.UserData, history);
        await addDoc(collection(db, 'messages'), {
          senderId: aiChatId, senderName: "TeBLOCK AI", senderPhoto: "https://api.dicebear.com/7.x/bottts/svg?seed=ai",
          receiverId: user.Id_user, receiverName: user.UserData, receiverPhoto: user.photoURL || "",
          text: encryptText(aiResponse), timestamp: serverTimestamp(), read: true
        });
        setIsTyping(false);
      } else if (/@TeBLOCK AI|@ai\b/i.test(textToSend)) {
        // AI Response in Groups or Private Chats when tagged — review recent messages for topic & tone
        setIsTyping(true);
        const recentHistory = messages.slice(-12).map(m => ({
          role: ((m.senderName === 'TeBLOCK AI' || m.senderId === aiChatId || m.senderId === 'ai') ? 'model' : 'user') as 'user' | 'model',
          text: `${m.senderName || 'مستخدم'}: ${m.text || ''}`
        }));
        const cleanedPrompt = textToSend.replace(/@TeBLOCK AI/gi, '').replace(/@ai\b/gi, '').trim() || textToSend;
        const aiResponse = await getSmartResponse(cleanedPrompt, user.UserData, recentHistory);
        const botMsg: any = {
          senderId: aiChatId,
          senderName: "TeBLOCK AI",
          senderPhoto: "https://api.dicebear.com/7.x/bottts/svg?seed=ai",
          text: encryptText(aiResponse),
          timestamp: serverTimestamp()
        };
        
        if (activeChat.isGroup) {
          botMsg.groupId = activeChat.id;
          botMsg.readBy = [aiChatId];
        } else {
          botMsg.isPrivateAIReply = true;
          botMsg.aiContextUserId = user.Id_user;
          botMsg.receiverId = activeChat.id;
          botMsg.receiverName = activeChat.name || "";
          botMsg.receiverPhoto = activeChat.photo || "";
          botMsg.read = false;
        }
        
        await addDoc(collection(db, 'messages'), botMsg);
        setIsTyping(false);
      }
    } catch (e) { console.error(e); setInputMessage(textToSend === quickEmoji ? "" : textToSend); }
  };

  const handleReaction = async (msgId: string, emoji: string) => {
    const msg = messages.find(m => m.id === msgId);
    if (!msg) return;
    const reactions = msg.reactions || {};
    reactions[user.Id_user.replace(/\./g, "_")] = emoji;
    await updateDoc(doc(db, 'messages', msgId), { reactions });
    setContextMenu(null);
  };

  const handleLongPress = (e: any, msg: any) => {
    if (msg.isSystem) return;
    e.preventDefault();
    const touch = e.touches ? e.touches[0] : e;
    soundManager.playLongPressSound();

    setContextMenu({ x: touch.clientX, y: touch.clientY, message: msg });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (checkMute()) return;
    const file = e.target.files?.[0];
    if (!file || !activeChat) return;

    setIsUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', UPLOAD_PRESET);

    try {
      const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      
      if (!data.secure_url) {
        throw new Error(data.error?.message || "Cloudinary upload failed - no secure_url");
      }

      const aiChatId = `ai_${user.Id_user}`;
      const isAIChat = activeChat.isAI || activeChat.id === 'ai' || activeChat.id === aiChatId || activeChat.name === 'TeBLOCK AI';
      const targetId = isAIChat ? aiChatId : activeChat.id;
      
      const messageData: any = {
        senderId: user.Id_user, senderName: user.UserData, senderPhoto: user.photoURL || "",
        text: "", imageUrl: data.secure_url, timestamp: serverTimestamp(),
      };

      if (activeChat.isGroup) {
        messageData.groupId = activeChat.id;
        messageData.readBy = [user.Id_user];
      } else {
        messageData.receiverId = targetId;
        messageData.receiverName = activeChat.name;
        messageData.receiverPhoto = activeChat.photo || "";
        messageData.read = !!activeChat.isAI;
      }

      await addDoc(collection(db, 'messages'), messageData);
    } catch (err) {
      console.error("Upload failed", err);
    } finally {
      setIsUploading(false);
      setShowPlusMenu(false);
    }
  };

  const startRecording = async () => {
    if (checkMute()) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder.current = new MediaRecorder(stream);
      audioChunks.current = [];
      
      // Volume Analysis
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const analyser = audioContext.createAnalyser();
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);
      analyser.fftSize = 256;
      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      
      const updateVolume = () => {
        if (!mediaRecorder.current || mediaRecorder.current.state === 'inactive') return;
        analyser.getByteFrequencyData(dataArray);
        const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
        setRecordingVolume(average);
        requestAnimationFrame(updateVolume);
      };
      updateVolume();

      mediaRecorder.current.ondataavailable = (e) => {
        if (audioChunks.current) {
          audioChunks.current.push(e.data);
        }
      };
      mediaRecorder.current.onstop = async () => {
        const audioBlob = new Blob(audioChunks.current, { type: 'audio/webm' });
        const formData = new FormData();
        formData.append('file', audioBlob);
        formData.append('upload_preset', UPLOAD_PRESET);
        
        setIsUploading(true);
        try {
          const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/auto/upload`, {
            method: 'POST',
            body: formData
          });
          const data = await res.json();
          
          if (!data.secure_url) {
            throw new Error(data.error?.message || "Cloudinary upload failed - no secure_url");
          }

          const aiChatId = `ai_${user.Id_user}`;
          const isAIChat = activeChat.isAI || activeChat.id === 'ai' || activeChat.id === aiChatId || activeChat.name === 'TeBLOCK AI';
          const targetId = isAIChat ? aiChatId : activeChat.id;
          
          const messageData: any = {
            senderId: user.Id_user, senderName: user.UserData, senderPhoto: user.photoURL || "",
            text: "", voiceUrl: data.secure_url, timestamp: serverTimestamp(),
          };

          if (activeChat.isGroup) {
            messageData.groupId = activeChat.id;
            messageData.readBy = [user.Id_user];
          } else {
            messageData.receiverId = targetId;
            messageData.receiverName = isAIChat ? "TeBLOCK AI" : activeChat.name;
            messageData.receiverPhoto = isAIChat ? "https://api.dicebear.com/7.x/bottts/svg?seed=ai" : (activeChat.photo || "");
            messageData.read = isAIChat;
          }

          await addDoc(collection(db, 'messages'), messageData);
        } catch (e) {
          console.error("Voice upload failed", e);
        } finally {
          setIsUploading(false);
        }
      };
      mediaRecorder.current.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Mic access denied", err);
      alert(t("chat.micAccessRequired"));
    }
  };

  const cancelRecording = () => {
    if (mediaRecorder.current && mediaRecorder.current.state !== 'inactive') {
      mediaRecorder.current.onstop = null; // Prevent sending
      mediaRecorder.current.stop();
      mediaRecorder.current.stream.getTracks().forEach(track => track.stop());
    }
    setIsRecording(false);
    setRecordingVolume(0);
  };

  const handleGifSelect = async (gifUrl: string) => {
    if (!activeChat) return;
    try {
      const aiChatId = `ai_${user.Id_user}`;
      const isAIChat = activeChat.isAI || activeChat.id === 'ai' || activeChat.id === aiChatId || activeChat.name === 'TeBLOCK AI';
      const targetId = isAIChat ? aiChatId : activeChat.id;
      
      const messageData: any = {
        senderId: user.Id_user, senderName: user.UserData, senderPhoto: user.photoURL || "",
        text: "", imageUrl: gifUrl, timestamp: serverTimestamp(),
      };

      if (activeChat.isGroup) {
        messageData.groupId = activeChat.id;
        messageData.readBy = [user.Id_user];
      } else {
        messageData.receiverId = targetId;
        messageData.receiverName = isAIChat ? "TeBLOCK AI" : activeChat.name;
        messageData.receiverPhoto = isAIChat ? "https://api.dicebear.com/7.x/bottts/svg?seed=ai" : (activeChat.photo || "");
        messageData.read = isAIChat;
      }

      await addDoc(collection(db, 'messages'), messageData);
      setShowGifPicker(false);
      setShowPlusMenu(false);
    } catch (err) {
      console.error("GIF send failed", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder.current && mediaRecorder.current.state !== 'inactive') {
      mediaRecorder.current.stop();
      mediaRecorder.current.stream.getTracks().forEach(track => track.stop());
    }
    setIsRecording(false);
    setShowPlusMenu(false);
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-[var(--teblock-bg)] h-full overflow-hidden relative" onContextMenu={(e) => e.preventDefault()}>
      {mode === 'inboxSearch' && (
        <div className="fixed inset-0 z-[400] bg-black flex flex-col animate-in fade-in duration-300">
          {/* HEADER */}
          <div className="glass border-b border-white/5 pt-6">
            <div className="px-6 mb-4 flex items-center">
              <button onClick={() => setMode('inbox')} className="ml-4 p-2 text-slate-500">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7" strokeWidth={3}/></svg>
              </button>
              <div className="flex-1 relative">
                <input 
                  autoFocus
                  type="text" 
                  placeholder={
                    inboxSearchActiveTab === 'chats' ? t('chat.searchInChats') :
                    inboxSearchActiveTab === 'messages' ? t('chat.searchInMessages') : t('chat.searchInGroups')
                  }
                  value={inboxSearchTerm || ""}
                  onChange={(e) => setInboxSearchTerm(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-12 py-4 text-xs font-bold text-white outline-none focus:ring-2 focus:ring-blue-600 transition-all text-right"
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" strokeWidth={3}/></svg>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-around px-4 pb-2">
              {[
                {id: 'chats', label: t('chat.tabChats')},
                {id: 'messages', label: t('chat.tabMessages')},
                {id: 'groups', label: t('chat.tabGroups')}
              ].map(tab => (
                <button 
                  key={tab.id} 
                  onClick={() => setInboxSearchActiveTab(tab.id as any)}
                  className={`pb-2 px-2 text-[10px] font-black uppercase tracking-widest transition-all relative ${inboxSearchActiveTab === tab.id ? 'text-blue-500' : 'text-slate-500 opacity-40'}`}
                >
                  {tab.label}
                  {inboxSearchActiveTab === tab.id && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500 rounded-full" />}
                </button>
              ))}
            </div>
          </div>

          {/* RESULTS */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
            {inboxSearchLoading ? (
              <div className="h-full flex items-center justify-center">
                <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : (
              <>
                {inboxSearchActiveTab === 'chats' && inboxSearchResults.chats.map(chat => (
                  <div key={chat.id} onClick={() => { setActiveChat(chat); setMode('activeChat'); }} className="flex items-center p-4 bg-white/5 rounded-[2rem] border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                    <img src={chat.photo || `https://api.dicebear.com/7.x/bottts/svg?seed=${chat.id}`} className="w-12 h-12 rounded-2xl ml-4" />
                    <div className="text-right flex-1">
                      <h4 className="text-sm font-black text-white">{chat.name}</h4>
                      <p className="text-[10px] text-slate-500 truncate">{chat.lastMessage}</p>
                    </div>
                  </div>
                ))}

                {inboxSearchActiveTab === 'messages' && inboxSearchResults.messages.map((m, i) => (
                  <div key={i} onClick={() => { 
                    const chat = previews.find(p => p.id === (m.groupId || (m.senderId === user.Id_user ? m.receiverId : m.senderId)));
                    if (chat) { setActiveChat(chat); setMode('activeChat'); }
                  }} className="p-4 bg-white/5 rounded-3xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[8px] text-slate-500">{m.timestamp?.toDate().toLocaleString()}</span>
                      <span className="text-[10px] font-black text-blue-500">{m.senderName}</span>
                    </div>
                    <p className="text-xs text-white leading-relaxed text-right truncate" dir="auto">{m.text}</p>
                  </div>
                ))}

                {inboxSearchActiveTab === 'groups' && inboxSearchResults.groups.map(group => {
                  const isMember = group.members?.includes(user.Id_user);
                  return (
                  <div key={group.id} onClick={() => { if(isMember) { setActiveChat({...group, isGroup: true}); setMode('activeChat'); } }} className="flex items-center p-4 bg-white/5 rounded-[2rem] border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                    <img src={group.photo || `https://api.dicebear.com/7.x/bottts/svg?seed=${group.id}`} className="w-12 h-12 rounded-2xl ml-4" />
                    <div className="text-right flex-1">
                      <h4 className="text-sm font-black text-white">{group.name}</h4>
                      <p className="text-[10px] text-slate-500">{group.members?.length || 0} {t("chat.memberCount")}</p>
                    </div>
                    {!isMember && (
                      <button onClick={async (e) => {
                        e.stopPropagation();
                        try {
                           await addDoc(collection(db, 'notifications'), {
                             type: 'group_join_request',
                             groupId: group.id,
                             fromId: user.Id_user,
                             fromName: user.UserData,
                             fromPhoto: user.photoURL || "",
                             read: false,
                             createdAt: serverTimestamp()
                           });
                           alert(t("chat.joinRequestSent"));
                        } catch (err) {
                           alert(t("common.error"));
                        }
                      }} className="px-4 py-2 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase hover:bg-blue-500 transition-colors shadow-lg shadow-blue-500/20">
                        {t('chat.joinBtn')}
                      </button>
                    )}
                  </div>
                )})}

                {inboxSearchTerm && !inboxSearchLoading && inboxSearchResults[inboxSearchActiveTab].length === 0 && (
                  <div className="text-center py-20 opacity-20">
                    <p className="text-xs font-black uppercase tracking-widest">{t("chat.noResults")}</p>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {mode === 'friends' && (
        <div className="fixed inset-0 z-[300] bg-black/95 backdrop-blur-2xl flex flex-col animate-in slide-in-from-right duration-500">
          <div className="p-7 border-b border-white/5 flex items-center justify-between sticky top-0 bg-black/50 backdrop-blur-xl z-50">
            <button onClick={() => setMode('inbox')} className="p-2 text-slate-500"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5" strokeWidth={3}/></svg></button>
            <h2 className="text-sm font-black text-white uppercase tracking-[0.3em]">{t("chat.friendsHeader")}</h2>
            <button onClick={() => setMode('createGroup')} className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-600/20">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-5M3 4h5V-1" /></svg>
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {/* Gemini AI Option */}
            <div onClick={() => {
              const aiChat = previews.find(p => p.isAI);
              if (aiChat) {
                setActiveChat(aiChat);
              } else {
                setActiveChat({ 
                  id: `ai_${user.Id_user}`, 
                  name: "TeBLOCK AI", 
                  photo: "https://api.dicebear.com/7.x/bottts/svg?seed=ai", 
                  isAI: true,
                  isGroup: false 
                });
              }
              setMode('activeChat');
            }} className="flex items-center p-4 bg-blue-600/10 border border-blue-500/20 rounded-[2.2rem] hover:bg-blue-600/20 transition-all cursor-pointer mb-4">
              <div className="relative">
                <img src="https://api.dicebear.com/7.x/bottts/svg?seed=ai" className="w-12 h-12 rounded-2xl border border-blue-500/30 bg-blue-500/10" />
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-black rounded-full"></div>
              </div>
              <div className="flex-1 mr-4">
                <div className="flex items-center">
                  <h4 className="text-sm font-black text-blue-400">TeBLOCK AI</h4>
                  <span className="mr-2 text-[7px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded-full font-black uppercase tracking-widest">Bot</span>
                </div>
                <p className="text-[10px] text-slate-400 font-bold">{t("chat.aiAssistantTitle")}</p>
              </div>
            </div>

            {friends.map(friend => (
              <div key={friend.Id_user} onClick={() => {
                const existingChat = previews.find(p => !p.isGroup && p.id === friend.Id_user);
                if (existingChat) {
                  setActiveChat(existingChat);
                } else {
                  setActiveChat({ id: friend.Id_user, name: friend.UserData, photo: friend.photoURL, isGroup: false });
                }
                setMode('activeChat');
              }} className="flex items-center p-4 bg-white/[0.02] border border-white/5 rounded-[2.2rem] hover:bg-white/[0.05] transition-all cursor-pointer">
                <img src={friend.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${friend.Id_user}`} className="w-12 h-12 rounded-2xl border border-white/10" />
                <div className="flex-1 mr-4">
                  <h4 className="text-sm font-bold text-white">{friend.UserData}</h4>
                  <p className="text-xs text-slate-500">@{friend.Id_user}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Split screen layout for Tablet / Desktop and single screen on Mobile */}
      <div className="flex-1 min-h-0 flex flex-row h-full w-full overflow-hidden relative">

        {/* Panel 1: Conversation Selection List (شاشة اختيار المحادثة) */}
        <div className={`
          ${mode === 'activeChat' ? 'hidden md:flex' : 'flex'}
          w-full md:w-80 lg:w-[360px] xl:w-[400px] shrink-0 rtl:border-l ltr:border-r border-white/10 flex-col h-full bg-[#050914] relative z-10 overflow-hidden min-h-0
        `}>
          <div className="p-2.5 sm:p-3 glass border-b border-white/5 flex items-center space-x-2 space-x-reverse shrink-0">
            <div 
              onClick={() => setMode('inboxSearch')}
              className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3.5 py-2 text-[11px] font-bold text-slate-500 cursor-pointer hover:border-blue-500/50 transition-all rtl:text-right ltr:text-left"
            >
              {t('chat.searchGeneralPlaceholder')}
            </div>
            {serverStatus?.status === 'online' && (
              <div className="flex items-center bg-blue-600/10 border border-blue-500/20 px-2.5 py-1.5 rounded-xl animate-in fade-in duration-500">
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse ml-1.5"></div>
                <span className="text-[8px] font-black text-blue-400 uppercase tracking-tighter">Server Live</span>
              </div>
            )}
          </div>
          <NotesSystem 
            user={user} 
            friends={friends}
            onlineUsers={onlineUsers}
            onNavigateChat={(userId, userName, userPhoto) => {
              const existingChat = previews.find(p => !p.isGroup && p.id === userId);
              if (existingChat) {
                setActiveChat(existingChat);
              } else {
                setActiveChat({ id: userId, name: userName, photo: userPhoto, isGroup: false });
              }
              setMode('activeChat');
            }} 
          />
          <div className="flex-1 overflow-y-auto p-2 sm:p-2.5 space-y-1.5 custom-scrollbar pb-24">
            {/* Floating Action Button - Compact */}
            <div className="fixed bottom-20 left-4 z-50 flex flex-col items-center">
              {showFabMenu && (
                <div className="flex flex-col items-center space-y-2 mb-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
                  {/* AI Chat Button */}
                  <button 
                    onClick={() => {
                      const aiChat = previews.find(p => p.isAI);
                      if (aiChat) {
                        setActiveChat(aiChat);
                      } else {
                        setActiveChat({ 
                          id: `ai_${user.Id_user}`, 
                          name: "TeBLOCK AI", 
                          photo: "https://api.dicebear.com/7.x/bottts/svg?seed=ai", 
                          isAI: true, 
                          isGroup: false 
                        });
                      }
                      setMode('activeChat');
                      setShowFabMenu(false);
                    }} 
                    className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center text-white shadow-md hover:bg-slate-600 transition-colors"
                    title={t("chat.botChatTitle")}
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                  </button>
                  {/* Friends Button */}
                  <button 
                    onClick={() => { setMode('friends'); setShowFabMenu(false); }} 
                    className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center text-white shadow-md hover:bg-slate-600 transition-colors"
                    title={t("chat.friendsHeader")}
                  >
                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                  </button>
                </div>
              )}
              <button onClick={() => setShowFabMenu(!showFabMenu)} className={`w-11 h-11 sm:w-12 sm:h-12 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-md transform transition-transform duration-200 ${showFabMenu ? 'rotate-45' : ''}`}>
                <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={3} /></svg>
              </button>
            </div>

             {previews.map((chat, index) => (
               <React.Fragment key={chat.id}>
                 <div 
                    onClick={() => { setActiveChat(chat); setMode('activeChat'); }}
                    onContextMenu={(e) => { e.preventDefault(); toggleManualUnread(chat.id); }}
                    className={`flex items-center p-2.5 rounded-xl border transition-all cursor-pointer ${activeChat?.id === chat.id ? 'bg-blue-600/15 border-blue-500/40 shadow-sm border-r-3 border-r-blue-500' : 'bg-white/[0.02] border-white/5 hover:bg-white/[0.05] hover:border-white/10 active:scale-[0.99]'} ${chat.manualUnread ? 'border-blue-500/50 bg-blue-500/5' : ''}`}>
                  <div className="relative ml-2.5 shrink-0">
                    <img src={chat.photo || `https://api.dicebear.com/7.x/bottts/svg?seed=${chat.id}`} className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl border border-white/10 object-cover" />
                  </div>
                  <div className="flex-1 text-right overflow-hidden min-w-0">
                     <div className="flex justify-between items-center mb-0.5">
                        <span className="text-[7.5px] text-slate-500 font-bold">{chat.timestamp ? new Date(chat.timestamp.seconds * 1000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : t('chat.now')}</span>
                        <h4 className="text-[11px] font-black text-white truncate">{chat.name}</h4>
                     </div>
                     <p className="text-[10px] text-slate-400 truncate font-medium">{chat.lastMessage}</p>
                  </div>
                  {(chat.unreadCount > 0 || chat.manualUnread) && (
                    <div className={`mr-2 w-4 h-4 sm:w-4.5 sm:h-4.5 ${chat.isTagged ? 'bg-green-500' : 'bg-blue-600'} rounded-full flex items-center justify-center text-[8px] font-black text-white shadow-md animate-pulse shrink-0`}>
                      {chat.unreadCount || ""}
                    </div>
                  )}
                 </div>

               </React.Fragment>
             ))}
          </div>
        </div>

        {/* Panel 2: Active Chat / Desktop Empty State (شاشة المحادثة) */}
        <div className={`
          ${mode === 'activeChat' && activeChat ? 'flex' : 'hidden md:flex'}
          flex-1 min-h-0 flex-col h-full relative overflow-hidden bg-black/60 min-w-0
        `}>
          {activeChat ? (
<div className="flex-1 min-h-0 flex flex-col h-full bg-black relative animate-in fade-in duration-200 overflow-hidden">
           {/* طبقة السمة (خلفية المحادثة) */}
           <div className="absolute inset-0 z-0 opacity-50 pointer-events-none">
              {currentChatTheme.bg && <img src={currentChatTheme.bg} className="w-full h-full object-cover brightness-[0.7]" />}
           </div>

            <div className={`px-3 py-2.5 sm:px-5 sm:py-3.5 ${currentChatTheme.id !== 'none' ? 'bg-black/30 backdrop-blur-xl' : 'glass'} border-b border-white/5 flex items-center justify-between z-20 shrink-0 transition-colors duration-500`}>
              <div className="flex items-center flex-1">
                 <button onClick={() => { setMode('inbox'); setIsSearchingChat(false); setChatSearchTerm(""); }} className="rtl:ml-2 rtl:sm:ml-4 ltr:mr-2 ltr:sm:mr-4 p-2 text-slate-400 hover:text-white transition-colors md:hidden shrink-0" title={t("common.back")}><svg className="w-6 h-6 transform rtl:rotate-180 ltr:rotate-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7"/></svg></button>
                 <button onClick={() => { setActiveChat(null); setMode('inbox'); }} className="hidden md:flex rtl:ml-2 ltr:mr-2 p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all shrink-0" title={t("common.close")}><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg></button>
                 
                 {isSearchingChat ? (
                   <div className="flex-1 flex items-center bg-white/5 rounded-2xl px-4 py-2 border border-white/10 animate-in slide-in-from-left duration-300">
                     <input 
                       autoFocus
                       type="text" 
                       value={chatSearchTerm || ""}
                       onChange={(e) => setChatSearchTerm(e.target.value)}
                       placeholder={t("chat.searchInMessages")}
                       className="bg-transparent border-none outline-none text-xs font-bold text-white w-full rtl:text-right ltr:text-left"
                     />
                     <button onClick={() => { setIsSearchingChat(false); setChatSearchTerm(""); }} className="mr-2 text-slate-500">
                       <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
                     </button>
                   </div>
                 ) : (
                   <>
                     <img 
                        src={activeChat.photo || undefined} 
                        onClick={() => {
                          if (!activeChat.isAI && !activeChat.isGroup) {
                            onNavigateProfile?.(activeChat.id);
                          }
                        }} 
                        className={`w-10 h-10 rounded-xl ml-3 border border-white/10 transition-transform ${(!activeChat.isAI && !activeChat.isGroup) ? 'cursor-pointer hover:scale-105' : ''}`} 
                      />
                      <div className="text-right">
                         <h4 className="text-[11px] font-black text-white">{nicknames[(activeChat.id || "").replace(/\./g, "_")] || activeChat.name}</h4>
                         <div className="flex items-center space-x-1 space-x-reverse">
                            <span className="text-[8px] text-green-500 font-bold uppercase tracking-widest">
                               {activeChat.isGroup ? `${activeChat.members?.length || 0} ${t("chat.memberCount")}` : (
                                 onlineUsers[activeChat.id]?.status === 'online' ? t('chat.onlineNow') : `${t('chat.lastSeen')} ${new Date(onlineUsers[activeChat.id]?.lastSeen || Date.now()).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`
                               )}
                            </span>
                            {serverStatus?.status === 'online' && (
                              <div className="flex items-center">
                                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse ml-1"></div>
                                <span className="text-[7px] text-blue-400 font-black uppercase">{t("chat.serverConnected")}</span>
                              </div>
                            )}
                         </div>
                      </div>
                   </>
                 )}
              </div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <button 
                  onClick={() => setIsSearchingChat(!isSearchingChat)}
                  className={`p-2 transition-colors ${isSearchingChat ? 'text-blue-500' : 'text-slate-500 hover:text-blue-500'}`}
                >
                   <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" strokeWidth={2.5}/></svg>
                </button>
                {!activeChat.isAI && (
                  <button 
                    onClick={() => joinCall()}
                    className="p-1.5 text-slate-400 hover:text-green-500 transition-colors"
                    title={t("chat.p2pCallTooltip")}
                  >
                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                  </button>
                )}
                <button onClick={() => setMode('chatSettings')} className="p-1.5 text-slate-500 hover:text-blue-500 transition-colors">
                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                   </svg>
                </button>
              </div>
            </div>

           <div ref={messagesContainerRef} className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden p-3 sm:p-4 custom-scrollbar pb-6 flex flex-col z-10 relative">
              {(() => {
                const displayedMessages = messages.filter(m => !chatSearchTerm || m.text?.toLowerCase().includes(chatSearchTerm.toLowerCase()));

                // 1. Calculate overall last read message index
                let lastReadMessageIndex = -1;
                for (let idx = displayedMessages.length - 1; idx >= 0; idx--) {
                  const msg = displayedMessages[idx];
                  if (msg.isSystem) continue;
                  if (activeChat.isGroup) {
                    if (msg.readBy && msg.readBy.some((uid: string) => uid !== user.Id_user)) {
                      lastReadMessageIndex = idx;
                      break;
                    }
                  } else {
                    if (msg.read) {
                      lastReadMessageIndex = idx;
                      break;
                    }
                  }
                }

                // 2. In 1-on-1, calculate last message sent by me that was read by the other party
                let lastReadMyMessageIndex = -1;
                if (!activeChat.isGroup) {
                  for (let idx = displayedMessages.length - 1; idx >= 0; idx--) {
                    const msg = displayedMessages[idx];
                    if (!msg.isSystem && msg.senderId === user.Id_user && msg.read) {
                      lastReadMyMessageIndex = idx;
                      break;
                    }
                  }
                }

                // 3. In group, calculate last read message index per member
                const lastReadIndexPerMember: Record<string, number> = {};
                if (activeChat.isGroup) {
                  for (let idx = displayedMessages.length - 1; idx >= 0; idx--) {
                    const msg = displayedMessages[idx];
                    if (msg.isSystem) continue;
                    if (msg.readBy && Array.isArray(msg.readBy)) {
                      for (const uid of msg.readBy) {
                        if (uid !== user.Id_user && lastReadIndexPerMember[uid] === undefined) {
                          lastReadIndexPerMember[uid] = idx;
                        }
                      }
                    }
                  }
                }

                return displayedMessages.map((m, i) => {
                  if (m.isSystem) {
                    return (
                      <div key={m.id || i} className="flex justify-center my-2 sm:my-3">
                         <span className="text-[10px] font-black text-slate-500/80 uppercase tracking-[0.2em] text-center px-6">{m.text}</span>
                      </div>
                    );
                  }
                  const isMe = m.senderId === user.Id_user;
                  const emojiOnly = m.text && isOnlyEmojis(m.text);
                  const emojiCount = emojiOnly ? getEmojiCount(m.text) : 0;
                  const isBigEmoji = emojiOnly && emojiCount <= 3;

                  // Grouping with adjacent messages from the same sender
                  const prevMsg = i > 0 ? displayedMessages[i - 1] : null;
                  const nextMsg = i < displayedMessages.length - 1 ? displayedMessages[i + 1] : null;
                  const isSameSenderAsPrev = !!prevMsg && !prevMsg.isSystem && prevMsg.senderId === m.senderId;
                  const isSameSenderAsNext = !!nextMsg && !nextMsg.isSystem && nextMsg.senderId === m.senderId;

                  const getBubbleCorners = () => {
                    if (isMe) {
                      if (!isSameSenderAsPrev && !isSameSenderAsNext) return 'rounded-2xl rounded-tl-none';
                      if (!isSameSenderAsPrev && isSameSenderAsNext) return 'rounded-2xl rounded-tl-none rounded-bl-sm';
                      if (isSameSenderAsPrev && isSameSenderAsNext) return 'rounded-2xl rounded-tl-sm rounded-bl-sm';
                      return 'rounded-2xl rounded-tl-sm';
                    } else {
                      if (!isSameSenderAsPrev && !isSameSenderAsNext) return 'rounded-2xl rounded-tr-none';
                      if (!isSameSenderAsPrev && isSameSenderAsNext) return 'rounded-2xl rounded-tr-none rounded-br-sm';
                      if (isSameSenderAsPrev && isSameSenderAsNext) return 'rounded-2xl rounded-tr-sm rounded-br-sm';
                      return 'rounded-2xl rounded-tr-sm';
                    }
                  };

                  const getStatus = (): 'sending' | 'sent' | 'delivered' | 'read' => {
                    if (!m.timestamp) return 'sending';
                    if (activeChat.isGroup) {
                      if (m.readBy && m.readBy.length > 1) return 'read';
                      return 'sent';
                    } else {
                      if (m.read) return 'read';
                      if (m.delivered) return 'delivered';
                      return 'sent';
                    }
                  };

                  const getReadPhotos = () => {
                    if (activeChat.isGroup) {
                      return activeChat.membersData
                        ?.filter((member: any) => lastReadIndexPerMember[member.Id_user] === i)
                        .map((member: any) => member.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${member.Id_user}`) || [];
                    } else {
                      // Show avatar under the last message that was actually read
                      const isTargetReadMsg = (lastReadMyMessageIndex !== -1 && i === lastReadMyMessageIndex) ||
                                              (lastReadMyMessageIndex === -1 && i === lastReadMessageIndex);
                      if (isTargetReadMsg && activeChat.photo) {
                        return [activeChat.photo];
                      }
                      return [];
                    }
                  };

                  const readPhotos = getReadPhotos();

                return (
                  <div 
                    key={m.id || i} 
                    className={`flex w-full ${isMe ? 'justify-end' : 'justify-start'} ${isSameSenderAsPrev ? 'mt-0.5 sm:mt-1' : (i === 0 ? '' : 'mt-2.5 sm:mt-3')}`} 
                    onContextMenu={(e) => handleLongPress(e, m)}
                  >
                    <SwipeableMessage onReply={() => setReplyingTo(m)} isMe={isMe}>
                      <div className="flex items-end max-w-[88%] sm:max-w-[80%] md:max-w-[75%] min-w-0 relative">
                        {!isMe && (
                          !isSameSenderAsNext ? (
                            <img 
                              src={m.senderPhoto || undefined} 
                              onClick={() => setAvatarMenuTarget({ id: m.senderId, name: m.senderName, photo: m.senderPhoto })}
                              className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg ml-2 border border-white/10 cursor-pointer hover:scale-110 transition-transform shrink-0" 
                              alt={m.senderName || ""}
                            />
                          ) : (
                            <div className="w-7 sm:w-8 ml-2 shrink-0 pointer-events-none" aria-hidden="true" />
                          )
                        )}
                      
                      <div className="flex flex-col items-end">
                        {m.isCallInvite ? (
                          <div className={`p-3.5 rounded-2xl shadow-lg border border-white/5 flex flex-col items-center space-y-2.5 min-w-[190px] ${isMe ? 'bg-blue-600 text-white rounded-tl-none' : 'bg-slate-800 text-slate-200 rounded-tr-none'}`}>
                             <div className={`w-9 h-9 rounded-full flex items-center justify-center ${currentChatCall ? 'bg-emerald-500 animate-pulse' : 'bg-white/10'}`}>
                                <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                             </div>
                             <div className="text-center">
                                <p className="text-[10px] font-black uppercase tracking-wider mb-0.5">
                                  {currentChatCall ? t('chat.p2pCallOngoing') : t('chat.p2pCallEndedDropped')}
                                </p>
                                <p className="text-[8px] opacity-75 font-bold">
                                  {currentChatCall ? t('chat.p2pCallClickJoin') : t('chat.p2pCallEndedDropped')}
                                </p>
                             </div>
                             {currentChatCall && (
                               <button 
                                 onClick={() => joinCall(m.callId || currentChatCall.callId)}
                                 className="w-full bg-white text-blue-600 py-1.5 rounded-lg text-[9px] font-black uppercase hover:scale-105 transition-transform shadow-md"
                               >
                                  {t("chat.p2pJoinNow")}
                                </button>
                             )}
                          </div>
                        ) : (
                          <div className={isBigEmoji ? "relative px-2" : `px-3.5 py-2 sm:px-4 sm:py-2.5 ${getBubbleCorners()} text-[11px] font-bold shadow-md relative ${isMe ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-200'}`}>
                             {m.forwarded && (
                                <p className="text-[8px] text-white/50 italic mb-1 flex items-center">
                                  <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                                  {t("chat.forwardedMsg")}
                                </p>
                             )}
                             {m.replyToId && (
                               <div className="bg-black/20 rounded-xl p-2 mb-2 border-r-4 border-r-blue-400">
                                 <p className="text-[9px] font-black text-blue-300">{m.replyToSender}</p>
                                 <p className="text-[10px] truncate max-w-[200px] text-white/80">{m.replyToText}</p>
                               </div>
                             )}
                             {m.text && (
                               isBigEmoji ? (
                                 <div className="flex items-center space-x-2 space-x-reverse py-1">
                                   {renderEmojiText(m.text, { size: emojiCount === 1 ? 64 : emojiCount === 2 ? 48 : 36 })}
                                   {m.edited && <span className="text-[8px] text-white/50 mr-2 inline-block">{t("chat.editedLabel")}</span>}
                                 </div>
                               ) : (
                                 <p 
                                   dir="auto"
                                   className="whitespace-pre-wrap break-words text-[13px] leading-relaxed"
                                 >
                                   {renderMessageText(m.text)}
                                   {m.edited && <span className="text-[8px] text-white/50 mr-2 inline-block">{t("chat.editedLabel")}</span>}
                                 </p>
                               )
                             )}
                             {m.pinned && (
                               <div className="flex items-center gap-1 text-[9px] font-black text-amber-300/90 mb-1">
                                 <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2z"/></svg>
                                 <span>مثبتة</span>
                               </div>
                             )}
                             {m.imageUrl && !m.reelId && (
                                <div 
                                  onClick={() => setPreviewImage(m.imageUrl)} 
                                  className="mt-2 rounded-2xl overflow-hidden border border-white/10 max-w-full bg-black/40 relative group cursor-pointer"
                                >
                                  <img 
                                    src={m.imageUrl} 
                                    alt={t("chat.photo") || "Photo"}
                                    loading="lazy"
                                    className="w-full max-w-full max-h-[46vh] sm:max-h-[55vh] object-contain rounded-2xl transition-transform duration-200 group-hover:scale-[1.01]" 
                                  />
                                  <div className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                                    <div className="p-2 bg-black/60 rounded-xl backdrop-blur-md text-white shadow-lg">
                                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/></svg>
                                    </div>
                                  </div>
                                </div>
                              )}
                             {m.reelId && (
                               <div 
                                 onClick={() => {
                                   (window as any).navigateToReel?.(m.reelId, true);
                                 }}
                                 className="mt-1.5 relative w-48 sm:w-56 h-72 rounded-2xl overflow-hidden border border-white/15 bg-gradient-to-b from-slate-800 to-slate-950 shadow-xl cursor-pointer group hover:scale-[1.01] transition-transform"
                               >
                                 {(m.reelVideoUrl || m.imageUrl) ? (
                                   <video
                                     src={m.reelVideoUrl || m.imageUrl}
                                     muted
                                     playsInline
                                     preload="metadata"
                                     className="w-full h-full object-cover opacity-85 group-hover:opacity-100 transition-opacity pointer-events-none"
                                   />
                                 ) : (
                                   <div className="w-full h-full bg-gradient-to-br from-blue-900/40 via-slate-900 to-purple-900/40" />
                                 )}
                                 <div className="absolute top-2.5 right-2.5 flex items-center gap-1 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15">
                                   <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                                   <span className="text-[10px] font-black text-white">ريلز</span>
                                 </div>
                                 <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                   <div className="w-12 h-12 bg-black/50 backdrop-blur-md border border-white/25 rounded-full flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                                     <svg className="w-6 h-6 text-white translate-x-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                                   </div>
                                 </div>
                                 <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/90 via-black/50 to-transparent text-right">
                                   {m.reelAuthorName && (
                                     <p className="text-[11px] font-black text-white truncate">{m.reelAuthorName}</p>
                                   )}
                                   <p className="text-[10px] font-bold text-blue-300 mt-0.5">{t("chat.watchReel")}</p>
                                 </div>
                               </div>
                             )}
                             {m.voiceUrl && (
                               <div className="mt-2 flex items-center">
                                 <audio src={m.voiceUrl} controls className="h-8 w-48 opacity-80" />
                                </div>
                             )}
                             {m.reactions && (
                               <div className={`absolute -bottom-2 ${isMe ? 'left-2' : 'right-2'} flex -space-x-1 space-x-reverse`}>
                                 {Object.values(m.reactions).map((emo: any, idx) => (
                                   <span key={idx} className="bg-slate-900 border border-white/10 rounded-full w-5 h-5 flex items-center justify-center p-0.5">
                                     <EmojiImg emoji={emo} size={14} />
                                   </span>
                                 ))}
                               </div>
                             )}
                          </div>
                        )}
                        
                        {readPhotos.length > 0 ? (
                          <div className={`mt-1 ${isMe ? 'mr-2' : 'ml-2'}`}>
                            <MessageStatus status="read" isMe={isMe} readByPhotos={readPhotos} />
                          </div>
                        ) : (
                          isMe && getStatus() !== 'read' && (
                            <div className="mt-1 mr-2">
                              <MessageStatus status={getStatus()} isMe={isMe} />
                            </div>
                          )
                        )}
                      </div>
                    </div>
                    </SwipeableMessage>
                  </div>
                );
              });
            })()}

              {/* Typing & Recording Indicators */}
              {Object.entries(typingStates).map(([uid, state]) => {
                const s = state as { targetId: string, type: 'typing' | 'recording' | null };
                if (s.targetId === activeChat.id && uid !== user.Id_user && s.type) {
                  return (
                    <div key={uid} className="flex justify-start items-center space-x-2 space-x-reverse animate-in fade-in slide-in-from-left duration-300">
                       <img src={`https://api.dicebear.com/7.x/bottts/svg?seed=${uid}`} className="w-6 h-6 rounded-lg opacity-50" />
                       <div className="bg-slate-800/50 px-4 py-2 rounded-2xl flex items-center space-x-2 space-x-reverse">
                          {s.type === 'typing' ? (
                            <div className="flex space-x-1 space-x-reverse">
                              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce"></div>
                            </div>
                          ) : (
                            <div className="flex items-center text-red-500 animate-pulse">
                              <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 20 20"><path d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z"/></svg>
                              <span className="text-[8px] font-black uppercase">{t("chat.recordVoice")}</span>
                            </div>
                          )}
                       </div>
                    </div>
                  );
                }
                return null;
              })}

              <div ref={scrollRef} />
           </div>

           {(replyingTo || editingMessage) && (
              <div className="mx-4 mb-2 p-3 bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl border-r-4 border-r-blue-500 flex justify-between items-center animate-in fade-in duration-200 z-20">
                 <div className="text-right flex-1 overflow-hidden">
                    <p className="text-[10px] font-black text-blue-500 mb-1">
                      {editingMessage ? t('chat.editMsg') : `${t('chat.replyTo')} ${replyingTo?.senderName}`}
                    </p>
                    <p className="text-[10px] text-slate-300 truncate pl-4">
                      {editingMessage ? editingMessage.text : replyingTo?.text}
                    </p>
                 </div>
                 <button onClick={() => { setReplyingTo(null); setEditingMessage(null); setInputMessage(""); }} className="p-2 bg-white/5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white ml-2 shrink-0">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2}/></svg>
                 </button>
              </div>
           )}

            <div className={`p-2 sm:p-2.5 ${currentChatTheme.id !== 'none' ? 'bg-black/30 backdrop-blur-xl' : 'glass'} border-t border-white/5 flex items-center space-x-2 space-x-reverse z-20 shrink-0 relative transition-all duration-300 ${isRecording ? 'bg-slate-900/95 py-4' : ''}`}>
              {isKicked ? (
                <div className="w-full p-4 bg-red-600/10 border border-red-500/20 rounded-2xl text-center">
                  <span className="text-[10px] font-black text-red-500 uppercase tracking-widest">{t("chat.notInGroup")}</span>
                </div>
              ) : isCurrentUserMessagingRestricted ? (
                <div className="w-full p-3 bg-red-950/40 border border-red-500/30 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-right animate-in fade-in">
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <div className="w-9 h-9 rounded-xl bg-red-600/20 text-red-400 flex items-center justify-center shrink-0 border border-red-500/30">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                    </div>
                    <div>
                      <p className="text-xs font-black text-white">{t("chat.inputLockedRestricted")}</p>
                      <p className="text-[10px] text-red-300 font-bold">{getMessagingRestrictionMessage()}</p>
                    </div>
                  </div>
                  {!user.hasAppealed ? (
                    <button 
                      onClick={() => setShowAppealModal(true)} 
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-black text-[11px] rounded-xl transition-all shadow-md shadow-blue-600/20 shrink-0"
                    >
                      {t("chat.requestAppealBtn")}
                    </button>
                  ) : (
                    <span className="text-[10px] bg-white/5 border border-white/10 text-slate-400 px-3 py-1.5 rounded-xl font-bold shrink-0">
                      {t("chat.appealUnderReview")}
                    </span>
                  )}
                </div>
              ) : isTargetPermanentlyBanned ? (
                <div className="w-full p-4 bg-red-950/40 border border-red-500/30 rounded-2xl flex items-center justify-center space-x-3 space-x-reverse text-center animate-in fade-in">
                  <div className="w-8 h-8 rounded-xl bg-red-600/20 text-red-400 flex items-center justify-center shrink-0 border border-red-500/30">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
                  </div>
                  <div>
                    <p className="text-xs font-black text-white">{t("chat.cannotMessageUser")}</p>
                    <p className="text-[10px] text-red-300 font-bold">{t("chat.userBannedReason")}</p>
                  </div>
                </div>
              ) : isBlockedByTarget ? (
                <div className="w-full p-4 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center space-x-3 space-x-reverse text-center animate-in fade-in">
                  <div className="w-8 h-8 rounded-xl bg-red-600/15 text-red-400 flex items-center justify-center shrink-0 border border-red-500/20">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
                  </div>
                  <div>
                    <p className="text-xs font-black text-white">هذا المستخدم غير متوفر</p>
                    <p className="text-[10px] text-slate-400 font-bold">لا يمكنك إرسال أو استلام رسائل من هذا الحساب</p>
                  </div>
                </div>
              ) : isBlockedByMe ? (
                <div className="w-full p-3.5 bg-red-950/30 border border-red-500/25 rounded-2xl flex items-center justify-between gap-3 animate-in fade-in">
                  <div className="flex items-center space-x-2.5 space-x-reverse">
                    <div className="w-8 h-8 rounded-xl bg-red-600/20 text-red-400 flex items-center justify-center shrink-0 border border-red-500/30">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-black text-white">لقد قمت بحظر هذا المستخدم</p>
                      <p className="text-[10px] text-slate-400 font-bold">قم بإلغاء الحظر لتتمكن من المراسلة مجدداً</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggleBlock(activeChat.id)}
                    className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-[10px] font-black shrink-0 transition-all"
                  >
                    إلغاء الحظر
                  </button>
                </div>
              ) : isRecording ? (
                <div className="w-full flex items-center space-x-3 space-x-reverse animate-in fade-in duration-300">
                  <button 
                    onClick={cancelRecording}
                    className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-red-600/20 text-red-500 flex items-center justify-center hover:bg-red-600/30 transition-all shrink-0"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth={2}/></svg>
                  </button>
                  
                  <div className="flex-1 h-9 sm:h-10 bg-black/40 rounded-xl flex items-center justify-center px-3 space-x-1 space-x-reverse">
                    {[...Array(20)].map((_, i) => {
                      const height = Math.max(3, (recordingVolume / 255) * 32 * (Math.sin(i * 0.5) + 1.5));
                      return (
                        <div 
                          key={i} 
                          className="w-1 bg-blue-500 rounded-full transition-all duration-75"
                          style={{ height: `${height}px` }}
                        />
                      );
                    })}
                  </div>

                  <button 
                    onClick={stopRecording}
                    className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-600/40 hover:scale-105 transition-all shrink-0"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
                  </button>
                </div>
              ) : (
                <>
                  {!isUserTyping && (
                    <>
                      {!activeChat.isAI && (
                        <>
                          <button onClick={() => fileInputRef.current?.click()} className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center bg-white/5 text-blue-500 hover:bg-white/10 transition-all flex-shrink-0">
                             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth={2}/></svg>
                          </button>
                          <button 
                            onClick={startRecording} 
                            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center bg-white/5 text-red-500 hover:bg-white/10 transition-all flex-shrink-0"
                          >
                             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" strokeWidth={2}/></svg>
                          </button>
                        </>
                      )}
                    </>
                  )}
                  {isUserTyping && !activeChat.isAI && (
                    <button 
                      onClick={() => setShowPlusMenu(!showPlusMenu)} 
                      className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center transition-all flex-shrink-0 ${showPlusMenu ? 'bg-blue-600 text-white rotate-45' : 'bg-white/5 text-slate-400 hover:bg-white/10'}`}
                    >
                       <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={2.5}/></svg>
                    </button>
                  )}

                  {showPlusMenu && (
                    <div className="absolute bottom-16 right-3 bg-slate-900 border border-white/10 rounded-2xl p-1.5 shadow-2xl flex flex-col space-y-1.5 animate-in fade-in duration-200 z-[150]">
                       <button onClick={() => fileInputRef.current?.click()} className="p-2.5 hover:bg-white/5 rounded-xl flex items-center space-x-2.5 space-x-reverse text-white">
                          <div className="w-8 h-8 bg-blue-600/20 rounded-lg flex items-center justify-center text-blue-500">
                             <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth={2}/></svg>
                          </div>
                          <span className="text-[10px] font-black uppercase">{t("chat.photo")}</span>
                       </button>
                       <button 
                         onMouseDown={startRecording} 
                         onMouseUp={stopRecording}
                         onTouchStart={startRecording}
                         onTouchEnd={stopRecording}
                         className={`p-2.5 rounded-xl flex items-center space-x-2.5 space-x-reverse transition-all ${isRecording ? 'bg-red-600 text-white animate-pulse' : 'hover:bg-white/5 text-white'}`}
                       >
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isRecording ? 'bg-white/20 text-white' : 'bg-red-600/20 text-red-500'}`}>
                             <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" strokeWidth={2}/></svg>
                          </div>
                          <span className="text-[10px] font-black uppercase">{isRecording ? t('chat.recordingAudio') : t('chat.voiceClip')}</span>
                       </button>
                    </div>
                  )}

                  <div className="flex-1 relative">
                    {showMentionList && filteredMembers.length > 0 && (
                      <div className="absolute bottom-full mb-2 left-0 w-60 bg-slate-900 border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-[200] animate-in fade-in duration-200">
                        <div className="p-2.5 border-b border-white/5 bg-white/5">
                          <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">{t("chat.mentionMember")}</span>
                        </div>
                        <div className="max-h-44 overflow-y-auto custom-scrollbar">
                          {filteredMembers.map((m: any) => (
                            <button 
                              key={m.Id_user}
                              onMouseDown={(e) => {
                                e.preventDefault();
                                insertMention(m.UserData);
                              }}
                              className="w-full p-2.5 flex items-center space-x-2.5 space-x-reverse hover:bg-white/5 transition-colors border-b border-white/5 last:border-0"
                            >
                              <img src={m.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${m.Id_user}`} className="w-7 h-7 rounded-lg border border-white/10" />
                              <div className="text-right">
                                <p className="text-[10px] font-black text-white">{m.UserData}</p>
                                <p className="text-[8px] text-slate-500 font-bold">@{m.Id_user.substring(0, 8)}</p>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    <button onClick={(e) => { e.stopPropagation(); setEmojiTarget('input'); setShowEmojiPicker(!showEmojiPicker); }} className="absolute left-2.5 bottom-2.5 text-slate-500 hover:text-yellow-500 z-30 transition-colors">
                       <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14.828 14.828a4 4 0 01-5.656 0" strokeWidth={2}/></svg>
                    </button>
                    <div className="relative w-full min-h-[36px]">
                      <div className="absolute inset-0 w-full h-full pl-9 pr-3.5 py-1.5 sm:py-2 text-[11px] font-bold text-transparent pointer-events-none whitespace-pre-wrap break-words leading-5">
                        {renderTextareaOverlay()}
                      </div>
                      <textarea 
                        ref={textareaRef} 
                        rows={1} 
                        value={inputMessage || ""} 
                        onChange={e => handleInputChange(e.target.value)} 
                        onBlur={() => setShowMentionList(false)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                        className="w-full bg-black/40 border border-white/5 rounded-xl pl-9 pr-3.5 py-1.5 sm:py-2 text-[11px] font-bold text-white outline-none focus:border-blue-500/30 transition-all resize-none min-h-[36px] max-h-28 custom-scrollbar leading-5 relative z-10" 
                        placeholder={t("chat.typeYourMessage")} 
                      />
                    </div>
                  </div>
                  <button onPointerDown={(e) => { e.preventDefault(); if (!isUploading) sendMessage(); }} disabled={isUploading} className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-white shadow-md active:scale-90 transition-all flex-shrink-0 ${isUploading ? 'bg-slate-700 animate-pulse' : 'bg-blue-600'}`}>
                    {isUploading ? (
                       <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : isUserTyping ? (
                      <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
                    ) : (
                      <span className="flex items-center justify-center">
                        <EmojiImg emoji={quickEmoji} size={20} />
                      </span>
                    )}
                  </button>
                </>
              )}
           </div>
           <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />
        </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center relative overflow-hidden select-none">
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-blue-500 flex items-center justify-center text-white mb-6 shadow-2xl shadow-blue-500/30 animate-pulse">
                <svg className="w-10 h-10 sm:w-12 sm:h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white mb-2 tracking-tight">{t("chat.hubTitle")}</h2>
              <p className="text-slate-400 text-xs font-bold max-w-sm leading-relaxed mb-6">
                {t("chat.chooseChatSubtitle")}
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <button 
                  onClick={() => {
                    const aiChat = previews.find(p => p.isAI);
                    if (aiChat) setActiveChat(aiChat);
                    else setActiveChat({ id: `ai_${user.Id_user}`, name: "TeBLOCK AI", photo: "https://api.dicebear.com/7.x/bottts/svg?seed=ai", isAI: true, isGroup: false });
                    setMode('activeChat');
                  }}
                  className="px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-black text-xs transition-all shadow-lg shadow-blue-600/30 flex items-center space-x-2 space-x-reverse active:scale-95"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                  <span>{t("chat.chatWithAI")}</span>
                </button>
                <button 
                  onClick={() => setMode('friends')}
                  className="px-5 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-slate-300 font-black text-xs border border-white/10 transition-all active:scale-95"
                >
                  {t("chat.showFriendsList")}
                </button>
              </div>
              <div className="mt-10 flex items-center space-x-4 space-x-reverse text-[11px] text-slate-500 font-bold border-t border-white/5 pt-5">
                <span className="flex items-center"><span className="w-1.5 h-1.5 rounded-full bg-green-500 ml-1.5"></span>{t('chat.encryptedNotice')}</span>
                <span>·</span>
                <span>{t("chat.hdCalls")}</span>
                <span>·</span>
                <span>{t("chat.reelsAndNotes")}</span>
              </div>
            </div>
          )}
        </div>

      </div>


      {mode === 'voiceCall' && activeChat && (
        <P2PCallModal
          user={user}
          incomingCall={null}
          activeSession={activeP2PSession || currentChatCall || {
            callId: activeChat.id,
            callerId: user.Id_user,
            callerName: user.UserData,
            callerPhoto: user.photoURL,
            callerIp: p2pCallManager.getMyTemporaryIp() || t('chat.registeredTemp'),
            receiverId: activeChat.id,
            receiverName: activeChat.name,
            receiverPhoto: activeChat.photo,
            receiverIp: t('chat.connectingP2P'),
            chatId: activeChat.id,
            status: 'connected'
          }}
          onAcceptIncoming={() => {}}
          onRejectIncoming={leaveCall}
          onEndActiveCall={leaveCall}
          onClose={() => setMode('activeChat')}
        />
      )}

      {mode === 'chatSettings' && activeChat && (
        <div className="fixed inset-0 z-[300] bg-black/95 backdrop-blur-2xl flex flex-col animate-in slide-in-from-left duration-500 overflow-y-auto custom-scrollbar">
           <div className="px-6 pb-5 pt-[max(1.25rem,env(safe-area-inset-top))] border-b border-white/5 flex items-center justify-between sticky top-0 bg-black/90 backdrop-blur-xl z-50">
              <button onClick={() => setMode('activeChat')} className="p-2 text-slate-500"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5" strokeWidth={3}/></svg></button>
              <h2 className="text-sm font-black text-white uppercase tracking-[0.3em]">{activeChat.isGroup ? t('chat.groupSettings') : t('chat.chatOptions')}</h2>
              <div className="w-10"></div>
           </div>

           {activeChat.isGroup ? (
            <div className="p-8 pb-12">
               <div className="flex flex-col items-center mb-8">
                 <button onClick={isMeAdmin ? changeGroupPhoto : undefined} disabled={isUploading} className="relative group">
                   <img src={activeChat.photo || `https://api.dicebear.com/7.x/bottts/svg?seed=${activeChat.id}`} className="w-28 h-28 rounded-full object-cover shadow-2xl border border-white/10" />
                   {isMeAdmin && (
                     <div className="absolute inset-0 bg-black/50 rounded-full opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                       <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth={2}/></svg>
                     </div>
                   )}
                 </button>
                 <button onClick={() => {
                   if (isMeAdmin) {
                      const newName = prompt(t('chat.editGroupNamePrompt'), activeChat.name);
                      if (newName) changeGroupName(newName);
                   }
                 }} className="mt-4 flex flex-col items-center group">
                   <h3 className="text-xl font-black text-white">{activeChat.name}</h3>
                   {isMeAdmin && (
                     <span className="text-[10px] text-white/50 opacity-0 group-hover:opacity-100 transition-opacity mt-1">{t('chat.clickToEditName')}</span>
                   )}
                 </button>
               </div>

               <p className="text-[11px] font-black text-blue-500 uppercase tracking-widest text-right mb-3 px-2">{t("common.actions")}</p>
               <div className="space-y-3 mb-8 bg-white/5 rounded-[2rem] p-3 border border-white/5">
                 <button onClick={() => setMode('groupMembers')} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.members")}</span>
                    <div className="flex items-center">
                       <span className="text-[10px] font-bold bg-white/10 px-2 py-1 rounded-full text-slate-300 ml-2">{activeChat.members?.length || 0}</span>
                       <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" strokeWidth={2}/></svg>
                    </div>
                 </button>
                 <button onClick={() => setMode('themePicker')} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.theme")}</span>
                    <span className="text-2xl">{currentChatTheme.emoji}</span>
                 </button>
                 <button onClick={() => setMode('nicknamePicker')} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.editNickname")}</span>
                    <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth={2}/></svg>
                 </button>
                 <button onClick={() => setMode('quickEmojiPicker')} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.quickReaction")}</span>
                    <span className="text-2xl">{quickEmoji}</span>
                 </button>
                 <button onClick={() => setMode('pinnedMessages')} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.pinnedMessages")}</span>
                    <span className="bg-blue-600/20 text-blue-500 px-2 py-1 rounded-lg text-[9px] font-black">
                      {messages.filter(m => m.pinned && !(m.deletedFor || []).includes(user.Id_user)).length}
                    </span>
                 </button>
               </div>

               <p className="text-[11px] font-black text-slate-500 uppercase tracking-widest text-right mb-3 px-2">{t("common.privacy")}</p>
               <div className="space-y-3 bg-red-500/5 rounded-[2rem] p-3 border border-red-500/10">
                 <button onClick={async () => {
                   try {
                     await addDoc(collection(db, 'reports'), {
                       reportedChat: activeChat.id,
                       reportedBy: user.Id_user,
                       type: 'chat_report',
                       timestamp: serverTimestamp()
                     });
                     alert(t("chat.reportSent"));
                   } catch (e) {
                     alert(t("common.error"));
                   }
                 }} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-red-500/10 transition-colors">
                    <span className="text-xs font-bold text-red-500">{t("chat.reportMessages")}</span>
                    <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                 </button>
                 <button onClick={leaveGroup} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-red-500/10 transition-colors">
                    <span className="text-xs font-bold text-red-500">{t("chat.leaveGroup")}</span>
                    <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                 </button>
               </div>

               {serverLogs && (
                 <div className="mt-8 w-full p-5 bg-black/40 rounded-3xl border border-white/5 space-y-3">
                    <div className="flex items-center justify-between">
                       <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest">{t("chat.serverLogsSecurity")}</span>
                       <button onClick={() => refetchStatus()} className="text-[8px] text-slate-500 hover:text-white">{t("common.refresh")}</button>
                    </div>
                    <div className="space-y-2 max-h-40 overflow-y-auto custom-scrollbar">
                       {serverLogs.logs.map((log: any) => (
                         <div key={log.id} className="text-[9px] font-mono text-slate-400 border-b border-white/5 pb-1">
                            <span className="text-blue-500">[{new Date(log.time).toLocaleTimeString()}]</span> {log.event}
                         </div>
                       ))}
                    </div>
                 </div>
               )}
            </div>
           ) : (
            <div className="p-8 space-y-6 pb-12">
               <div className="flex flex-col items-center mb-8">
                 <img src={activeChat.photo || `https://api.dicebear.com/7.x/bottts/svg?seed=${activeChat.id}`} className="w-28 h-28 rounded-full object-cover shadow-2xl border border-white/10" />
                 <h3 className="mt-4 text-xl font-black text-white">{activeChat.name}</h3>
               </div>
               
               <p className="text-[11px] font-black text-blue-500 uppercase tracking-widest text-right mb-2 px-2">{t("chat.chatActions")}</p>
               <div className="space-y-3 mb-6 bg-white/5 rounded-[2rem] p-3 border border-white/5">
                 <button onClick={() => setMode('themePicker')} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.theme")}</span>
                    <span className="text-2xl">{currentChatTheme.emoji}</span>
                 </button>
                 <button onClick={() => setMode('nicknamePicker')} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.editNickname")}</span>
                    <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth={2}/></svg>
                 </button>
                 <button onClick={() => setMode('quickEmojiPicker')} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.quickReaction")}</span>
                    <span className="text-2xl">{quickEmoji}</span>
                 </button>
                 <button onClick={() => { toggleManualUnread(activeChat.id); setMode('inbox'); }} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.markUnread")}</span>
                    <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8" strokeWidth={2}/></svg>
                 </button>
                 <button onClick={() => {
                   setGroupName(`${t("chat.groupDefaultName")} ${user.UserData} & ${activeChat.name}`);
                   setSelectedMembers([activeChat.id]);
                   setMode('createGroup');
                 }} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.createGroupWith")}</span>
                    <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={3}/></svg>
                 </button>
                 <button onClick={() => setMode('pinnedMessages')} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors">
                    <span className="text-xs font-bold text-white">{t("chat.pinnedMessages")}</span>
                    <span className="bg-blue-600/20 text-blue-500 px-2 py-1 rounded-lg text-[9px] font-black">
                      {messages.filter(m => m.pinned && !(m.deletedFor || []).includes(user.Id_user)).length}
                    </span>
                 </button>
               </div>

               <p className="text-[11px] font-black text-slate-500 uppercase tracking-widest text-right mb-2 px-2 mt-4">{t("common.privacy")}</p>
               <div className="space-y-3 bg-red-500/5 rounded-[2rem] p-3 border border-red-500/10">
                 <button onClick={async () => {
                   try {
                     await addDoc(collection(db, 'reports'), {
                       reportedChat: activeChat.id,
                       reportedBy: user.Id_user,
                       type: 'chat_report',
                       timestamp: serverTimestamp()
                     });
                     alert(t("chat.reportSent"));
                   } catch (e) {
                     alert(t("common.error"));
                   }
                 }} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-red-500/10 transition-colors">
                    <span className="text-xs font-bold text-red-500">{t("chat.reportAction")}</span>
                    <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                 </button>
                 <button onClick={() => handleToggleBlock(activeChat.id)} className="w-full p-4 rounded-2xl flex items-center justify-between hover:bg-red-500/10 transition-colors">
                    <span className="text-xs font-bold text-red-500">{isBlockedByMe ? 'إلغاء الحظر' : t("chat.block")}</span>
                    <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
                 </button>
               </div>
            </div>
           )}
        </div>
      )}

      {mode === 'themePicker' && (
        <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-3xl p-8 flex flex-col animate-in slide-in-from-right duration-500 overflow-y-auto custom-scrollbar">
           <div className="flex items-center justify-between mb-8">
              <button onClick={() => setMode('chatSettings')} className="p-2 text-slate-500"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5" strokeWidth={3}/></svg></button>
              <h2 className="text-sm font-black text-white uppercase tracking-[0.3em]">{t("chat.chooseChatTheme")}</h2>
              <div className="w-10"></div>
           </div>

           <div className="grid grid-cols-2 gap-4 pb-12">
              {CHAT_THEMES.map(theme => (
                <button key={theme.id} onClick={async () => {
                  setCurrentChatTheme(theme);
                  if (activeChat) {
                     const convId = activeChat.isGroup ? activeChat.id : [user.Id_user, activeChat.id].sort().join('_');
                     const updates: any = { themeId: theme.id };
                     if (theme.id !== 'none') updates.quickEmoji = theme.emoji;
                     await setDoc(doc(db, 'conversations', convId), updates, { merge: true });
                  } else {
                     localStorage.setItem(`theme_${user.Id_user}_ai`, theme.id);
                     if (theme.id !== 'none') localStorage.setItem(`emoji_${user.Id_user}_ai`, theme.emoji);
                  }
                  setMode('activeChat');
                }} className={`relative h-32 rounded-3xl overflow-hidden border-4 transition-all ${currentChatTheme.id === theme.id ? 'border-blue-600 scale-95 shadow-2xl shadow-blue-600/30' : 'border-white/5 opacity-40'}`}>
                   {theme.bg ? (
                     <img src={theme.bg} className="w-full h-full object-cover brightness-50" />
                   ) : (
                     <div className="w-full h-full bg-slate-900" />
                   )}
                   <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                      <span className="text-4xl">{theme.emoji}</span>
                   </div>
                </button>
              ))}
           </div>
        </div>
      )}

      {mode === 'pinnedMessages' && activeChat && (
        <div
          className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-3xl p-6 sm:p-8 flex flex-col animate-in slide-in-from-right duration-500 overflow-y-auto custom-scrollbar"
          style={{ paddingTop: 'calc(env(safe-area-inset-top, 0px) + 1.5rem)' }}
        >
           <div className="flex items-center justify-between mb-8">
              <button onClick={() => setMode('chatSettings')} className="p-2 text-slate-400 hover:text-white"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5" strokeWidth={3}/></svg></button>
              <h2 className="text-sm font-black text-white">{t("chat.pinnedMessages")}</h2>
              <div className="w-10"></div>
           </div>

           {(() => {
             const pinnedList = messages.filter(m => m.pinned && !(m.deletedFor || []).includes(user.Id_user));
             if (pinnedList.length === 0) {
               return (
                 <div className="flex-1 flex flex-col items-center justify-center text-center py-20 space-y-3">
                   <div className="w-16 h-16 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center text-slate-500">
                     <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2z"/></svg>
                   </div>
                   <p className="text-sm font-bold text-slate-400">لا توجد رسائل مثبتة حالياً</p>
                   <p className="text-xs text-slate-500 max-w-xs">اضغط مطولاً على أي رسالة في المحادثة واختر "تثبيت" لتظهر هنا.</p>
                 </div>
               );
             }
             return (
               <div className="space-y-3 pb-12">
                 {pinnedList.map(pm => (
                   <div key={pm.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col gap-2">
                     <div className="flex items-center justify-between">
                       <span className="text-xs font-black text-blue-400">{pm.senderName || (pm.senderId === user.Id_user ? user.UserData : activeChat.name)}</span>
                       <button
                         onClick={async () => {
                           try {
                             await updateDoc(doc(db, 'messages', pm.id), { pinned: false, pinnedBy: null, pinnedAt: null });
                           } catch (err) {
                             console.error(err);
                           }
                         }}
                         className="text-[11px] font-bold text-red-400 hover:text-red-300 px-2.5 py-1 rounded-xl bg-red-500/10"
                       >
                         إلغاء التثبيت
                       </button>
                     </div>
                     {pm.reelId ? (
                       <button
                         onClick={() => (window as any).navigateToReel?.(pm.reelId, true)}
                         className="text-right text-xs font-bold text-blue-300 hover:underline flex items-center gap-1.5"
                       >
                         <span>🎬 ريلز مشارك: {pm.reelCaption || pm.text || t("chat.watchReel")}</span>
                       </button>
                     ) : pm.imageUrl ? (
                       <img src={pm.imageUrl} alt="" className="w-32 h-32 object-cover rounded-xl border border-white/10" />
                     ) : pm.voiceUrl ? (
                       <audio src={pm.voiceUrl} controls className="h-8 w-full max-w-[220px]" />
                     ) : (
                       <p className="text-sm text-white/90 whitespace-pre-wrap break-words leading-relaxed">{pm.text}</p>
                     )}
                   </div>
                 ))}
               </div>
             );
           })()}
        </div>
      )}


      {mode === 'groupMembers' && activeChat && (
        <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-3xl p-8 flex flex-col animate-in slide-in-from-right duration-500 overflow-y-auto custom-scrollbar">
           <div className="flex items-center justify-between mb-8">
              <button onClick={() => setMode('chatSettings')} className="p-2 text-slate-500"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5" strokeWidth={3}/></svg></button>
              <h2 className="text-sm font-black text-white uppercase tracking-[0.3em]">{t("chat.members")}</h2>
              {isMeAdmin && (
                <button onClick={() => setMode('addMember')} className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-600/20">
                   <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={3}/></svg>
                </button>
              )}
              {!isMeAdmin && <div className="w-10"></div>}
           </div>

           <div className="space-y-4">
              {isMeAdmin && joinRequests.length > 0 && (
                <div className="space-y-4 mb-8">
                  <h3 className="text-[10px] font-black text-blue-500 uppercase tracking-widest px-2">{t("chat.pendingRequests")}</h3>
                  {joinRequests.map(req => (
                    <div key={req.id} className="p-5 bg-blue-600/5 rounded-[2rem] flex items-center justify-between border border-blue-500/20">
                       <div className="flex items-center">
                          <img src={req.fromPhoto || `https://api.dicebear.com/7.x/bottts/svg?seed=${req.fromId}`} className="w-10 h-10 rounded-xl ml-3" />
                          <div className="text-right">
                             <p className="text-xs font-black text-white">{req.fromName}</p>
                             <p className="text-[8px] text-slate-500">@{req.fromId}</p>
                          </div>
                       </div>
                       <div className="flex gap-2">
                          <button onClick={() => handleJoinResponse(req, true)} className="p-2 bg-green-600 text-white rounded-xl"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7" strokeWidth={3}/></svg></button>
                          <button onClick={() => handleJoinResponse(req, false)} className="p-2 bg-red-600 text-white rounded-xl"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={3}/></svg></button>
                       </div>
                    </div>
                  ))}
                </div>
              )}
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2 mb-2">{t("chat.groupMembersTitle")}</h3>
              {activeChat.membersData?.map((m: any) => (
                <div key={m.Id_user} className="p-5 bg-white/5 rounded-[2rem] flex items-center justify-between border border-white/5 group hover:bg-white/10 transition-all">
                   <div className="flex items-center">
                      <img src={m.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${m.Id_user}`} className="w-12 h-12 rounded-2xl ml-4 border border-white/10" />
                      <div className="text-right">
                         <p className="text-xs font-black text-white">{nicknames[(m.Id_user || "").replace(/\./g, "_")] || m.UserData}</p>
                         <div className="flex items-center mt-1">
                            {activeChat.admins?.includes(m.Id_user) && <span className="text-[7px] bg-blue-600/20 text-blue-500 px-2 py-0.5 rounded-full font-black uppercase tracking-widest ml-2">{t("chat.adminRole")}</span>}
                            <span className="text-[8px] text-slate-500 font-bold uppercase tracking-widest">@{m.Id_user.substring(0,8)}</span>
                         </div>
                      </div>
                   </div>
                   {isMeAdmin && m.Id_user !== user.Id_user && (
                     <button onClick={() => kickMember(m.Id_user, m.UserData)} className="w-10 h-10 rounded-xl bg-red-500/10 text-red-500 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
                     </button>
                   )}
                </div>
              ))}
           </div>
        </div>
      )}

      {mode === 'nicknamePicker' && activeChat && (
        <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-3xl p-8 flex flex-col animate-in slide-in-from-right duration-500">
           <h2 className="text-center font-black text-white mb-8 tracking-widest uppercase">{t("chat.editNickname")}</h2>
           <div className="space-y-4 flex-1 overflow-y-auto custom-scrollbar">
              {(activeChat.isGroup ? (activeChat.membersData && activeChat.membersData.length > 0 ? activeChat.membersData : [user]) : [user, activeChat]).map((u: any) => (
                <div key={u.Id_user || u.id} className="p-5 bg-white/5 rounded-3xl border border-white/5 flex items-center justify-between">
                   <div className="flex items-center">
                      <img src={u.photoURL || u.photo || `https://api.dicebear.com/7.x/bottts/svg?seed=${u.Id_user || u.id}`} className="w-10 h-10 rounded-xl ml-3" />
                      <div className="text-right">
                         <p className="text-[10px] text-slate-500 font-bold">{u.UserData || u.name}</p>
                         <p className="text-xs font-black text-white">{nicknames[((u.Id_user || u.id) || "").replace(/\./g, "_")] || t("chat.noNickname")}</p>
                      </div>
                   </div>
                   <button onClick={() => { setEditingNicknameId(((u.Id_user || u.id) || "").replace(/\./g, "_")); setNicknameInput(nicknames[((u.Id_user || u.id) || "").replace(/\./g, "_")] || ""); }} className="p-2 text-blue-500"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth={2}/></svg></button>
                </div>
              ))}
           </div>

           {editingNicknameId && (
             <div className="fixed inset-0 z-[500] bg-black/80 backdrop-blur-md flex items-center justify-center p-6">
                <div className="w-full max-w-sm glass p-8 rounded-[2.5rem] text-right">
                   <h3 className="text-lg font-black text-white mb-6 text-center">{t("chat.editNickname")}</h3>
                   <input type="text" value={nicknameInput || ""} onChange={e => setNicknameInput(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-4 text-sm font-bold text-white outline-none focus:border-blue-500 mb-6" placeholder={t("chat.enterNewNickname")} />
                   <div className="flex gap-3">
                      <button onClick={async () => {
                         const newNicknames = { ...nicknames, [editingNicknameId]: nicknameInput };
                         if (newNicknames[editingNicknameId] === "") delete newNicknames[editingNicknameId];
                         setNicknames(newNicknames);
                         const convId = activeChat.isGroup ? activeChat.id : (activeChat.isAI ? null : [user.Id_user, activeChat.id].sort().join('_'));
                         if (convId) {
                            await setDoc(doc(db, 'conversations', convId), { nicknames: newNicknames }, { merge: true });
                         }
                         setEditingNicknameId(null);
                      }} className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-black text-xs">{t("chat.save")}</button>
                      <button onClick={() => setEditingNicknameId(null)} className="flex-1 py-4 bg-white/5 text-slate-400 rounded-2xl font-black text-xs">{t("common.cancel")}</button>
                   </div>
                </div>
             </div>
           )}

           <button onClick={() => setMode('chatSettings')} className="mt-8 w-full py-4 bg-white/5 text-slate-400 rounded-2xl font-black text-xs uppercase tracking-widest">{t("common.back")}</button>
        </div>
      )}

      {mode === 'createGroup' && (
        <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-3xl p-8 flex flex-col animate-in slide-in-from-right duration-500 overflow-y-auto custom-scrollbar">
           <div className="flex items-center justify-between mb-8">
              <button onClick={() => setMode('inbox')} className="p-2 text-slate-500"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5" strokeWidth={3}/></svg></button>
              <h2 className="text-sm font-black text-white uppercase tracking-[0.3em]">{t("chat.createGroup")}</h2>
              <div className="w-10"></div>
           </div>

           <div className="space-y-6">
              <div className="space-y-2">
                 <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mr-2">{t("chat.groupNameInput")}</label>
                 <input type="text" value={groupName || ""} onChange={e => setGroupName(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm font-bold text-white outline-none focus:border-blue-500 transition-all" placeholder={t("chat.enterGroupName")} />
              </div>

               <div className="space-y-4">
                  <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mr-2">{t("chat.selectMembers")}</h3>
                 <div className="space-y-2">
                    {/* Gemini AI Option in Group Creation */}
                    <button onClick={() => {
                      const aiId = `ai_${user.Id_user}`;
                      if (selectedMembers.includes(aiId)) {
                        setSelectedMembers(selectedMembers.filter(id => id !== aiId));
                      } else {
                        setSelectedMembers([...selectedMembers, aiId]);
                      }
                    }} className={`w-full p-4 rounded-2xl border transition-all flex items-center justify-between ${selectedMembers.includes(`ai_${user.Id_user}`) ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white/5 border-white/5 text-slate-300'}`}>
                       <div className="flex items-center">
                         <img src="https://api.dicebear.com/7.x/bottts/svg?seed=ai" className="w-8 h-8 rounded-lg ml-3 border border-blue-500/30 bg-blue-500/10" />
                         <span className="text-xs font-bold">TeBLOCK AI (Bot)</span>
                       </div>
                       {selectedMembers.includes(`ai_${user.Id_user}`) && <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>}
                    </button>
                    {friends.map(f => (
                      <button key={f.Id_user} onClick={() => {
                        if (selectedMembers.includes(f.Id_user)) {
                          setSelectedMembers(selectedMembers.filter(id => id !== f.Id_user));
                        } else {
                          setSelectedMembers([...selectedMembers, f.Id_user]);
                        }
                      }} className={`w-full p-4 rounded-2xl border transition-all flex items-center justify-between ${selectedMembers.includes(f.Id_user) ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white/5 border-white/5 text-slate-300'}`}>
                        <div className="flex items-center">
                          <img src={f.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${f.Id_user}`} className="w-8 h-8 rounded-lg ml-3" />
                          <span className="text-xs font-bold">{f.UserData}</span>
                        </div>
                        {selectedMembers.includes(f.Id_user) && <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>}
                      </button>
                    ))}
                 </div>
              </div>

              <button onClick={createGroup} disabled={!groupName.trim() || selectedMembers.length === 0} className="w-full py-5 bg-blue-600 text-white rounded-3xl font-black text-xs shadow-2xl shadow-blue-600/30 disabled:opacity-50 transition-all">{t("chat.createGroup")}</button>
           </div>
        </div>
      )}

      {mode === 'addMember' && activeChat && (
        <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-3xl p-8 flex flex-col animate-in slide-in-from-right duration-500 overflow-y-auto custom-scrollbar">
           <div className="flex items-center justify-between mb-8">
              <button onClick={() => setMode('chatSettings')} className="p-2 text-slate-500"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5" strokeWidth={3}/></svg></button>
              <h2 className="text-sm font-black text-white uppercase tracking-[0.3em]">{t("chat.addMember")}</h2>
              <div className="w-10"></div>
           </div>

           <div className="space-y-2">
              {/* Gemini AI Option in Add Member */}
              {!activeChat.members?.includes(`ai_${user.Id_user}`) && (
                <button onClick={() => { 
                  addMember({ 
                    Id_user: `ai_${user.Id_user}`, 
                    UserData: "TeBLOCK AI", 
                    photoURL: "https://api.dicebear.com/7.x/bottts/svg?seed=ai" 
                  } as any); 
                  setMode('chatSettings'); 
                }} className="w-full p-5 bg-blue-600/10 border border-blue-500/20 rounded-3xl flex items-center justify-between hover:bg-blue-600/20 transition-all">
                   <div className="flex items-center">
                      <img src="https://api.dicebear.com/7.x/bottts/svg?seed=ai" className="w-10 h-10 rounded-xl ml-4 border border-blue-500/30 bg-blue-500/10" />
                      <span className="text-xs font-black text-blue-400">TeBLOCK AI (Bot)</span>
                   </div>
                   <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={3}/></svg>
                </button>
              )}
              {friends.filter(f => !activeChat.members?.includes(f.Id_user)).map(f => (
                <button key={f.Id_user} onClick={() => { addMember(f); setMode('chatSettings'); }} className="w-full p-5 bg-white/5 rounded-3xl border border-white/5 flex items-center justify-between hover:bg-white/10 transition-all">
                   <div className="flex items-center">
                      <img src={f.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${f.Id_user}`} className="w-10 h-10 rounded-xl ml-4" />
                      <span className="text-xs font-black text-white">{f.UserData}</span>
                   </div>
                   <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth={3}/></svg>
                </button>
              ))}
              {friends.filter(f => !activeChat.members?.includes(f.Id_user)).length === 0 && (
                <p className="text-center text-slate-500 text-[10px] font-bold py-10">{t("chat.noMoreFriends")}</p>
              )}
           </div>
        </div>
      )}
      {mode === 'quickEmojiPicker' && (
        <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-3xl p-8 flex flex-col animate-in slide-in-from-right duration-500">
           <h2 className="text-center font-black text-white mb-8 tracking-widest uppercase">{t("chat.customizeQuickReaction")}</h2>
           <div className="grid grid-cols-6 gap-4 overflow-y-auto custom-scrollbar">
              {EMOJI_CATEGORIES.flatMap(cat => cat.emojis).map(e => (
                <button key={e} onClick={() => {
                  setEmojiTarget('quickEmoji');
                  handleEmojiSelect(e);
                  setMode('activeChat');
                }} className="p-3 hover:bg-white/10 rounded-2xl active:scale-125 transition-transform flex items-center justify-center">
                  <EmojiImg emoji={e} size={32} />
                </button>
              ))}
           </div>
        </div>
      )}

      {showEmojiPicker && (
        <div className="absolute bottom-20 right-0 w-80 h-96 bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-3xl overflow-hidden animate-in zoom-in-95 duration-200 z-[100] flex flex-col" onClick={e => e.stopPropagation()}>
           {/* Top Bar with Style Selector & Quick Switch */}
           <div className="p-3 border-b border-white/5 bg-black/40 flex items-center justify-between shrink-0">
              <button 
                onClick={() => setShowEmojiStyleModal(true)} 
                className="flex items-center space-x-1 space-x-reverse px-2.5 py-1 rounded-xl bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white transition-all text-[9px] font-black"
                title={t("chat.changeEmojiStyle")}
              >
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /></svg>
                <span>{t('chat.emojiStyleLabel')} {EMOJI_STYLES.find(s => s.id === currentEmojiStyle)?.brand || 'Twemoji'}</span>
              </button>

              <div className="flex items-center space-x-1 space-x-reverse bg-black/60 p-0.5 rounded-xl border border-white/5">
                {EMOJI_STYLES.map(st => (
                  <button
                    key={st.id}
                    onClick={() => setStoredEmojiStyle(st.id)}
                    className={`px-2 py-0.5 rounded-lg text-[9px] font-black transition-all ${
                      currentEmojiStyle === st.id ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                    }`}
                    title={st.name}
                  >
                    {st.brand}
                  </button>
                ))}
              </div>
           </div>

           <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-4">
              {EMOJI_CATEGORIES.map(cat => (
                <div key={cat.name}>
                   <h5 className="text-[8px] font-black text-slate-500 uppercase mb-2 tracking-wider">{cat.name}</h5>
                   <div className="grid grid-cols-6 gap-2">
                      {cat.emojis.map(e => (
                        <button 
                          key={e} 
                          onClick={() => handleEmojiSelect(e)} 
                          className="w-10 h-10 flex items-center justify-center p-1 hover:bg-white/10 rounded-xl active:scale-125 transition-transform"
                        >
                          <EmojiImg emoji={e} size={24} />
                        </button>
                      ))}
                   </div>
                </div>
              ))}
           </div>
        </div>
      )}

      {contextMenu && (
        <div className="fixed inset-0 z-[600] flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-in fade-in duration-300" onClick={() => { setContextMenu(null); setShowMoreContextOptions(false); }}>
           
           {/* Reactions positioned near the click */}
           <style>{`
             @keyframes popIn {
               0% { opacity: 0; transform: scale(0.3); }
               100% { opacity: 1; transform: scale(1); }
             }
           `}</style>
           <div 
             className="absolute flex items-center space-x-2 space-x-reverse bg-slate-900 border border-white/10 rounded-[2.5rem] p-2 shadow-3xl z-[610] max-w-[calc(100vw-2rem)] overflow-x-auto custom-scrollbar"
             style={{ 
               top: Math.max(20, Math.min(contextMenu.y - 80, window.innerHeight - 200)) + 'px',
               left: contextMenu.message.senderId === user.Id_user ? 'auto' : '1rem',
               right: contextMenu.message.senderId === user.Id_user ? '1rem' : 'auto',
             }}
             onClick={e => e.stopPropagation()}
           >
              {QUICK_REACTIONS.map((emoji, idx) => (
                <button 
                  key={emoji} 
                  onClick={() => handleReaction(contextMenu.message.id, emoji)} 
                  className="p-1.5 hover:scale-125 transition-transform flex items-center justify-center"
                  style={{ animation: `popIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) ${idx * 0.06}s both` }}
                >
                  <EmojiImg emoji={emoji} size={28} />
                </button>
              ))}
              <button 
                onClick={() => { setEmojiTarget(contextMenu.message.id); setShowEmojiPicker(true); setContextMenu(null); setShowMoreContextOptions(false); }} 
                className="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-all flex-shrink-0 mx-1"
                style={{ animation: `popIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) ${QUICK_REACTIONS.length * 0.06}s both` }}
              >
                 <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4"/></svg>
              </button>
           </div>

           {/* Main Actions - Stuck to bottom */}
           <div className="w-full bg-slate-900 border-t border-white/10 flex items-center justify-between shadow-3xl pb-8 pt-2 px-2 animate-in slide-in-from-bottom duration-300" onClick={e => e.stopPropagation()}>
              <button onClick={() => { setReplyingTo(contextMenu.message); setContextMenu(null); setShowMoreContextOptions(false); }} className="flex-1 p-4 flex flex-col items-center justify-center hover:bg-white/5 transition-colors">
                 <svg className="w-6 h-6 text-blue-500 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6" strokeWidth={2}/></svg>
                 <span className="text-[10px] font-black text-white uppercase mt-1">{t("chat.replyAction")}</span>
              </button>
              
              {(!contextMenu.message.reelId && !contextMenu.message.imageUrl) ? (
                <button onClick={() => { navigator.clipboard.writeText(contextMenu.message.text); setContextMenu(null); setShowMoreContextOptions(false); }} className="flex-1 p-4 flex flex-col items-center justify-center hover:bg-white/5 transition-colors">
                   <svg className="w-6 h-6 text-green-500 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" strokeWidth={2}/></svg>
                   <span className="text-[10px] font-black text-white uppercase mt-1">{t("chat.copyAction")}</span>
                </button>
              ) : (
                <div className="flex-1"></div>
              )}
              
              <button
                onClick={async () => {
                  try {
                    const nextPinned = !contextMenu.message.pinned;
                    await updateDoc(doc(db, 'messages', contextMenu.message.id), {
                      pinned: nextPinned,
                      pinnedBy: nextPinned ? user.Id_user : null,
                      pinnedAt: nextPinned ? serverTimestamp() : null
                    });
                  } catch (err) {
                    console.error(err);
                  }
                  setContextMenu(null);
                  setShowMoreContextOptions(false);
                }}
                className="flex-1 p-4 flex flex-col items-center justify-center hover:bg-white/5 transition-colors"
              >
                 <svg className={`w-6 h-6 mb-1 ${contextMenu.message.pinned ? 'text-amber-400' : 'text-amber-500'}`} fill="currentColor" viewBox="0 0 24 24"><path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2z"/></svg>
                 <span className="text-[10px] font-black text-white uppercase mt-1">{contextMenu.message.pinned ? 'إلغاء التثبيت' : 'تثبيت'}</span>
              </button>

              <button onClick={() => { setShowForwardModal(contextMenu.message); setContextMenu(null); setShowMoreContextOptions(false); }} className="flex-1 p-4 flex flex-col items-center justify-center hover:bg-white/5 transition-colors">
                 <svg className="w-6 h-6 text-purple-500 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                 <span className="text-[10px] font-black text-white uppercase mt-1">{t("chat.forwardAction")}</span>
              </button>

              <button onClick={() => setShowMoreContextOptions(!showMoreContextOptions)} className="flex-1 p-4 flex flex-col items-center justify-center hover:bg-white/5 transition-colors">
                 <svg className={`w-6 h-6 text-slate-400 mb-1 transition-transform ${showMoreContextOptions ? 'rotate-45' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4"/></svg>
                 <span className="text-[10px] font-black text-slate-400 uppercase mt-1">{t("chat.moreAction")}</span>
              </button>
           </div>
           
           {/* More Options List */}
           {showMoreContextOptions && (
             <div className="absolute bottom-20 left-4 right-4 bg-slate-900 border border-white/10 rounded-3xl shadow-3xl overflow-hidden animate-in slide-in-from-bottom-4 duration-200" onClick={e => e.stopPropagation()}>
               {contextMenu.message.senderId === user.Id_user && (!contextMenu.message.imageUrl && !contextMenu.message.reelId && !contextMenu.message.voiceUrl) && (
                 <button onClick={() => { soundManager.playEditSound(); setEditingMessage(contextMenu.message); setInputMessage(contextMenu.message.text); setContextMenu(null); setShowMoreContextOptions(false); }} className="w-full p-4 flex flex-row-reverse items-center justify-between hover:bg-white/5 border-b border-white/5 transition-colors">
                    <span className="text-xs font-black text-white uppercase">{t("chat.editMessage")}</span>
                    <svg className="w-5 h-5 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" strokeWidth={2}/></svg>
                 </button>
               )}
               {contextMenu.message.senderId !== user.Id_user && (
                 <button onClick={async () => { 
                   await addDoc(collection(db, 'reports'), {
                     messageId: contextMenu.message.id,
                     reportedUser: contextMenu.message.senderId,
                     reportedBy: user.Id_user,
                     text: contextMenu.message.text || "",
                     timestamp: serverTimestamp()
                   });
                   alert(t("chat.reportedMsgSuccess"));
                   setContextMenu(null); 
                   setShowMoreContextOptions(false); 
                 }} className="w-full p-4 flex flex-row-reverse items-center justify-between hover:bg-orange-500/10 transition-colors border-b border-white/5">
                    <span className="text-xs font-black text-orange-500 uppercase">{t("chat.reportAction")}</span>
                    <svg className="w-5 h-5 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                 </button>
               )}
               <button onClick={async () => { soundManager.playDeleteSound(); await updateDoc(doc(db, 'messages', contextMenu.message.id), { deletedFor: arrayUnion(user.Id_user) }); setContextMenu(null); setShowMoreContextOptions(false); }} className={`w-full p-4 flex flex-row-reverse items-center justify-between hover:bg-red-500/10 transition-colors ${contextMenu.message.senderId === user.Id_user ? 'border-b border-white/5' : ''}`}>
                  <span className="text-xs font-black text-red-500 uppercase">{t("chat.deleteForMe")}</span>
                  <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7a4 4 0 11-8 0 4 4 0 018 0zM9 14a6 6 0 00-6 6v1h12v-1a6 6 0 00-6-6zM21 12h-6"/></svg>
               </button>
               {contextMenu.message.senderId === user.Id_user && (
                 <button onClick={async () => { soundManager.playDeleteSound(); await deleteDoc(doc(db, 'messages', contextMenu.message.id)); setContextMenu(null); setShowMoreContextOptions(false); }} className="w-full p-4 flex flex-row-reverse items-center justify-between hover:bg-red-500/10 transition-colors">
                    <span className="text-xs font-black text-red-500 uppercase">{t("chat.deleteForEveryone")}</span>
                    <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21" strokeWidth={2}/></svg>
                 </button>
               )}
             </div>
           )}
        </div>
      )}

      {showForwardModal && (
        <div className="fixed inset-0 z-[700] bg-black/80 backdrop-blur-md flex flex-col justify-end p-0">
          <div className="bg-slate-900 rounded-t-[2.5rem] w-full h-[80vh] flex flex-col animate-in slide-in-from-bottom p-6 shadow-2xl">
             <div className="flex justify-between items-center mb-6">
                <button onClick={() => setShowForwardModal(null)} className="p-2 bg-white/5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white">
                   <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2}/></svg>
                </button>
                <h2 className="text-lg font-black text-white">{t("chat.forwardTitle")}</h2>
             </div>
             
             <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4">
                {previews.map(chat => (
                   <button 
                     key={chat.id}
                     onClick={async () => {
                       try {
                         const messageData: any = {
                           senderId: user.Id_user, 
                           senderName: user.UserData, 
                           senderPhoto: user.photoURL || "",
                           text: encryptText(showForwardModal.text || ""), 
                           timestamp: serverTimestamp(),
                           forwarded: true
                         };
                         if (showForwardModal.imageUrl) messageData.imageUrl = showForwardModal.imageUrl;
                         if (showForwardModal.voiceUrl) messageData.voiceUrl = showForwardModal.voiceUrl;
                         if (showForwardModal.reelId) messageData.reelId = showForwardModal.reelId;
                         
                         if (chat.isGroup) {
                           messageData.groupId = chat.id;
                           messageData.readBy = [user.Id_user];
                         } else {
                           messageData.receiverId = chat.id;
                           messageData.receiverName = chat.name;
                           messageData.receiverPhoto = chat.photo || "";
                           messageData.read = false;
                         }
                         
                         await addDoc(collection(db, 'messages'), messageData);
                         setShowForwardModal(null);
                       } catch (e) {
                         console.error(e);
                       }
                     }}
                     className="w-full flex items-center p-4 bg-white/5 border border-white/5 rounded-[2rem] hover:bg-white/10 transition-all cursor-pointer"
                   >
                     <img src={chat.photo || `https://api.dicebear.com/7.x/bottts/svg?seed=${chat.id}`} className="w-12 h-12 rounded-2xl ml-4 object-cover" />
                     <div className="text-right flex-1">
                        <h4 className="text-[11px] font-black text-white">{chat.name}</h4>
                        <p className="text-[10px] text-slate-500">{chat.isGroup ? t('chat.groupLabel') : t('chat.contactLabel')}</p>
                     </div>
                     <svg className="w-6 h-6 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                   </button>
                ))}
             </div>
          </div>
        </div>
      )}

      {/* Avatar Context Menu */}
      {avatarMenuTarget && (
        <div className="fixed inset-0 z-[500] bg-black/80 backdrop-blur-md flex items-center justify-center p-6" onClick={() => setAvatarMenuTarget(null)}>
          <div className="w-full max-w-sm glass p-8 rounded-[3rem] text-right animate-in zoom-in duration-300" onClick={e => e.stopPropagation()}>
            <div className="flex flex-col items-center mb-8">
              <img src={avatarMenuTarget.photo || `https://api.dicebear.com/7.x/bottts/svg?seed=${avatarMenuTarget.id}`} className="w-24 h-24 rounded-[2.5rem] border-4 border-blue-600 p-1 bg-slate-900 shadow-2xl mb-4" />
              <h3 className="text-xl font-black text-white">{avatarMenuTarget.name}</h3>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">@{avatarMenuTarget.id.substring(0, 12)}</p>
            </div>

            <div className="space-y-3">
              <button 
                onClick={() => {
                  setActiveChat({ id: avatarMenuTarget.id, name: avatarMenuTarget.name, photo: avatarMenuTarget.photo, isGroup: false });
                  setMode('activeChat');
                  setAvatarMenuTarget(null);
                }}
                className="w-full p-5 bg-blue-600 text-white rounded-3xl font-black text-xs flex items-center justify-between space-x-4 space-x-reverse shadow-xl shadow-blue-600/20"
              >
                <span>{t("profile.message")}</span>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" strokeWidth={2.5}/></svg>
              </button>

              {!user.friendsList?.includes(avatarMenuTarget.id) && avatarMenuTarget.id !== user.Id_user && (
                <button 
                  onClick={async () => {
                    const isSent = user.sentRequests?.includes(avatarMenuTarget.id);
                    const isPending = user.pendingRequests?.includes(avatarMenuTarget.id);

                    if (isSent) {
                      // Cancel request
                      await updateDoc(doc(db, 'users', user.Id_user), { sentRequests: arrayRemove(avatarMenuTarget.id) });
                      await updateDoc(doc(db, 'users', avatarMenuTarget.id), { pendingRequests: arrayRemove(user.Id_user) });
                    } else if (isPending) {
                      // Accept request
                      await updateDoc(doc(db, 'users', user.Id_user), { 
                        pendingRequests: arrayRemove(avatarMenuTarget.id),
                        friendsList: arrayUnion(avatarMenuTarget.id)
                      });
                      await updateDoc(doc(db, 'users', avatarMenuTarget.id), { 
                        sentRequests: arrayRemove(user.Id_user),
                        friendsList: arrayUnion(user.Id_user)
                      });
                      
                      await addDoc(collection(db, 'notifications'), {
                        toId: avatarMenuTarget.id,
                        fromId: user.Id_user,
                        fromName: user.UserData,
                        fromPhoto: user.photoURL,
                        type: 'accept_friend',
                        read: false,
                        timestamp: serverTimestamp()
                      });
                    } else {
                      // Send request
                      await updateDoc(doc(db, 'users', user.Id_user), { sentRequests: arrayUnion(avatarMenuTarget.id) });
                      await updateDoc(doc(db, 'users', avatarMenuTarget.id), { pendingRequests: arrayUnion(user.Id_user) });
                      
                      await addDoc(collection(db, 'notifications'), {
                        toId: avatarMenuTarget.id,
                        fromId: user.Id_user,
                        fromName: user.UserData,
                        fromPhoto: user.photoURL,
                        type: 'friend_request',
                        read: false,
                        timestamp: serverTimestamp()
                      });
                    }
                    setAvatarMenuTarget(null);
                  }}
                  className={`w-full p-5 rounded-3xl font-black text-xs flex items-center justify-between space-x-4 space-x-reverse border ${
                    user.sentRequests?.includes(avatarMenuTarget.id) ? 'bg-blue-600/20 text-blue-400 border-blue-500/30' :
                    user.pendingRequests?.includes(avatarMenuTarget.id) ? 'bg-green-600/20 text-green-400 border-green-500/30' :
                    'bg-white/5 text-white border-white/10'
                  }`}
                >
                  <span>
                    {user.sentRequests?.includes(avatarMenuTarget.id) ? t('chat.friendRequestSent') :
                     user.pendingRequests?.includes(avatarMenuTarget.id) ? t('chat.friendRequestAccept') :
                     t('chat.addFriend')}
                  </span>
                  {!user.sentRequests?.includes(avatarMenuTarget.id) && !user.pendingRequests?.includes(avatarMenuTarget.id) && <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" strokeWidth={2.5}/></svg>}
                </button>
              )}

              {isMeAdmin && avatarMenuTarget.id !== user.Id_user && (
                <>
                  {!activeChat.admins?.includes(avatarMenuTarget.id) && (
                    <button 
                      onClick={() => { makeAdmin(avatarMenuTarget.id, avatarMenuTarget.name); setAvatarMenuTarget(null); }}
                      className="w-full p-5 bg-blue-600/10 text-blue-500 rounded-3xl font-black text-xs flex items-center justify-between space-x-4 space-x-reverse border border-blue-500/20"
                    >
                      <span>{t("chat.addAdmin")}</span>
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-9.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" strokeWidth={2.5}/></svg>
                    </button>
                  )}
                  <button 
                    onClick={() => { kickMember(avatarMenuTarget.id, avatarMenuTarget.name); setAvatarMenuTarget(null); }}
                    className="w-full p-5 bg-red-600/10 text-red-500 rounded-3xl font-black text-xs flex items-center justify-between space-x-4 space-x-reverse border border-red-500/20"
                  >
                    <span>{t("chat.kickMember")}</span>
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
                  </button>
                </>
              )}

              <button 
                onClick={() => { onNavigateProfile?.(avatarMenuTarget.id); setAvatarMenuTarget(null); }}
                className="w-full p-5 bg-white/5 text-slate-400 rounded-3xl font-black text-xs flex items-center justify-between space-x-4 space-x-reverse border border-white/10"
              >
                <span>{t("chat.viewProfile")}</span>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" strokeWidth={2.5}/></svg>
              </button>

              <button onClick={() => setAvatarMenuTarget(null)} className="w-full py-4 text-center text-[10px] font-black text-slate-600 uppercase tracking-widest">{t("chat.closeModal")}</button>
            </div>
          </div>
        </div>
      )}

      {/* Messaging Restriction Appeal Modal */}
      {showAppealModal && (
        <div className="fixed inset-0 z-[600] bg-black/85 backdrop-blur-md flex items-center justify-center p-6 animate-in zoom-in">
          <div className="w-full max-w-sm glass bg-slate-900 border border-white/10 p-6 rounded-[2rem] text-right shadow-2xl">
            <h3 className="text-base font-black text-white mb-2 text-center">{t("chat.appealTitle")}</h3>
            <p className="text-xs text-slate-400 mb-5 text-center leading-relaxed">
              {t("chat.appealDesc")}
            </p>

            {appealSuccess ? (
              <div className="py-8 text-center">
                <div className="w-14 h-14 bg-green-500/20 text-green-400 rounded-full flex items-center justify-center mx-auto mb-3 border border-green-500/30">
                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>
                </div>
                <h4 className="text-white font-black text-sm mb-1">{t("chat.appealSuccessTitle")}</h4>
                <p className="text-slate-400 text-[11px] font-bold">{t("chat.appealSuccessDesc")}</p>
              </div>
            ) : (
              <div className="space-y-3">
                <button 
                  onClick={() => setAppealReason('innocent')}
                  className={`w-full p-3.5 rounded-2xl border text-xs font-black transition-all flex items-center justify-between ${appealReason === 'innocent' ? 'bg-blue-600 border-blue-500 text-white' : 'bg-black/30 border-white/10 text-slate-300'}`}
                >
                  <span>{t("chat.appealInnocentReason")}</span>
                  {appealReason === 'innocent' && <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>}
                </button>

                <button 
                  onClick={() => setAppealReason('apology')}
                  className={`w-full p-3.5 rounded-2xl border text-xs font-black transition-all flex items-center justify-between ${appealReason === 'apology' ? 'bg-blue-600 border-blue-500 text-white' : 'bg-black/30 border-white/10 text-slate-300'}`}
                >
                  <span>{t("chat.appealApologyReason")}</span>
                  {appealReason === 'apology' && <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>}
                </button>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold mb-1.5">{t("chat.appealExtraExplanation")}</label>
                  <textarea 
                    value={appealExplanation}
                    onChange={e => setAppealExplanation(e.target.value)}
                    rows={3}
                    placeholder={t("chat.appealExtraPlaceholder")}
                    className="w-full bg-black/40 border border-white/10 rounded-2xl p-3 text-white text-xs outline-none focus:border-blue-500 resize-none"
                  />
                </div>

                <div className="flex gap-2.5 pt-2">
                  <button 
                    onClick={handleSendMessagingAppeal}
                    disabled={isSubmittingAppeal}
                    className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-black text-xs transition-all disabled:opacity-50 shadow-lg shadow-blue-600/30"
                  >
                    {isSubmittingAppeal ? t('chat.submitting') : t('chat.submitAppealBtn')}
                  </button>
                  <button 
                    onClick={() => setShowAppealModal(false)}
                    className="px-5 py-3 bg-white/5 border border-white/10 rounded-xl text-slate-400 font-bold text-xs hover:bg-white/10 transition-all"
                  >{t("common.cancel")}</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Fullscreen Image Preview Modal */}
      {previewImage && (
        <div 
          onClick={() => setPreviewImage(null)}
          className="fixed inset-0 z-[700] bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-center p-4 animate-in fade-in duration-200 select-none cursor-zoom-out"
        >
          <div className="absolute top-4 right-4 z-50 flex items-center space-x-3 space-x-reverse" onClick={e => e.stopPropagation()}>
            <a 
              href={previewImage} 
              target="_blank" 
              rel="noopener noreferrer" 
              download 
              className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl backdrop-blur-md transition-all flex items-center space-x-1.5 space-x-reverse text-xs font-bold"
              title={t("chat.openDownload")}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              <span>{t("chat.openPhoto")}</span>
            </a>
            <button 
              onClick={() => setPreviewImage(null)}
              className="p-3 bg-white/10 hover:bg-red-600/80 text-white rounded-2xl backdrop-blur-md transition-all"
              title={t("common.close")}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
          </div>
          <img 
            src={previewImage} 
            alt={t("chat.fullPreview")} 
            onClick={e => e.stopPropagation()} 
            className="max-w-[92vw] max-h-[85vh] object-contain rounded-2xl shadow-2xl border border-white/10 animate-in zoom-in-95 duration-200 cursor-default"
          />
        </div>
      )}

      {showEmojiStyleModal && (
        <EmojiStyleModal onClose={() => setShowEmojiStyleModal(false)} />
      )}

      <ImageCropperModal
        file={pendingGroupCropFile}
        title="تحديد جزء صورة المجموعة (1:1)"
        onCancel={() => setPendingGroupCropFile(null)}
        onConfirm={uploadCroppedGroupPhoto}
      />
    </div>
  );
};

export default AIChatView;
