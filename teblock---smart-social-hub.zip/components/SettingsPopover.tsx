
import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { useLanguage } from '../utils/i18n';

interface SettingsPopoverProps {
  user: User;
  theme: string;
  onThemeChange: (t: string) => void;
  onLogout: () => void;
  onNavigateProfile: (id: string) => void;
  onClose: () => void;
  onSwitchAccount: (userId: string) => void;
  onNavigateSavedReels: () => void;
  onNavigateSettings: () => void;
  onShowDebug: () => void;
  onOpenEmojiStyle?: () => void;
  onOpenLanguageModal?: () => void;
}

const SettingsPopover: React.FC<SettingsPopoverProps> = ({ 
  user, theme, onThemeChange, onLogout, onNavigateProfile, onClose, onSwitchAccount, onNavigateSavedReels, onNavigateSettings, onShowDebug, onOpenEmojiStyle, onOpenLanguageModal 
}) => {
  const { t, langInfo } = useLanguage();
  const [showAccounts, setShowAccounts] = useState(false);
  const [savedAccounts, setSavedAccounts] = useState<User[]>([]);

  useEffect(() => {
    const accounts = JSON.parse(localStorage.getItem('teblock_multi_accounts') || '[]');
    setSavedAccounts(accounts.filter((a: User) => a.Id_user !== user.Id_user));
  }, [user.Id_user]);

  const themes = [
    { id: 'deepblue', label: t('settings.themeDeepBlue'), icon: '🌌' },
    { id: 'white', label: t('settings.themeWhite'), icon: '⚪' },
    { id: 'pureblack', label: t('settings.themePureBlack'), icon: '⚫' },
    { id: 'brown', label: t('settings.themeBrown'), icon: '🟤' }
  ];

  return (
    <div className="absolute top-16 rtl:left-4 ltr:right-4 sm:rtl:left-6 sm:ltr:right-6 w-72 bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl z-[200] animate-in zoom-in-95 duration-200 overflow-hidden">
      <div className="p-4 space-y-4">
        {/* Profile Section */}
        <div className="flex items-center justify-between bg-white/5 p-3 rounded-2xl">
          <button 
            onClick={() => { onNavigateProfile(user['id-2'] || user.Id_user); onClose(); }}
            className="flex items-center space-x-3 space-x-reverse"
          >
            <img src={user.photoURL} className="w-10 h-10 rounded-xl border border-blue-500/30" />
            <div className="rtl:text-right ltr:text-left">
              <p className="text-[10px] font-black text-white">{user.UserData}</p>
              <p className="text-[8px] text-slate-500 font-bold">{t('nav.profile')}</p>
            </div>
          </button>
          
          <button 
            onClick={() => setShowAccounts(!showAccounts)}
            className="p-2 bg-blue-600/20 text-blue-500 rounded-xl hover:bg-blue-600/30 transition-colors"
          >
            <svg className="w-5 h-5 flip-in-ltr" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" strokeWidth={2.5}/></svg>
          </button>
        </div>

        {/* Accounts List (Sub-menu) */}
        {showAccounts && (
          <div className="bg-black/40 rounded-2xl p-2 space-y-2 animate-in slide-in-from-top-2">
            <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest px-2">{t('auth.accountType')}</p>
            {savedAccounts.length > 0 ? (
              savedAccounts.map(acc => (
                <button 
                  key={acc.Id_user}
                  onClick={() => onSwitchAccount(acc.Id_user)}
                  className="w-full flex items-center space-x-3 space-x-reverse p-2 hover:bg-white/5 rounded-xl transition-colors rtl:text-right ltr:text-left"
                >
                  <img src={acc.photoURL} className="w-8 h-8 rounded-lg" />
                  <span className="text-[10px] font-bold text-slate-300">{acc.UserData}</span>
                </button>
              ))
            ) : (
              <p className="text-[9px] text-slate-500 px-2 py-1">{t('settings.noOtherAccounts')}</p>
            )}
          </div>
        )}

        {/* Themes Section */}
        <div className="space-y-2">
          <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest px-2">{t('common.theme')}</p>
          <div className="grid grid-cols-4 gap-2">
            {themes.map(tItem => (
              <button 
                key={tItem.id} 
                onClick={() => onThemeChange(tItem.id)}
                className={`p-2 rounded-xl border transition-all flex flex-col items-center justify-center ${theme === tItem.id ? 'border-blue-600 bg-blue-600/10' : 'border-white/5 bg-white/5'}`}
              >
                <span className="text-sm">{tItem.icon}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-1">
          {onOpenLanguageModal && (
            <button 
              onClick={() => { onOpenLanguageModal(); onClose(); }}
              className="w-full p-3 rtl:text-right ltr:text-left flex items-center justify-between hover:bg-white/5 rounded-2xl transition-colors group"
            >
              <div className="flex items-center space-x-2 space-x-reverse">
                <span className="text-base group-hover:scale-125 transition-transform">🌐</span>
                <span className="text-[10px] font-black text-slate-300">{t('lang.title')}</span>
              </div>
              <div className="flex items-center space-x-1.5 space-x-reverse">
                <span className="text-[9px] bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full font-bold">
                  {langInfo.flag} {langInfo.nativeName}
                </span>
              </div>
            </button>
          )}

          {onOpenEmojiStyle && (
            <button 
              onClick={() => { onOpenEmojiStyle(); onClose(); }}
              className="w-full p-3 rtl:text-right ltr:text-left flex items-center justify-between hover:bg-white/5 rounded-2xl transition-colors group"
            >
              <div className="flex items-center space-x-1.5 space-x-reverse">
                <span className="text-[9px] bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full font-bold">★</span>
                <span className="text-[10px] font-black text-slate-300">{t('common.emojiStyle')}</span>
              </div>
              <span className="text-base group-hover:scale-125 transition-transform">😍</span>
            </button>
          )}

          <button 
            onClick={() => { onNavigateSavedReels(); onClose(); }}
            className="w-full p-3 rtl:text-right ltr:text-left flex items-center justify-between hover:bg-white/5 rounded-2xl transition-colors"
          >
            <span className="text-[10px] font-black text-slate-300">{t('common.savedReels')}</span>
            <svg className="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" strokeWidth={2}/></svg>
          </button>

          <button 
            onClick={onNavigateSettings}
            className="w-full p-3 rtl:text-right ltr:text-left flex items-center justify-between hover:bg-white/5 rounded-2xl transition-colors"
          >
            <span className="text-[10px] font-black text-slate-300">{t('nav.settings')}</span>
            <svg className="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37a1.724 1.724 0 002.572-1.065z" strokeWidth={2}/><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" strokeWidth={2}/></svg>
          </button>
          
          <button 
            onClick={onLogout}
            className="w-full p-3 rtl:text-right ltr:text-left flex items-center justify-between hover:bg-red-500/10 rounded-2xl transition-colors group"
          >
            <span className="text-[10px] font-black text-red-500">{t('auth.logout')}</span>
            <svg className="w-4 h-4 text-red-500 group-hover:translate-x-1 flip-in-ltr transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17 16l4-4m0 0l-4-4m4 4H7" strokeWidth={3}/></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPopover;
