import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { db } from '../firebase';
import { 
  doc, updateDoc, collection, query, where, getDocs, getDoc, 
  deleteDoc, onSnapshot, arrayRemove, arrayUnion, serverTimestamp 
} from 'firebase/firestore';
import { useLanguage } from '../utils/i18n';
import LanguageModal from './LanguageModal';
import { encryptText, decryptText } from '../utils/crypto';
import { compressImageFile } from '../utils/mediaOptimizer';
import ImageCropperModal from './ImageCropperModal';

interface AccountSettingsViewProps {
  user: User;
  onBack: () => void;
  onLogout: () => void;
  onOpenLanguageModal?: () => void;
}

type ActiveModal = 
  | null 
  | 'editProfile' 
  | 'securityPassword' 
  | 'privacyOption' 
  | 'commentFiltering' 
  | 'blockedUsers' 
  | 'deactivateAccount' 
  | 'deleteAccount' 
  | 'language';

interface PrivacyOptionConfig {
  field: 'whoCanSendFriendRequests' | 'whoCanSeeFriendsList' | 'whoCanSendChatRequests' | 'directMessagesPermission';
  title: string;
  description: string;
  options: { value: string; label: string; icon?: string }[];
}

const CLOUD_NAME = "dei75gqcl";
const UPLOAD_PRESET = "TEBLOCK";

// Word bank for generating memorable Arabic secret passphrases
const PASSPHRASE_WORDS = [
  'نجم', 'صقر', 'واحة', 'قمر', 'درع', 'سيف', 'نهر', 'سحاب', 
  'رمح', 'فجر', 'بحر', 'شهاب', 'فارس', 'طويق', 'أطلس', 'أرز'
];

const generateSecretPassphrase = (): string => {
  const selected: string[] = [];
  for (let i = 0; i < 4; i++) {
    const randomWord = PASSPHRASE_WORDS[Math.floor(Math.random() * PASSPHRASE_WORDS.length)];
    selected.push(randomWord);
  }
  const randomNum = Math.floor(1000 + Math.random() * 9000);
  return `TEB-${selected.join('-')}-${randomNum}`;
};

const AccountSettingsView: React.FC<AccountSettingsViewProps> = ({ 
  user: initialUser, 
  onBack, 
  onLogout, 
  onOpenLanguageModal 
}) => {
  const { t, langInfo, dir } = useLanguage();
  const [currentUser, setCurrentUser] = useState<User>(initialUser);
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [privacyOptionConfig, setPrivacyOptionConfig] = useState<PrivacyOptionConfig | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'error'>('success');

  // Edit Profile Form State
  const [editName, setEditName] = useState(initialUser.UserData || '');
  const [editBio, setEditBio] = useState(initialUser.bio || '');
  const [editId, setEditId] = useState(initialUser.Id_user || '');
  const [editPhotoURL, setEditPhotoURL] = useState(initialUser.photoURL || '');
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Security & Password Form State
  const [currentPasswordInput, setCurrentPasswordInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [showPasswordText, setShowPasswordText] = useState(false);
  const [passphraseCopied, setPassphraseCopied] = useState(false);

  // Comment Filtering State (for Pages)
  const [newKeywordInput, setNewKeywordInput] = useState('');
  const [commentKeywords, setCommentKeywords] = useState<string[]>(initialUser.blockedCommentKeywords || []);

  // Blocked Users State
  const [blockedUsersDetails, setBlockedUsersDetails] = useState<{ id: string; name: string; photoURL?: string }[]>([]);
  const [loadingBlocked, setLoadingBlocked] = useState(false);

  // Danger Zone Password Input State
  const [dangerPassword, setDangerPassword] = useState('');
  const [deleteConfirmText, setDeleteConfirmText] = useState('');

  const isPage = currentUser.accountType === 'page';

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Sync with Firestore in real-time
  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'users', initialUser.Id_user), (snap) => {
      if (snap.exists()) {
        const data = snap.data() as User;
        setCurrentUser(data);
        setEditName(data.UserData || '');
        setEditBio(data.bio || '');
        setEditId(data.Id_user || '');
        setEditPhotoURL(data.photoURL || '');
        setCommentKeywords(data.blockedCommentKeywords || []);
      }
    });
    return () => unsub();
  }, [initialUser.Id_user]);

  // Load details of blocked users when opening blocked users modal
  useEffect(() => {
    if (activeModal === 'blockedUsers') {
      const blockedList = currentUser.blockedUsers || [];
      if (blockedList.length === 0) {
        setBlockedUsersDetails([]);
        return;
      }

      setLoadingBlocked(true);
      Promise.all(
        blockedList.map(async (uid) => {
          try {
            const snap = await getDoc(doc(db, 'users', uid));
            if (snap.exists()) {
              const uData = snap.data();
              return { id: uid, name: uData.UserData || uid, photoURL: uData.photoURL };
            }
          } catch (e) {
            console.error(e);
          }
          return { id: uid, name: uid };
        })
      ).then((res) => {
        setBlockedUsersDetails(res);
        setLoadingBlocked(false);
      });
    }
  }, [activeModal, currentUser.blockedUsers]);

  // --------------------------------------------------------------------------
  // 1. Account & Security Handlers
  // --------------------------------------------------------------------------

  const [pendingCropFile, setPendingCropFile] = useState<File | null>(null);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';
    setPendingCropFile(file);
  };

  const handleConfirmCroppedPhoto = async (croppedFile: File) => {
    setPendingCropFile(null);
    setIsUploadingPhoto(true);
    try {
      const compressedFile = await compressImageFile(croppedFile, 800, 0.88);
      const formData = new FormData();
      formData.append('file', compressedFile);
      formData.append('upload_preset', UPLOAD_PRESET);

      const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (data.secure_url) {
        setEditPhotoURL(data.secure_url);
        showToast('تم رفع الصورة بنجاح');
      } else {
        throw new Error('Upload error');
      }
    } catch (err) {
      console.error(err);
      showToast('فشل رفع الصورة، يرجى المحاولة لاحقاً', 'error');
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!editName.trim()) {
      showToast('الاسم الظاهر لا يمكن أن يكون فارغاً', 'error');
      return;
    }

    setIsLoading(true);
    try {
      const userRef = doc(db, 'users', currentUser.Id_user);
      await updateDoc(userRef, {
        UserData: editName.trim(),
        bio: editBio.trim(),
        photoURL: editPhotoURL.trim()
      });

      showToast('تم تحديث الملف الشخصي بنجاح');
      setActiveModal(null);
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء حفظ التعديلات', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdatePassword = async () => {
    if (!currentPasswordInput || !newPasswordInput || !confirmPasswordInput) {
      showToast('يرجى ملء جميع حقول كلمة المرور', 'error');
      return;
    }

    if (newPasswordInput !== confirmPasswordInput) {
      showToast('كلمة المرور الجديدة غير متطابقة مع التأكيد', 'error');
      return;
    }

    if (newPasswordInput.length < 6) {
      showToast('يجب أن تتكون كلمة المرور الجديدة من 6 أحرف على الأقل', 'error');
      return;
    }

    setIsLoading(true);
    try {
      const userDocSnap = await getDoc(doc(db, 'users', currentUser.Id_user));
      if (!userDocSnap.exists()) {
        showToast('لم يتم العثور على الحساب', 'error');
        return;
      }

      const storedEncrypted = userDocSnap.data().password;
      const decrypted = decryptText(storedEncrypted);

      if (decrypted !== currentPasswordInput) {
        showToast('كلمة المرور الحالية غير صحيحة', 'error');
        return;
      }

      // Update password
      await updateDoc(doc(db, 'users', currentUser.Id_user), {
        password: encryptText(newPasswordInput)
      });

      showToast('تم تغيير كلمة المرور بنجاح');
      setCurrentPasswordInput('');
      setNewPasswordInput('');
      setConfirmPasswordInput('');
      setActiveModal(null);
    } catch (e) {
      console.error(e);
      showToast('تعذر تغيير كلمة المرور', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateNewPassphrase = async () => {
    const newCode = generateSecretPassphrase();
    setIsLoading(true);
    try {
      await updateDoc(doc(db, 'users', currentUser.Id_user), {
        secretPassphrase: newCode
      });
      showToast('تم إنشاء رمز استعادة أمان جديد وحفظه');
    } catch (e) {
      console.error(e);
      showToast('تعذر إنشاء الرمز السري', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyPassphrase = (code: string) => {
    navigator.clipboard.writeText(code);
    setPassphraseCopied(true);
    setTimeout(() => setPassphraseCopied(false), 2000);
    showToast('تم نسخ رمز الأمان إلى الحافظة');
  };

  // --------------------------------------------------------------------------
  // 2. Privacy Controls Handlers
  // --------------------------------------------------------------------------

  const handleTogglePrivateAccount = async () => {
    const targetState = !currentUser.isPrivate;
    try {
      await updateDoc(doc(db, 'users', currentUser.Id_user), {
        isPrivate: targetState
      });
      showToast(targetState ? 'تم تفعيل الحساب الخاص' : 'تم تحويل الحساب إلى عام');
    } catch (e) {
      console.error(e);
      showToast('تعذر تحديث إعدادات الخصوصية', 'error');
    }
  };

  const openPrivacyOptionModal = (
    field: 'whoCanSendFriendRequests' | 'whoCanSeeFriendsList' | 'whoCanSendChatRequests' | 'directMessagesPermission',
    title: string,
    description: string,
    options: { value: string; label: string; icon?: string }[]
  ) => {
    setPrivacyOptionConfig({ field, title, description, options });
    setActiveModal('privacyOption');
  };

  const handleSelectPrivacyOption = async (value: string) => {
    if (!privacyOptionConfig) return;
    setIsLoading(true);
    try {
      await updateDoc(doc(db, 'users', currentUser.Id_user), {
        [privacyOptionConfig.field]: value
      });
      showToast('تم تحديث الإعداد بنجاح');
      setActiveModal(null);
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء الحفظ', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddCommentKeyword = () => {
    const kw = newKeywordInput.trim().toLowerCase();
    if (!kw) return;
    if (commentKeywords.includes(kw)) {
      showToast('هذه الكلمة مضافة مسبقاً', 'error');
      return;
    }
    const updated = [...commentKeywords, kw];
    setCommentKeywords(updated);
    setNewKeywordInput('');
    updateDoc(doc(db, 'users', currentUser.Id_user), {
      blockedCommentKeywords: updated
    }).catch(console.error);
    showToast('تمت إضافة الكلمة إلى قائمة الحظر');
  };

  const handleRemoveCommentKeyword = (kw: string) => {
    const updated = commentKeywords.filter(k => k !== kw);
    setCommentKeywords(updated);
    updateDoc(doc(db, 'users', currentUser.Id_user), {
      blockedCommentKeywords: updated
    }).catch(console.error);
    showToast('تمت إزالة الكلمة');
  };

  const handleUnblockUser = async (targetId: string) => {
    try {
      await updateDoc(doc(db, 'users', currentUser.Id_user), {
        blockedUsers: arrayRemove(targetId)
      });
      setBlockedUsersDetails(prev => prev.filter(u => u.id !== targetId));
      showToast('تم فك الحظر بنجاح');
    } catch (e) {
      console.error(e);
      showToast('فشل فك الحظر', 'error');
    }
  };

  // --------------------------------------------------------------------------
  // 3. Danger Zone Handlers
  // --------------------------------------------------------------------------

  const handleDeactivateAccount = async () => {
    if (!dangerPassword) {
      showToast('يرجى إدخال كلمة المرور لتأكيد إيقاف النشاط', 'error');
      return;
    }

    setIsLoading(true);
    try {
      const snap = await getDoc(doc(db, 'users', currentUser.Id_user));
      if (!snap.exists()) {
        showToast('الحساب غير موجود', 'error');
        return;
      }
      const decrypted = decryptText(snap.data().password);
      if (decrypted !== dangerPassword) {
        showToast('كلمة المرور غير صحيحة', 'error');
        return;
      }

      // Freeze / Deactivate account
      await updateDoc(doc(db, 'users', currentUser.Id_user), {
        isDeactivated: true,
        deactivatedAt: serverTimestamp(),
        Freeaccount: "مجمد"
      });

      // Clear sessions
      localStorage.removeItem('teblock_active_id');
      const accounts = JSON.parse(localStorage.getItem('teblock_multi_accounts') || '[]');
      const filtered = accounts.filter((a: any) => a.Id_user !== currentUser.Id_user);
      localStorage.setItem('teblock_multi_accounts', JSON.stringify(filtered));

      alert('تم إيقاف نشاط حسابك وإخفاؤه بنجاح. يمكنك استئناف نشاطه في أي وقت بمجرد تسجيل الدخول مجدداً.');
      onLogout();
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء تجميد الحساب', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteAccountPermanent = async () => {
    if (!dangerPassword) {
      showToast('يرجى إدخال كلمة المرور للتأكيد النهائي', 'error');
      return;
    }

    if (deleteConfirmText.trim() !== 'حذف' && deleteConfirmText.trim().toLowerCase() !== 'delete') {
      showToast('يرجى كتابة كلمة "حذف" في حقل التأكيد', 'error');
      return;
    }

    setIsLoading(true);
    try {
      const snap = await getDoc(doc(db, 'users', currentUser.Id_user));
      if (!snap.exists()) {
        showToast('الحساب غير موجود', 'error');
        return;
      }
      const decrypted = decryptText(snap.data().password);
      if (decrypted !== dangerPassword) {
        showToast('كلمة المرور غير صحيحة', 'error');
        return;
      }

      const uid = currentUser.Id_user;

      // 1. Delete user reels
      const reelsQ = query(collection(db, 'reels'), where('userId', '==', uid));
      const reelsSnap = await getDocs(reelsQ);
      for (const d of reelsSnap.docs) await deleteDoc(d.ref);

      // 2. Delete user messages
      const msgQ = query(collection(db, 'messages'), where('senderId', '==', uid));
      const msgSnap = await getDocs(msgQ);
      for (const d of msgSnap.docs) await deleteDoc(d.ref);

      // 3. Delete user notes
      const notesQ = query(collection(db, 'notes'), where('userId', '==', uid));
      const notesSnap = await getDocs(notesQ);
      for (const d of notesSnap.docs) await deleteDoc(d.ref);

      // 4. Delete user notifications (both received and sent)
      const notifToQ = query(collection(db, 'notifications'), where('toId', '==', uid));
      const notifToSnap = await getDocs(notifToQ);
      for (const d of notifToSnap.docs) await deleteDoc(d.ref);

      const notifFromQ = query(collection(db, 'notifications'), where('fromId', '==', uid));
      const notifFromSnap = await getDocs(notifFromQ);
      for (const d of notifFromSnap.docs) await deleteDoc(d.ref);

      // 5. Delete user doc itself
      await deleteDoc(doc(db, 'users', uid));

      // 6. Clear storage and multi-account entries
      localStorage.removeItem('teblock_active_id');
      const accounts = JSON.parse(localStorage.getItem('teblock_multi_accounts') || '[]');
      const filtered = accounts.filter((a: any) => a.Id_user !== uid);
      localStorage.setItem('teblock_multi_accounts', JSON.stringify(filtered));

      alert('تم حذف الحساب ومسح كافة البيانات والرسائل والوسائط بشكل نهائي لا رجعة فيه.');
      onLogout();
    } catch (e) {
      console.error(e);
      showToast('تعذر حذف الحساب، يرجى المحاولة لاحقاً', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // Support phone back button for open sub-modals
  useEffect(() => {
    if (activeModal) {
      window.history.pushState({ settingsModal: activeModal }, '', window.location.pathname);
    }
  }, [activeModal]);

  useEffect(() => {
    const onPopState = () => {
      if (activeModal) {
        setActiveModal(null);
      }
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [activeModal]);

  // Ensure user has a passphrase if opened
  const currentPassphrase = currentUser.secretPassphrase || 'TEB-نجم-صقر-فجر-طويق-9921';

  return (
    <div dir={dir} className="fixed inset-0 z-[400] bg-slate-950 flex flex-col animate-in fade-in duration-300 overflow-y-auto custom-scrollbar select-none">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`fixed top-5 left-1/2 -translate-x-1/2 z-[1000] px-5 py-3 rounded-2xl shadow-2xl backdrop-blur-xl border text-xs font-black animate-in fade-in slide-in-from-top-4 flex items-center space-x-2 space-x-reverse ${
          toastType === 'success' 
            ? 'bg-emerald-950/90 text-emerald-300 border-emerald-500/40 shadow-emerald-950/50' 
            : 'bg-red-950/90 text-red-300 border-red-500/40 shadow-red-950/50'
        }`}>
          <span>{toastType === 'success' ? '✓' : '⚠️'}</span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="px-4 pb-4 pt-[max(1rem,env(safe-area-inset-top))] sm:p-6 flex items-center justify-between sticky top-0 bg-slate-950/95 backdrop-blur-2xl z-40 border-b border-white/5">
        <button 
          onClick={onBack} 
          className="p-3 bg-white/5 rounded-2xl text-slate-400 hover:text-white hover:bg-white/10 active:scale-95 transition-all shadow-sm"
          title="رجوع"
        >
          <svg className="w-5 h-5 flip-in-ltr" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7" strokeWidth={2.5}/></svg>
        </button>
        <div className="text-center">
          <h2 className="text-base font-black text-white uppercase tracking-wider">صفحة الإعدادات</h2>
          <p className="text-[10px] text-slate-400 font-bold">التحكم في الحساب، الخصوصية والأمان</p>
        </div>
        <button 
          onClick={() => onOpenLanguageModal ? onOpenLanguageModal() : setActiveModal('language')}
          className="p-2 sm:px-3 sm:py-2 bg-white/5 hover:bg-white/10 rounded-2xl text-slate-300 text-xs font-bold border border-white/5 transition-all flex items-center space-x-1.5 space-x-reverse active:scale-95"
          title="تبديل اللغة"
        >
          <span className="text-base">{langInfo.flag}</span>
          <span className="hidden sm:inline text-[11px] font-black">{langInfo.nativeName}</span>
        </button>
      </div>

      <div className="p-4 sm:p-6 md:p-8 space-y-6 pb-28 max-w-3xl mx-auto w-full">
        {/* Profile Card Header */}
        <div className="relative p-6 sm:p-8 bg-gradient-to-b from-blue-600/15 via-indigo-600/5 to-transparent border border-blue-500/20 rounded-[2.5rem] flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 sm:space-x-reverse text-center sm:text-right overflow-hidden shadow-2xl">
          <div className="relative shrink-0">
            <img 
              src={currentUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.Id_user}`} 
              alt="Avatar" 
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-[2rem] object-cover border-4 border-slate-900 shadow-2xl bg-slate-800" 
            />
            <span className={`absolute -bottom-1 -left-1 px-2 py-0.5 rounded-full text-[9px] font-black text-white shadow-md border border-slate-900 ${isPage ? 'bg-indigo-600' : 'bg-blue-600'}`}>
              {isPage ? 'صفحة' : 'شخصي'}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-xl font-black text-white truncate">{currentUser.UserData}</h3>
            <p className="text-xs text-blue-400 font-mono font-bold mt-0.5">@{currentUser.Id_user}</p>
            {currentUser.bio ? (
              <p className="text-xs text-slate-300 font-medium mt-2 line-clamp-2 leading-relaxed">{currentUser.bio}</p>
            ) : (
              <p className="text-[11px] text-slate-500 font-bold mt-2">لا توجد سيرة ذاتية بعد. انقر على تعديل الملف الشخصي لإضافتها.</p>
            )}
          </div>
        </div>

        {/* ================================================================= */}
        {/* 1. قسم إدارة الحساب والأمان (Account & Security) */}
        {/* ================================================================= */}
        <section className="bg-slate-900/60 border border-white/5 rounded-[2.5rem] p-5 sm:p-7 space-y-4 shadow-xl">
          <div className="flex items-center space-x-3 space-x-reverse px-2 mb-2">
            <div className="w-9 h-9 rounded-2xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">1. إدارة الحساب والأمان</h3>
              <p className="text-[10px] text-slate-400 font-bold">تعديل بيانات الحساب، كلمات المرور، ورموز الاستعادة</p>
            </div>
          </div>

          <div className="space-y-3">
            {/* زر تعديل الملف الشخصي */}
            <button 
              onClick={() => setActiveModal('editProfile')}
              className="w-full p-4 sm:p-5 bg-black/40 hover:bg-white/5 border border-white/5 hover:border-blue-500/30 rounded-[2rem] flex items-center justify-between transition-all group active:scale-[0.99]"
            >
              <div className="flex items-center space-x-3.5 space-x-reverse">
                <div className="w-10 h-10 rounded-2xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                </div>
                <div className="text-right">
                  <p className="text-xs font-black text-white group-hover:text-blue-400 transition-colors">تعديل الملف الشخصي</p>
                  <p className="text-[10px] text-slate-400 font-bold mt-0.5">الاسم الظاهر، السيرة الذاتية (Bio)، الصورة الشخصية، ومُعرّف الحساب</p>
                </div>
              </div>
              <svg className="w-5 h-5 text-slate-500 group-hover:text-white flip-in-ltr transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7"/></svg>
            </button>

            {/* زر الأمان وكلمة المرور */}
            <button 
              onClick={() => setActiveModal('securityPassword')}
              className="w-full p-4 sm:p-5 bg-black/40 hover:bg-white/5 border border-white/5 hover:border-blue-500/30 rounded-[2rem] flex items-center justify-between transition-all group active:scale-[0.99]"
            >
              <div className="flex items-center space-x-3.5 space-x-reverse">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                </div>
                <div className="text-right">
                  <p className="text-xs font-black text-white group-hover:text-emerald-400 transition-colors">الأمان وكلمة المرور</p>
                  <p className="text-[10px] text-slate-400 font-bold mt-0.5">تغيير كلمة المرور، ورمز استعادة الحساب السري (Secret Passphrase)</p>
                </div>
              </div>
              <svg className="w-5 h-5 text-slate-500 group-hover:text-white flip-in-ltr transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7"/></svg>
            </button>
          </div>
        </section>

        {/* ================================================================= */}
        {/* 2. قسم الخصوصية والتفاعل (Privacy Controls) */}
        {/* ================================================================= */}
        <section className="bg-slate-900/60 border border-white/5 rounded-[2.5rem] p-5 sm:p-7 space-y-4 shadow-xl">
          <div className="flex items-center justify-between px-2 mb-2">
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="w-9 h-9 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
              </div>
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider">2. الخصوصية والتفاعل</h3>
                <p className="text-[10px] text-slate-400 font-bold">
                  {isPage ? 'خيارات مخصصة لصفحتك العامة والتفاعل' : 'خيارات مخصصة لحسابك الشخصي'}
                </p>
              </div>
            </div>
            <span className="text-[9px] font-black px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {isPage ? 'حساب صفحة' : 'حساب شخصي'}
            </span>
          </div>

          <div className="space-y-3">
            {/* في حالة الحساب الشخصي (Personal Profile) */}
            {!isPage && (
              <>
                {/* مفتاح تبديل حساب خاص */}
                <div className="p-4 sm:p-5 bg-black/40 border border-white/5 rounded-[2rem] flex items-center justify-between">
                  <div className="text-right">
                    <p className="text-xs font-black text-white">حساب خاص (Private Profile)</p>
                    <p className="text-[10px] text-slate-400 font-bold mt-0.5">
                      {currentUser.isPrivate 
                        ? 'الحساب خاص حالياً (لا يرى منشوراتك إلا أصدقاؤك فقط)' 
                        : 'الحساب عام حالياً (يمكن للجميع رؤية حسابك ومنشوراتك)'}
                    </p>
                  </div>
                  <button 
                    onClick={handleTogglePrivateAccount}
                    className={`relative w-12 h-6 rounded-full transition-colors p-0.5 ${currentUser.isPrivate ? 'bg-blue-600' : 'bg-white/10'}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white transition-transform ${currentUser.isPrivate ? 'translate-x-0' : 'translate-x-6'}`} />
                  </button>
                </div>

                {/* زر من يمكنه إرسال طلبات صداقة */}
                <button 
                  onClick={() => openPrivacyOptionModal(
                    'whoCanSendFriendRequests',
                    'من يمكنه إرسال طلبات صداقة',
                    'اختر الفئات التي تستطيع إرسال طلبات صداقة إليك',
                    [
                      { value: 'everyone', label: 'الجميع' },
                      { value: 'friends_of_friends', label: 'أصدقاء الأصدقاء' },
                      { value: 'nobody', label: 'إيقاف الطلبات' }
                    ]
                  )}
                  className="w-full p-4 sm:p-5 bg-black/40 hover:bg-white/5 border border-white/5 rounded-[2rem] flex items-center justify-between transition-all group"
                >
                  <div className="text-right">
                    <p className="text-xs font-black text-white group-hover:text-blue-400 transition-colors">من يمكنه إرسال طلبات صداقة</p>
                    <p className="text-[10px] text-slate-400 font-bold mt-0.5">
                      {currentUser.whoCanSendFriendRequests === 'nobody' ? 'إيقاف الطلبات' : currentUser.whoCanSendFriendRequests === 'friends_of_friends' ? 'أصدقاء الأصدقاء' : 'الجميع'}
                    </p>
                  </div>
                  <span className="text-[10px] font-black text-blue-400 bg-blue-500/10 px-3 py-1.5 rounded-xl border border-blue-500/20">تغيير</span>
                </button>

                {/* زر إظهار قائمة الأصدقاء */}
                <button 
                  onClick={() => openPrivacyOptionModal(
                    'whoCanSeeFriendsList',
                    'إظهار قائمة الأصدقاء',
                    'حدد من يستطيع الاطلاع على قائمة أصدقائك في ملفك الشخصي',
                    [
                      { value: 'everyone', label: 'الجميع' },
                      { value: 'friends_only', label: 'الأصدقاء فقط' },
                      { value: 'only_me', label: 'أنا فقط' }
                    ]
                  )}
                  className="w-full p-4 sm:p-5 bg-black/40 hover:bg-white/5 border border-white/5 rounded-[2rem] flex items-center justify-between transition-all group"
                >
                  <div className="text-right">
                    <p className="text-xs font-black text-white group-hover:text-blue-400 transition-colors">إظهار قائمة الأصدقاء</p>
                    <p className="text-[10px] text-slate-400 font-bold mt-0.5">
                      {currentUser.whoCanSeeFriendsList === 'only_me' ? 'أنا فقط' : currentUser.whoCanSeeFriendsList === 'friends_only' ? 'الأصدقاء فقط' : 'الجميع'}
                    </p>
                  </div>
                  <span className="text-[10px] font-black text-blue-400 bg-blue-500/10 px-3 py-1.5 rounded-xl border border-blue-500/20">تغيير</span>
                </button>

                {/* زر تحديد من يمكن إرسال طلبات المراسلة */}
                <button 
                  onClick={() => openPrivacyOptionModal(
                    'whoCanSendChatRequests',
                    'طلبات المراسلة الجديدة',
                    'حدد من يمكنه بدء محادثات جديدة وإرسال طلبات مراسلة إليك',
                    [
                      { value: 'everyone', label: 'الكل' },
                      { value: 'friends_of_friends', label: 'أصدقاء الأصدقاء' },
                      { value: 'nobody', label: 'متوقف' }
                    ]
                  )}
                  className="w-full p-4 sm:p-5 bg-black/40 hover:bg-white/5 border border-white/5 rounded-[2rem] flex items-center justify-between transition-all group"
                >
                  <div className="text-right">
                    <p className="text-xs font-black text-white group-hover:text-blue-400 transition-colors">تحديد من يمكن إرسال طلبات المراسلة</p>
                    <p className="text-[10px] text-slate-400 font-bold mt-0.5">
                      {currentUser.whoCanSendChatRequests === 'nobody' ? 'متوقف' : currentUser.whoCanSendChatRequests === 'friends_of_friends' ? 'أصدقاء الأصدقاء' : 'الكل'}
                    </p>
                  </div>
                  <span className="text-[10px] font-black text-blue-400 bg-blue-500/10 px-3 py-1.5 rounded-xl border border-blue-500/20">تغيير</span>
                </button>
              </>
            )}

            {/* في حالة حساب الصفحة (Public Page) */}
            {isPage && (
              <button 
                onClick={() => setActiveModal('commentFiltering')}
                className="w-full p-4 sm:p-5 bg-black/40 hover:bg-white/5 border border-white/5 rounded-[2rem] flex items-center justify-between transition-all group"
              >
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="w-10 h-10 rounded-2xl bg-purple-600/10 border border-purple-500/20 text-purple-400 flex items-center justify-center">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-black text-white group-hover:text-purple-400 transition-colors">فلترة التعليقات</p>
                    <p className="text-[10px] text-slate-400 font-bold mt-0.5">
                      إدخال الكلمات المحظورة لتنقية التعليقات تلقائياً ({commentKeywords.length} كلمة محظورة)
                    </p>
                  </div>
                </div>
                <svg className="w-5 h-5 text-slate-500 group-hover:text-white flip-in-ltr transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7"/></svg>
              </button>
            )}

            {/* خيارات الخصوصية المشتركة (Shared Privacy Controls) */}
            <div className="pt-2 border-t border-white/5 space-y-3">
              {/* الحسابات المحظورة */}
              <button 
                onClick={() => setActiveModal('blockedUsers')}
                className="w-full p-4 sm:p-5 bg-black/40 hover:bg-white/5 border border-white/5 rounded-[2rem] flex items-center justify-between transition-all group"
              >
                <div className="text-right">
                  <p className="text-xs font-black text-white group-hover:text-red-400 transition-colors">الحسابات المحظورة (Blocked Users)</p>
                  <p className="text-[10px] text-slate-400 font-bold mt-0.5">
                    عرض القائمة السوداء مع إمكانية فك الحظر عن أي حساب ({currentUser.blockedUsers?.length || 0} حساب)
                  </p>
                </div>
                <span className="text-[10px] font-black text-slate-300 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10 group-hover:border-white/20">إدارة</span>
              </button>
            </div>
          </div>
        </section>

        {/* ================================================================= */}
        {/* 3. منطقة الإجراءات الحساسة (Danger Zone) */}
        {/* ================================================================= */}
        <section className="bg-red-950/20 border border-red-500/25 rounded-[2.5rem] p-5 sm:p-7 space-y-4 shadow-xl">
          <div className="flex items-center space-x-3 space-x-reverse px-2 mb-2">
            <div className="w-9 h-9 rounded-2xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
            </div>
            <div>
              <h3 className="text-sm font-black text-red-400 uppercase tracking-wider">3. منطقة الإجراءات الحساسة (Danger Zone)</h3>
              <p className="text-[10px] text-red-400/70 font-bold">إيقاف الحساب مؤقتاً أو مسحه نهائياً من قاعدة البيانات</p>
            </div>
          </div>

          <div className="space-y-3">
            {/* زر إيقاف النشاط */}
            <button 
              onClick={() => {
                setDangerPassword('');
                setActiveModal('deactivateAccount');
              }}
              className="w-full p-4 sm:p-5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 rounded-[2rem] flex items-center justify-between transition-all group"
            >
              <div className="text-right">
                <p className="text-xs font-black text-amber-400">إيقاف النشاط (تجميد الحساب)</p>
                <p className="text-[10px] text-amber-400/80 font-bold mt-0.5">
                  مع كتابة كلمة المرور، يوقف نشاط الحساب مع عدم إظهار الرسائل والفيديوهات والمنشورات وإخفاء حسابك مؤقتاً
                </p>
              </div>
              <span className="text-[10px] font-black text-amber-300 bg-amber-500/20 px-3 py-1.5 rounded-xl border border-amber-500/30">تجميد</span>
            </button>

            {/* زر حذف الحساب نهائياً */}
            <button 
              onClick={() => {
                setDangerPassword('');
                setDeleteConfirmText('');
                setActiveModal('deleteAccount');
              }}
              className="w-full p-4 sm:p-5 bg-red-600/15 hover:bg-red-600/25 border border-red-500/40 rounded-[2rem] flex items-center justify-between transition-all group"
            >
              <div className="text-right">
                <p className="text-xs font-black text-red-400">حذف الحساب نهائياً (Delete Account)</p>
                <p className="text-[10px] text-red-400/80 font-bold mt-0.5">
                  نافذة تأكيد حازمة بإدخال كلمة المرور لمسح جميع بيانات الحساب والرسائل فوراً دون أي أثر
                </p>
              </div>
              <span className="text-[10px] font-black text-white bg-red-600 px-3 py-1.5 rounded-xl shadow-md shadow-red-600/30">حذف نهائي</span>
            </button>
          </div>
        </section>
      </div>

      {/* ================================================================= */}
      {/* MODAL 1: Edit Profile Modal */}
      {/* ================================================================= */}
      {activeModal === 'editProfile' && (
        <div className="fixed inset-0 z-[500] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl p-6 sm:p-8 space-y-5 text-right overflow-y-auto max-h-[90vh] custom-scrollbar animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <h3 className="text-sm font-black text-white">تعديل الملف الشخصي</h3>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-slate-400 hover:text-white rounded-xl">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>

            {/* Avatar & Photo Picker */}
            <div className="flex flex-col items-center space-y-3 pt-2">
              <div className="relative group">
                <img 
                  src={editPhotoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.Id_user}`} 
                  alt="Avatar" 
                  className="w-24 h-24 rounded-[2rem] object-cover border-4 border-blue-600 shadow-xl bg-slate-800" 
                />
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploadingPhoto}
                  className="absolute inset-0 bg-black/50 rounded-[2rem] opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[10px] font-black"
                >
                  <svg className="w-5 h-5 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                  <span>{isUploadingPhoto ? 'جاري الرفع...' : 'تغيير الصورة'}</span>
                </button>
              </div>
              <input 
                type="file" 
                ref={fileInputRef} 
                accept="image/*" 
                className="hidden" 
                onChange={handlePhotoUpload} 
              />
              <div className="flex gap-2">
                <button 
                  type="button" 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploadingPhoto}
                  className="text-[10px] px-3 py-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 rounded-xl font-bold transition-all"
                >
                  رفع صورة جديدة
                </button>
                <button 
                  type="button" 
                  onClick={() => setEditPhotoURL(`https://api.dicebear.com/7.x/bottts/svg?seed=${Date.now()}`)}
                  className="text-[10px] px-3 py-1.5 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl font-bold transition-all"
                >
                  رمز عشوائي
                </button>
              </div>
            </div>

            {/* Display Name */}
            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1.5">الاسم الظاهر</label>
              <input 
                type="text" 
                value={editName}
                onChange={e => setEditName(e.target.value)}
                placeholder="أدخل اسمك أو اسم صفحتك"
                className="w-full bg-black/40 border border-white/10 rounded-2xl p-3.5 text-xs text-white outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* User ID / Handle */}
            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1.5">مُعرّف الحساب (ID)</label>
              <div className="relative">
                <input 
                  type="text" 
                  value={editId}
                  disabled
                  className="w-full bg-black/60 border border-white/5 rounded-2xl p-3.5 text-xs text-slate-400 font-mono outline-none cursor-not-allowed"
                />
                <span className="absolute left-3 top-3.5 text-[10px] text-slate-500 font-bold">معرّف دائم</span>
              </div>
              <p className="text-[9px] text-slate-500 font-bold mt-1">يُستخدم هذا المعرّف الفريد للبحث عنك وتوجيه الروابط المباشرة لملفك الشخصي.</p>
            </div>

            {/* Bio */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-bold text-slate-400">السيرة الذاتية (Bio)</label>
                <span className="text-[10px] font-mono text-slate-500">{editBio.length}/160</span>
              </div>
              <textarea 
                value={editBio}
                onChange={e => setEditBio(e.target.value.slice(0, 160))}
                rows={3}
                placeholder="اكتب نبذة قصيرة عنك أو عن محتوى صفحتك..."
                className="w-full bg-black/40 border border-white/10 rounded-2xl p-3.5 text-xs text-white outline-none focus:border-blue-500 resize-none transition-colors"
              />
            </div>

            <div className="flex gap-3 pt-3">
              <button 
                onClick={handleSaveProfile}
                disabled={isLoading || isUploadingPhoto}
                className="flex-1 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-black text-xs rounded-2xl shadow-lg shadow-blue-600/30 transition-all disabled:opacity-50"
              >
                {isLoading ? 'جاري الحفظ...' : 'حفظ التعديلات'}
              </button>
              <button 
                onClick={() => setActiveModal(null)}
                className="px-5 py-3.5 bg-white/5 hover:bg-white/10 text-slate-400 font-black text-xs rounded-2xl border border-white/10 transition-all"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL 2: Security & Password Modal */}
      {/* ================================================================= */}
      {activeModal === 'securityPassword' && (
        <div className="fixed inset-0 z-[500] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl p-6 sm:p-8 space-y-6 text-right overflow-y-auto max-h-[90vh] custom-scrollbar animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <div>
                <h3 className="text-sm font-black text-white">الأمان وكلمة المرور</h3>
                <p className="text-[10px] text-slate-400 font-bold">تغيير كلمة المرور ورمز استعادة الحساب السري</p>
              </div>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-slate-400 hover:text-white rounded-xl">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>

            {/* الجزء الأول: تغيير كلمة المرور */}
            <div className="space-y-3.5">
              <h4 className="text-xs font-black text-blue-400 flex items-center space-x-1.5 space-x-reverse">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" /></svg>
                <span>تغيير كلمة المرور الحالية</span>
              </h4>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">كلمة المرور الحالية</label>
                <div className="relative">
                  <input 
                    type={showPasswordText ? 'text' : 'password'}
                    value={currentPasswordInput}
                    onChange={e => setCurrentPasswordInput(e.target.value)}
                    placeholder="أدخل كلمة المرور الحالية للتحقق"
                    className="w-full bg-black/40 border border-white/10 rounded-2xl p-3 text-xs text-white outline-none focus:border-blue-500"
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPasswordText(!showPasswordText)}
                    className="absolute left-3 top-3 text-slate-500 hover:text-slate-300"
                  >
                    {showPasswordText ? 'إخفاء' : 'عرض'}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">كلمة المرور الجديدة</label>
                <input 
                  type={showPasswordText ? 'text' : 'password'}
                  value={newPasswordInput}
                  onChange={e => setNewPasswordInput(e.target.value)}
                  placeholder="كلمة مرور قوية (6 أحرف على الأقل)"
                  className="w-full bg-black/40 border border-white/10 rounded-2xl p-3 text-xs text-white outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">تأكيد كلمة المرور الجديدة</label>
                <input 
                  type={showPasswordText ? 'text' : 'password'}
                  value={confirmPasswordInput}
                  onChange={e => setConfirmPasswordInput(e.target.value)}
                  placeholder="أعد إدخال كلمة المرور الجديدة"
                  className="w-full bg-black/40 border border-white/10 rounded-2xl p-3 text-xs text-white outline-none focus:border-blue-500"
                />
              </div>

              <button 
                onClick={handleUpdatePassword}
                disabled={isLoading}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-black text-xs rounded-2xl shadow-lg shadow-blue-600/30 transition-all disabled:opacity-50"
              >
                {isLoading ? 'جاري التحقق والتحديث...' : 'تحديث كلمة المرور'}
              </button>
            </div>

            {/* الجزء الثاني: رمز استعادة الحساب السري */}
            <div className="pt-4 border-t border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-emerald-400 flex items-center space-x-1.5 space-x-reverse">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                  <span>رمز استعادة الحساب السري (Secret Passphrase)</span>
                </h4>
              </div>

              <p className="text-[10px] text-slate-400 leading-relaxed">
                هذا الرمز اليدوي هو البديل الأساسي للبريد ورقم الهاتف في منصة تِبلوك. احفظه في مكان آمن لاستخدامه في استرداد حسابك في حال نسيان كلمة المرور.
              </p>

              {/* بطاقة عرض الرمز */}
              <div className="p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-2xl flex items-center justify-between">
                <div>
                  <span className="text-[9px] font-bold text-emerald-400 block mb-1">رمز الأمان اليدوي المشفر:</span>
                  <span className="font-mono text-sm font-black text-white tracking-wider select-all">
                    {currentPassphrase}
                  </span>
                </div>
                <button 
                  onClick={() => handleCopyPassphrase(currentPassphrase)}
                  className="p-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black transition-all active:scale-95 flex items-center space-x-1 space-x-reverse shadow-md shadow-emerald-600/20"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                  <span>{passphraseCopied ? 'تم النسخ!' : 'نسخ'}</span>
                </button>
              </div>

              <button 
                onClick={handleGenerateNewPassphrase}
                disabled={isLoading}
                className="w-full py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-[10px] rounded-xl border border-white/10 transition-all"
              >
                إعادة إنشاء كود أمان يدوي جديد
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL 3: Privacy Option Selector */}
      {/* ================================================================= */}
      {activeModal === 'privacyOption' && privacyOptionConfig && (
        <div className="fixed inset-0 z-[500] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl p-6 text-right space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-sm font-black text-white">{privacyOptionConfig.title}</h3>
              <button onClick={() => setActiveModal(null)} className="p-1 text-slate-400 hover:text-white">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed font-bold">{privacyOptionConfig.description}</p>

            <div className="space-y-2 pt-2">
              {privacyOptionConfig.options.map(opt => {
                const currentVal = (currentUser as any)[privacyOptionConfig.field] || privacyOptionConfig.options[0].value;
                const isSelected = currentVal === opt.value;
                return (
                  <button 
                    key={opt.value}
                    onClick={() => handleSelectPrivacyOption(opt.value)}
                    disabled={isLoading}
                    className={`w-full p-4 rounded-2xl font-black text-xs transition-all flex items-center justify-between border ${
                      isSelected 
                        ? 'bg-blue-600 text-white border-blue-400/40 shadow-lg shadow-blue-600/30' 
                        : 'bg-black/40 text-slate-300 border-white/5 hover:bg-white/5'
                    }`}
                  >
                    <span>{opt.label}</span>
                    {isSelected && <span className="text-sm">✓</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL 4: Comment Filtering (For Pages) */}
      {/* ================================================================= */}
      {activeModal === 'commentFiltering' && (
        <div className="fixed inset-0 z-[500] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl p-6 sm:p-8 space-y-5 text-right animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <div>
                <h3 className="text-sm font-black text-white">فلترة التعليقات التلقائية</h3>
                <p className="text-[10px] text-slate-400 font-bold">تنقية التعليقات وحجب الكلمات المسيئة على منشوراتك</p>
              </div>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-slate-400 hover:text-white rounded-xl">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>

            {/* Keyword Input */}
            <div className="flex gap-2">
              <input 
                type="text" 
                value={newKeywordInput}
                onChange={e => setNewKeywordInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleAddCommentKeyword()}
                placeholder="أدخل كلمة محظورة ثم اضغط إضافة..."
                className="flex-1 bg-black/40 border border-white/10 rounded-2xl px-4 py-3 text-xs text-white outline-none focus:border-purple-500"
              />
              <button 
                onClick={handleAddCommentKeyword}
                className="px-5 py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-2xl text-xs font-black shadow-lg shadow-purple-600/30 transition-all active:scale-95"
              >
                إضافة
              </button>
            </div>

            {/* List of blocked words */}
            <div>
              <p className="text-[10px] font-bold text-slate-400 mb-2">قائمة الكلمات المحظورة ({commentKeywords.length}):</p>
              {commentKeywords.length === 0 ? (
                <div className="p-6 text-center border border-dashed border-white/10 rounded-2xl text-slate-500 text-xs">
                  لا توجد كلمات محظورة حالياً. أضف كلمات لتصفية التعليقات غير المرغوبة تلقائياً.
                </div>
              ) : (
                <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto custom-scrollbar p-1">
                  {commentKeywords.map(kw => (
                    <span 
                      key={kw} 
                      className="px-3 py-1.5 bg-purple-500/15 border border-purple-500/30 text-purple-300 rounded-xl text-xs font-bold flex items-center space-x-1.5 space-x-reverse"
                    >
                      <span>{kw}</span>
                      <button 
                        onClick={() => handleRemoveCommentKeyword(kw)}
                        className="text-purple-400 hover:text-white mr-1"
                        title="حذف"
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-2">
              <button 
                onClick={() => setActiveModal(null)}
                className="w-full py-3.5 bg-white/5 hover:bg-white/10 text-white font-black text-xs rounded-2xl border border-white/10 transition-all"
              >
                تم الإنتهاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL 5: Blocked Users List Modal */}
      {/* ================================================================= */}
      {activeModal === 'blockedUsers' && (
        <div className="fixed inset-0 z-[500] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl p-6 sm:p-8 space-y-4 text-right animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <div>
                <h3 className="text-sm font-black text-white">الحسابات المحظورة (القائمة السوداء)</h3>
                <p className="text-[10px] text-slate-400 font-bold">الحسابات المحظورة لا يمكنها التواصل معك أو رؤية منشوراتك</p>
              </div>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-slate-400 hover:text-white rounded-xl">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto custom-scrollbar space-y-2.5 pr-1">
              {loadingBlocked ? (
                <div className="py-8 flex justify-center">
                  <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : blockedUsersDetails.length === 0 ? (
                <div className="py-8 text-center text-slate-500 text-xs font-bold">
                  لا توجد أي حسابات في القائمة المحظورة حالياً.
                </div>
              ) : (
                blockedUsersDetails.map(u => (
                  <div key={u.id} className="p-3 bg-black/40 border border-white/5 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center space-x-2.5 space-x-reverse">
                      <img 
                        src={u.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${u.id}`} 
                        alt="Blocked" 
                        className="w-9 h-9 rounded-xl object-cover bg-slate-800"
                      />
                      <div className="text-right">
                        <p className="text-xs font-black text-white truncate max-w-[150px]">{u.name}</p>
                        <p className="text-[9px] text-slate-500 font-mono">@{u.id}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => handleUnblockUser(u.id)}
                      className="px-3 py-1.5 bg-red-600/10 hover:bg-red-600 text-red-400 hover:text-white border border-red-500/20 rounded-xl text-[10px] font-black transition-all active:scale-95"
                    >
                      فك الحظر
                    </button>
                  </div>
                ))
              )}
            </div>

            <button 
              onClick={() => setActiveModal(null)}
              className="w-full py-3 bg-white/5 hover:bg-white/10 text-slate-300 font-black text-xs rounded-2xl border border-white/10 transition-all mt-2"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL 6: Deactivate / Freeze Account Modal */}
      {/* ================================================================= */}
      {activeModal === 'deactivateAccount' && (
        <div className="fixed inset-0 z-[500] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-[2.5rem] shadow-2xl p-6 sm:p-8 space-y-5 text-right animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
            </div>
            
            <div className="text-center">
              <h3 className="text-base font-black text-white">إيقاف نشاط الحساب مؤقتاً</h3>
              <p className="text-[11px] text-amber-300 font-bold mt-1">تجميد الحساب وإخفاء الظهور</p>
            </div>

            <div className="p-4 bg-amber-950/20 border border-amber-500/20 rounded-2xl text-[11px] text-amber-200/90 leading-relaxed space-y-1.5">
              <p>• سيتم إخفاء حسابك فوراً عن بقية المستخدمين وفي نتائج البحث.</p>
              <p>• لن تظهر رسائلك أو فيديوهاتك أو منشوراتك لأي شخص أثناء فترة التجميد.</p>
              <p>• <strong className="text-white">يمكنك استئناف النشاط في أي وقت</strong> بمجرد تسجيل الدخول مجدداً بكلمة مرورك.</p>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1.5">أدخل كلمة المرور الحالية لتأكيد التجميد:</label>
              <input 
                type="password" 
                value={dangerPassword}
                onChange={e => setDangerPassword(e.target.value)}
                placeholder="كلمة مرور حسابك الحالية"
                className="w-full bg-black/50 border border-white/10 rounded-2xl p-3.5 text-xs text-white outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button 
                onClick={handleDeactivateAccount}
                disabled={isLoading || !dangerPassword}
                className="flex-1 py-3.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-black text-xs rounded-2xl shadow-lg shadow-amber-600/20 transition-all disabled:opacity-40"
              >
                {isLoading ? 'جاري المعالجة...' : 'تأكيد تجميد الحساب'}
              </button>
              <button 
                onClick={() => setActiveModal(null)}
                className="px-5 py-3.5 bg-white/5 hover:bg-white/10 text-slate-400 font-black text-xs rounded-2xl border border-white/10 transition-all"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL 7: Delete Account Permanent Modal */}
      {/* ================================================================= */}
      {activeModal === 'deleteAccount' && (
        <div className="fixed inset-0 z-[500] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-red-500/40 rounded-[2.5rem] shadow-2xl p-6 sm:p-8 space-y-5 text-right animate-in zoom-in-95">
            <div className="w-14 h-14 rounded-2xl bg-red-600/15 border border-red-500/40 flex items-center justify-center text-red-500 mx-auto">
              <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            </div>
            
            <div className="text-center">
              <h3 className="text-base font-black text-white">حذف الحساب نهائياً من قاعدة البيانات</h3>
              <p className="text-[11px] text-red-400 font-bold mt-1">إجراء نهائي وشامل بدون أي إمكانية للاسترجاع</p>
            </div>

            <div className="p-4 bg-red-950/30 border border-red-500/30 rounded-2xl text-[11px] text-red-200/90 leading-relaxed space-y-1">
              <p>• سيتم مسح حسابك وكافة سجلاتك فوراً من قاعدة بيانات المنصة بشكل نهائي.</p>
              <p>• سيتم حذف كافة الرسائل، الفيديوهات (Reels)، الملاحظات والملفات المرفوعة دون الاحتفاظ بأي أثر.</p>
              <p className="text-red-400 font-black pt-1">⚠️ تحذير: لا يمكن التراجع عن هذا الإجراء إطلاقاً.</p>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1.5">1. أدخل كلمة المرور الحالية للتأكيد:</label>
              <input 
                type="password" 
                value={dangerPassword}
                onChange={e => setDangerPassword(e.target.value)}
                placeholder="كلمة مرور الحساب"
                className="w-full bg-black/50 border border-white/10 rounded-2xl p-3 text-xs text-white outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1.5">2. اكتب كلمة <strong className="text-red-400">"حذف"</strong> في الحقل أدناه:</label>
              <input 
                type="text" 
                value={deleteConfirmText}
                onChange={e => setDeleteConfirmText(e.target.value)}
                placeholder="اكتب حذف للتأكيد"
                className="w-full bg-black/50 border border-white/10 rounded-2xl p-3 text-xs text-white outline-none focus:border-red-500 text-center font-black"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button 
                onClick={handleDeleteAccountPermanent}
                disabled={isLoading || !dangerPassword || (deleteConfirmText.trim() !== 'حذف' && deleteConfirmText.trim().toLowerCase() !== 'delete')}
                className="flex-1 py-3.5 bg-red-600 hover:bg-red-500 text-white font-black text-xs rounded-2xl shadow-xl shadow-red-600/30 transition-all disabled:opacity-30"
              >
                {isLoading ? 'جاري المسح النهائي...' : 'تأكيد الحذف النهائي الشامل'}
              </button>
              <button 
                onClick={() => setActiveModal(null)}
                className="px-5 py-3.5 bg-white/5 hover:bg-white/10 text-slate-400 font-black text-xs rounded-2xl border border-white/10 transition-all"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Language Modal */}
      {activeModal === 'language' && (
        <LanguageModal onClose={() => setActiveModal(null)} />
      )}

      <ImageCropperModal
        file={pendingCropFile}
        title="تحديد جزء صورة البروفايل (1:1)"
        onCancel={() => setPendingCropFile(null)}
        onConfirm={handleConfirmCroppedPhoto}
      />
    </div>
  );
};

export default AccountSettingsView;
