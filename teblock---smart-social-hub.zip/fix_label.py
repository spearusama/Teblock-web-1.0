import re

with open('components/AuthForm.tsx', 'r') as f:
    content = f.read()

# Replace the specific text in the label
old_text = "الخاصة بـ TeBLOCK. وأقر بأن التطبيق غير مسؤول قانونياً عن أي خرق أمني أو تسريب ناتج عن ثغرات في خوادم طرف ثالث."
new_text = "الخاصة بـ TeBLOCK. وأقر بأني اطلعت عليها وأوافق عليها بالكامل وبأن التطبيق يتخذ تدابير أمنية معقولة."

content = content.replace(old_text, new_text)

with open('components/AuthForm.tsx', 'w') as f:
    f.write(content)

