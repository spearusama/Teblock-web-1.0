import re

with open('components/MenuView.tsx', 'r') as f:
    content = f.read()

# Add imports
content = content.replace("import React, { useState } from 'react';", "import React, { useState } from 'react';\nimport { User } from '../types';\nimport { doc, updateDoc } from 'firebase/firestore';\nimport { db } from '../firebase';")

# Update props interface
props_old = """interface MenuViewProps {
  isDeveloper: boolean;
  setIsDeveloper: (val: boolean) => void;
  onNavigate: (view: string) => void;
  onBack: () => void;
}"""
props_new = """interface MenuViewProps {
  user: User;
  onNavigate: (view: string) => void;
  onBack: () => void;
}"""
content = content.replace(props_old, props_new)

# Update component signature
comp_old = "export const MenuView: React.FC<MenuViewProps> = ({ isDeveloper, setIsDeveloper, onNavigate, onBack }) => {"
comp_new = "export const MenuView: React.FC<MenuViewProps> = ({ user, onNavigate, onBack }) => {"
content = content.replace(comp_old, comp_new)

# Update redeem logic
redeem_old = """  const handleRedeemCode = () => {
    if (!code.trim()) return;
    const upperCode = code.trim().toUpperCase();

    if (upperCode === 'D3R5') {
      setIsDeveloper(true);
      localStorage.setItem('teblock_developer', 'true');
      setCodeMessage({ text: 'تم تفعيل وضع المطور بنجاح!', type: 'success' });
      setCode('');
    } else {
      setCodeMessage({ text: 'الكود غير صالح أو منتهي الصلاحية.', type: 'error' });
    }
  };"""

redeem_new = """  const handleRedeemCode = async () => {
    if (!code.trim()) return;
    const upperCode = code.trim().toUpperCase();

    try {
      if (upperCode === 'D3R5') {
        await updateDoc(doc(db, 'users', user.Id_user), {
          isDeveloper: true
        });
        setCodeMessage({ text: 'تم تفعيل وضع المطور بنجاح!', type: 'success' });
        setCode('');
      } else {
        setCodeMessage({ text: 'الكود غير صالح أو منتهي الصلاحية.', type: 'error' });
      }
    } catch (e) {
      setCodeMessage({ text: 'حدث خطأ أثناء الاتصال بالخادم.', type: 'error' });
    }
  };"""
content = content.replace(redeem_old, redeem_new)

# Replace isDeveloper check
content = content.replace("{isDeveloper && (", "{user.isDeveloper && (")

with open('components/MenuView.tsx', 'w') as f:
    f.write(content)
