sed -i '5i import { encryptText, decryptText } from "../utils/crypto";' components/AuthForm.tsx
sed -i 's/password: formData.password,/password: encryptText(formData.password),/g' components/AuthForm.tsx
sed -i 's/if (userData.password !== formData.password)/if (decryptText(userData.password) !== formData.password)/g' components/AuthForm.tsx
