with open('components/ChatContainer.tsx', 'r') as f:
    content = f.read()

if "import { MenuView }" not in content:
    content = "import { MenuView } from './MenuView';\n" + content

with open('components/ChatContainer.tsx', 'w') as f:
    f.write(content)
