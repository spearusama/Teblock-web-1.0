import re

with open('components/ChatContainer.tsx', 'r') as f:
    content = f.read()

# 1. Add states
state_addition = """  const [showSettingsPopover, setShowSettingsPopover] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [isDeveloper, setIsDeveloper] = useState(() => localStorage.getItem('teblock_developer') === 'true');"""

content = content.replace("  const [showSettingsPopover, setShowSettingsPopover] = useState(false);", state_addition)

# 2. Add admin_reports view case
view_cases_old = """    if (currentView === 'settings') {
      return (
        <AccountSettingsView 
          user={user}
          onBack={() => setCurrentView('chats')}
          onLogout={onLogout}
        />
      );
    }"""

view_cases_new = """    if (currentView === 'settings') {
      return (
        <AccountSettingsView 
          user={user}
          onBack={() => setCurrentView('chats')}
          onLogout={onLogout}
        />
      );
    }
    if (currentView === 'admin_reports') {
      return (
        <AdminReportsView 
          onBack={() => setCurrentView('chats')}
        />
      );
    }"""

content = content.replace(view_cases_old, view_cases_new)

# 3. Add AdminReportsView import
import_addition = """import { AdminReportsView } from './AdminReportsView';
export const ChatContainer = """

content = content.replace("export const ChatContainer = ", import_addition)

# 4. Replace notifications button with menu
nav_old = """           <button onClick={() => { setCurrentView('notifications'); setJumpToReelId(null); }} className={`p-3 transition-all ${currentView === 'notifications' ? 'text-blue-500 scale-110' : 'text-slate-500 opacity-40'}`}>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" strokeWidth={2.5}/></svg>
           </button>"""

nav_new = """           <button onClick={() => setShowMenu(true)} className={`p-3 transition-all ${showMenu ? 'text-blue-500 scale-110' : 'text-slate-500 opacity-40'}`}>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" strokeWidth={2.5}/></svg>
           </button>"""

content = content.replace(nav_old, nav_new)

# 5. Add menu modal at the end
menu_modal = """      {showMenu && (
        <div className="fixed inset-0 z-[200] flex flex-col justify-end bg-black/60 backdrop-blur-sm" onClick={() => setShowMenu(false)}>
          <div className="bg-slate-900 border-t border-white/10 rounded-t-[2.5rem] p-6 pb-12 animate-in slide-in-from-bottom" onClick={e => e.stopPropagation()}>
             <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto mb-6"></div>
             <h3 className="text-white font-black text-lg mb-6 text-center">القائمة</h3>
             
             <div className="space-y-3">
               {!isDeveloper && (
                 <button 
                   onClick={() => {
                     const code = prompt("أدخل كود المطور:");
                     if (code === "D3R5") {
                       setIsDeveloper(true);
                       localStorage.setItem("teblock_developer", "true");
                       alert("تم تفعيل وضع المطور بنجاح!");
                     } else if (code) {
                       alert("الكود خاطئ!");
                     }
                   }}
                   className="w-full flex items-center justify-between p-4 bg-white/5 hover:bg-white/10 rounded-2xl transition-colors"
                 >
                   <span className="text-white font-bold text-sm">تفعيل وضع المطور</span>
                   <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" strokeWidth={2}/></svg>
                 </button>
               )}
               
               {isDeveloper && (
                 <button 
                   onClick={() => {
                     setCurrentView('admin_reports');
                     setShowMenu(false);
                   }}
                   className="w-full flex items-center justify-between p-4 bg-red-600/10 hover:bg-red-600/20 border border-red-500/20 rounded-2xl transition-colors text-red-500"
                 >
                   <span className="font-bold text-sm">الإبلاغات والعقوبات</span>
                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" strokeWidth={2}/></svg>
                 </button>
               )}
               
               {/* Could add other menu options here later */}
             </div>
          </div>
        </div>
      )}"""

content = content.replace("      {showDebug && <DebugView onClose={() => setShowDebug(false)} />}\n    </div>", f"      {{showDebug && <DebugView onClose={{() => setShowDebug(false)}} />}}\n{menu_modal}\n    </div>")

with open('components/ChatContainer.tsx', 'w') as f:
    f.write(content)
