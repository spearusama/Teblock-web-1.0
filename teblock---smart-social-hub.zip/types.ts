
export interface UserNote {
  id: string;
  userId: string;
  text: string;
  timestamp: any;
  userName: string;
  userPhoto?: string;
  musicTrack?: {
    id?: string;
    name: string;
    artist: string;
    previewUrl?: string;
    cover?: string;
    clipStart?: number;
    duration?: number;
    is30SecClip?: boolean;
    youtubeUrl?: string;
    videoId?: string;
    source?: string;
  };
  gifUrl?: string;
  reactions?: { userId: string; emoji: string; userName: string; userPhoto: string }[];
}

export interface User {
  Id_user: string;
  'id-2'?: string;
  UserData: string;
  gender: string;
  country: string;
  Contrôler: string;
  Freechat: string;
  Freechat_unlock: string;
  Freepublishing: string;
  Freepublishing_unlock: string;
  Freeaccount: string;
  Freeaccount_unlock: string;
  hasAppealed?: boolean;
  photoURL?: string;
  birthDate?: string;
  accountType?: 'user' | 'page';
  postsCount?: number;
  followersCount?: number;
  followingCount?: number;
  followersList?: string[];
  followingList?: string[];
  friendsList?: string[];
  blockedUsers?: string[];
  pendingRequests?: string[];
  sentRequests?: string[];
  lastActive?: any;
  interestVector?: Record<string, number>; 
  savedReels?: string[];
  isDeveloper?: boolean;
  bio?: string;
  secretPassphrase?: string;
  isPrivate?: boolean;
  whoCanSendFriendRequests?: 'everyone' | 'friends_of_friends' | 'nobody';
  whoCanSeeFriendsList?: 'everyone' | 'friends_only' | 'only_me';
  whoCanSendChatRequests?: 'everyone' | 'friends_of_friends' | 'nobody';
  blockedCommentKeywords?: string[];
  directMessagesPermission?: 'everyone' | 'friends_followers' | 'disabled';
  isDeactivated?: boolean;
  deactivatedAt?: any;
  messagingRestrictionUntil?: number | null;
  messagingRestrictedForever?: boolean;
  messagingRestrictionReason?: string;
  publishingRestrictionUntil?: number | null;
  publishingRestrictedForever?: boolean;
  publishingRestrictionReason?: string;
  accountBanReason?: string;
}

export interface Appeal {
  id: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  restrictionType: 'messaging' | 'publishing' | 'account' | 'all';
  reason: string;
  userExplanation?: string;
  timestamp: any;
  status: 'pending' | 'approved' | 'rejected';
}

export interface Group {
  id: string;
  name: string;
  members: string[];
  admins: string[];
  timestamp: any;
  photo?: string;
  createdBy: string;
}

// Reel interface for social short videos
export interface Reel {
  id: string;
  userId: string;
  userName: string;
  userPhoto: string;
  accountType?: 'user' | 'page';
  videoUrl?: string;
  mediaUrls?: { url: string; type: 'video' | 'image' }[];
  musicTrack?: {
    id: string;
    name: string;
    artist: string;
    cover: string;
    previewUrl?: string;
    duration: number;
    clipStart: number;
    youtubeUrl?: string;
    videoId?: string;
    source?: string;
  };
  caption: string;
  keywords?: string[];
  hashtags?: string[];
  likes: string[];
  commentsCount: number;
  sharesCount: number;
  category: string;
  timestamp: any;
  _algoScore?: number;
  matchPercentage?: number;
}

// Comment interface for reel comments
export interface Comment {
  id: string;
  reelId: string;
  userId: string;
  userName: string;
  userPhoto: string;
  text: string;
  timestamp: any;
  likes?: string[];
  parentId?: string; // For replies
  replyToName?: string;
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  senderPhoto?: string;
  receiverId?: string;
  text: string;
  timestamp: any;
  isAI?: boolean;
  isSystem?: boolean;
  isPinned?: boolean;
  reactions?: Record<string, string>;
  voiceUrl?: string;
  imageUrl?: string;
  reelId?: string;
  read?: boolean;
  replyToId?: string;
  replyToText?: string;
  replyToSender?: string;
  edited?: boolean;
  editedAt?: any;
  forwarded?: boolean;
}

export interface Notification {
  id: string;
  toId: string;
  fromId: string;
  fromName: string;
  fromPhoto?: string;
  type: 'friend_request' | 'follow' | 'like' | 'comment' | 'accept_friend';
  read: boolean;
  timestamp: any;
  content?: string;
  relatedId?: string;
}

export type AuthMode = 'login' | 'signup';
