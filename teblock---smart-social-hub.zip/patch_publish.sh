sed -i '5i import { encryptText } from "../utils/crypto";' components/PublishModal.tsx
sed -i 's/caption: caption || "",/caption: encryptText(caption || ""),/g' components/PublishModal.tsx
