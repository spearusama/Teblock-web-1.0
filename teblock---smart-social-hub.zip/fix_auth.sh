# Remove the inserted block
sed -i '/{showTerms && (/,$d' components/AuthForm.tsx

# Put back the original end
cat << 'INNER_EOF' >> components/AuthForm.tsx
  );
};
export default AuthForm;
INNER_EOF
