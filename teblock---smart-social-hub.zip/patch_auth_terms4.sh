cat << 'INNER_EOF' > /tmp/terms_modal.txt
      {showTerms && (
        <div className="fixed inset-0 z-[1000] bg-black/90 backdrop-blur-md flex items-center justify-center p-6">
          <div className="w-full max-w-lg bg-slate-900 border border-white/10 rounded-[2.5rem] p-8 animate-in zoom-in-95 flex flex-col max-h-[80vh]">
            <div className="flex justify-between items-center mb-6">
               <h3 className="text-xl font-black text-white">سياسة الخصوصية وشروط الاستخدام</h3>
               <button type="button" onClick={() => setShowTerms(false)} className="p-2 bg-white/5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors">
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
               </button>
            </div>
            
            <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-4 text-right text-xs text-slate-300 leading-loose">
               <p><strong className="text-blue-400">1. إخلاء المسؤولية الأمنية (Security Disclaimer)</strong></p>
               <p>يتم تخزين بيانات تطبيق TeBLOCK باستخدام خدمات سحابية (Firebase). نحن نستخدم أحدث تقنيات التشفير الشامل (End-to-End Encryption) لحماية نصوص رسائلك، ملاحظاتك، وكلمات المرور الخاصة بك بحيث لا يتم حفظها بصيغة مقروءة في قاعدة البيانات.</p>
               <p>بالموافقة على هذه الشروط، أنت تقر وتوافق على أن TeBLOCK والمطورين القائمين عليه يخلون مسؤوليتهم القانونية والمدنية التامة في حال حدوث أي اختراق أمني، تسريب بيانات، أو أخطاء في قواعد الأمان (Security Rules) ناتجة عن خوادم الطرف الثالث (Firebase/Google) أو هجمات سيبرانية خارجة عن سيطرتنا.</p>
               
               <p><strong className="text-blue-400">2. التشفير والبيانات (Encryption & Data)</strong></p>
               <p>نحن لا نمتلك مفاتيح فك تشفير رسائلك في خوادمنا، ولا يمكننا قراءتها. في حال فقدانك لحسابك، لا يمكننا استرجاع البيانات المشفرة.</p>
               
               <p><strong className="text-blue-400">3. الاستخدام المقبول (Acceptable Use)</strong></p>
               <p>يُمنع استخدام المنصة لأي أغراض غير قانونية، نشر محتوى ضار، أو انتهاك حقوق الآخرين. يحق للإدارة حظر أي حساب ينتهك هذه الشروط فوراً وبدون إنذار مسبق.</p>
            </div>
            
            <div className="mt-8">
              <button type="button" onClick={() => { setAgreeTerms(true); setShowTerms(false); }} className="w-full bg-blue-600 text-white font-black py-4 rounded-2xl hover:bg-blue-500 transition-all shadow-lg shadow-blue-600/20 text-sm">
                موافق وموافق على الشروط
              </button>
            </div>
          </div>
        </div>
      )}
INNER_EOF

# Insert before final closing div
sed -i '/^  );/i \
      {showTerms && ( \
        <div className="fixed inset-0 z-[1000] bg-black/90 backdrop-blur-md flex items-center justify-center p-6"> \
          <div className="w-full max-w-lg bg-slate-900 border border-white/10 rounded-[2.5rem] p-8 animate-in zoom-in-95 flex flex-col max-h-[80vh]"> \
            <div className="flex justify-between items-center mb-6"> \
               <h3 className="text-xl font-black text-white">سياسة الخصوصية وشروط الاستخدام</h3> \
               <button type="button" onClick={() => setShowTerms(false)} className="p-2 bg-white/5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"> \
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg> \
               </button> \
            </div> \
             \
            <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-4 text-right text-xs text-slate-300 leading-loose"> \
               <p><strong className="text-blue-400">1. إخلاء المسؤولية الأمنية (Security Disclaimer)</strong></p> \
               <p>يتم تخزين بيانات تطبيق TeBLOCK باستخدام خدمات سحابية (Firebase). نحن نستخدم أحدث تقنيات التشفير الشامل (End-to-End Encryption) لحماية نصوص رسائلك، ملاحظاتك، وكلمات المرور الخاصة بك بحيث لا يتم حفظها بصيغة مقروءة في قاعدة البيانات.</p> \
               <p>بالموافقة على هذه الشروط، أنت تقر وتوافق على أن TeBLOCK والمطورين القائمين عليه يخلون مسؤوليتهم القانونية والمدنية التامة في حال حدوث أي اختراق أمني، تسريب بيانات، أو أخطاء في قواعد الأمان (Security Rules) ناتجة عن خوادم الطرف الثالث (Firebase/Google) أو هجمات سيبرانية خارجة عن سيطرتنا.</p> \
                \
               <p><strong className="text-blue-400">2. التشفير والبيانات (Encryption & Data)</strong></p> \
               <p>نحن لا نمتلك مفاتيح فك تشفير رسائلك في خوادمنا، ولا يمكننا قراءتها. في حال فقدانك لحسابك، لا يمكننا استرجاع البيانات المشفرة.</p> \
                \
               <p><strong className="text-blue-400">3. الاستخدام المقبول (Acceptable Use)</strong></p> \
               <p>يُمنع استخدام المنصة لأي أغراض غير قانونية، نشر محتوى ضار، أو انتهاك حقوق الآخرين. يحق للإدارة حظر أي حساب ينتهك هذه الشروط فوراً وبدون إنذار مسبق.</p> \
            </div> \
             \
            <div className="mt-8"> \
              <button type="button" onClick={() => { setAgreeTerms(true); setShowTerms(false); }} className="w-full bg-blue-600 text-white font-black py-4 rounded-2xl hover:bg-blue-500 transition-all shadow-lg shadow-blue-600/20 text-sm"> \
                أوافق على الشروط \
              </button> \
            </div> \
          </div> \
        </div> \
      )}' components/AuthForm.tsx

