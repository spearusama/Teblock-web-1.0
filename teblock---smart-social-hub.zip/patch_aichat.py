import re

with open('components/AIChatView.tsx', 'r') as f:
    content = f.read()

chat_map_original = """             {previews.map(chat => (
               <div key={chat.id} 
                  onClick={() => { setActiveChat(chat); setMode('activeChat'); }}
                  onContextMenu={(e) => { e.preventDefault(); toggleManualUnread(chat.id); }}
                  className={`flex items-center p-4 bg-white/[0.02] border border-white/5 rounded-[2.2rem] hover:bg-white/[0.05] transition-all cursor-pointer ${chat.manualUnread ? 'border-blue-500/50 bg-blue-500/5' : ''}`}>"""

chat_map_new = """             {previews.map((chat, index) => (
               <React.Fragment key={chat.id}>
                 <div 
                    onClick={() => { setActiveChat(chat); setMode('activeChat'); }}
                    onContextMenu={(e) => { e.preventDefault(); toggleManualUnread(chat.id); }}
                    className={`flex items-center p-4 bg-white/[0.02] border border-white/5 rounded-[2.2rem] hover:bg-white/[0.05] transition-all cursor-pointer ${chat.manualUnread ? 'border-blue-500/50 bg-blue-500/5' : ''}`}>"""

content = content.replace(chat_map_original, chat_map_new)

chat_map_end_orig = """                  {(chat.unreadCount > 0 || chat.manualUnread) && (
                    <div className={`mr-3 w-5 h-5 ${chat.isTagged ? 'bg-green-500' : 'bg-blue-600'} rounded-full flex items-center justify-center text-[9px] font-black text-white shadow-lg animate-pulse`}>
                      {chat.unreadCount || ""}
                    </div>
                  )}
               </div>
             ))}"""

chat_map_end_new = """                  {(chat.unreadCount > 0 || chat.manualUnread) && (
                    <div className={`mr-3 w-5 h-5 ${chat.isTagged ? 'bg-green-500' : 'bg-blue-600'} rounded-full flex items-center justify-center text-[9px] font-black text-white shadow-lg animate-pulse`}>
                      {chat.unreadCount || ""}
                    </div>
                  )}
                 </div>
                 {(index + 1) % 8 === 0 && (
                   <div 
                      onClick={() => window.open('https://www.effectivecpmnetwork.com/kkki5pzpuw?key=c441d12b6467d461946f2f34bced59d8', '_blank')}
                      className="flex items-center p-4 bg-blue-500/10 border border-blue-500/20 rounded-[2.2rem] hover:bg-blue-500/20 transition-all cursor-pointer relative overflow-hidden"
                   >
                      <div className="absolute top-0 right-0 bg-blue-600 text-white text-[8px] font-black px-2 py-0.5 rounded-bl-lg">إعلان ممول</div>
                      <div className="relative ml-4">
                        <div className="w-12 h-12 rounded-2xl bg-blue-600/30 border border-blue-500/30 flex items-center justify-center">
                           <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11 19l-7-7 7-7m8 14l-7-7 7-7"/></svg>
                        </div>
                      </div>
                      <div className="flex-1 text-right overflow-hidden">
                         <div className="flex justify-between items-center mb-1">
                            <span className="text-[8px] text-blue-400 font-bold">الآن</span>
                            <h4 className="text-[11px] font-black text-blue-400">عروض مميزة</h4>
                         </div>
                         <p className="text-[10px] text-blue-300/80 truncate font-bold">اكتشف أحدث العروض والخدمات عبر شريكنا الإعلاني</p>
                      </div>
                   </div>
                 )}
               </React.Fragment>
             ))}"""

content = content.replace(chat_map_end_orig, chat_map_end_new)

with open('components/AIChatView.tsx', 'w') as f:
    f.write(content)

