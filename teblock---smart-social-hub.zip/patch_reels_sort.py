import re

with open('components/ReelsView.tsx', 'r') as f:
    content = f.read()

sort_logic = """
      const interestVector = user.interestVector || {};
      filtered.forEach(reel => {
        let score = 0;
        if (reel.keywords && reel.keywords.length > 0) {
          reel.keywords.forEach(kw => {
            if (interestVector[kw]) {
              score += interestVector[kw];
            }
          });
          
          // Optionally calculate a percentage relative to total user interests
          const totalInterests = Object.values(interestVector).reduce((acc: number, val: any) => acc + (val as number), 0) as number;
          if (totalInterests > 0) {
             // We can store a string percentage to display
             (reel as any).matchPercentage = Math.min(100, Math.round((score / totalInterests) * 100 * 5)); // multiplied by 5 just to scale up for visual effect
          } else {
             (reel as any).matchPercentage = 0;
          }
        } else {
             (reel as any).matchPercentage = 0;
        }
        reel._algoScore = score;
      });

      filtered.sort((a, b) => {
        const scoreDiff = (b._algoScore || 0) - (a._algoScore || 0);
        if (scoreDiff !== 0) return scoreDiff;
        return (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0);
      });

      if (jumpToReelId && jumpToReelId !== 'SAVED_REELS') {
        const idx = filtered.findIndex(r => r.id === jumpToReelId);
"""

# Replace the specific check for jumpToReelId to insert our logic
content = content.replace("      if (jumpToReelId && jumpToReelId !== 'SAVED_REELS') {", sort_logic)

with open('components/ReelsView.tsx', 'w') as f:
    f.write(content)

